import { useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth";
import { useI18n } from "./i18n";
import { initialTheme } from "./theme";
import Header from "./components/Header";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import Project from "./pages/Project";
import Scan from "./pages/Scan";
import CheckCode from "./pages/CheckCode";
import Settings from "./pages/Settings";

function Private({ children, theme, setTheme }) {
  const { user, ready } = useAuth();
  const { t } = useI18n();
  if (!ready) return <p className="center muted" role="status">{t("app.loading")}</p>;
  if (!user) return <Navigate to="/login" replace />;
  return (
    <>
      <a href="#main" className="skip">{t("app.skip")}</a>
      <Header theme={theme} setTheme={setTheme} />
      <main id="main" tabIndex={-1}>{children}</main>
    </>
  );
}

export default function App() {
  const { user } = useAuth();
  const [theme, setTheme] = useState(initialTheme);
  const P = (el) => <Private theme={theme} setTheme={setTheme}>{el}</Private>;
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Auth />} />
      <Route path="/" element={P(<Dashboard />)} />
      <Route path="/projects" element={P(<Projects />)} />
      <Route path="/projects/:id" element={P(<Project />)} />
      <Route path="/scans/:id" element={P(<Scan />)} />
      <Route path="/check" element={P(<CheckCode />)} />
      <Route path="/settings" element={P(<Settings />)} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
