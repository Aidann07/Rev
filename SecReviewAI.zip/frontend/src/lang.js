// Тіл таңдауы (React-сыз): api.js те, компоненттер де қолданады
const KEY = "secreview_lang";
export const LANGS = [["kk", "Қазақша"], ["ru", "Русский"], ["en", "English"]];

export function getLang() {
  try { const l = localStorage.getItem(KEY); if (LANGS.some(([k]) => k === l)) return l; } catch { /* жеке режим */ }
  return "kk";
}
export function saveLang(l) { try { localStorage.setItem(KEY, l); } catch { /* жеке режим */ } document.documentElement.lang = l; }

// Сервер қателері қазақша келеді: белгілі хабарларды таңдалған тілге аударамыз, қалғаны тұрған күйінде
const EXACT = {
  "Email немесе пароль қате": ["Email или пароль неверны", "Incorrect email or password"],
  "Жүйеге кіру қажет": ["Требуется вход в систему", "Sign-in required"],
  "Сессия жарамсыз": ["Сессия недействительна", "Invalid session"],
  "Ағымдағы құпиясөз қате": ["Текущий пароль неверен", "Current password is incorrect"],
  "Бұл бөлім тек оқытушыға арналған": ["Этот раздел только для преподавателя", "This section is for teachers only"],
  "Оқытушы коды дұрыс емес": ["Неверный код преподавателя", "Incorrect teacher code"],
  "Тек жоба иесі скан іске қоса алады": ["Только владелец проекта может запускать проверку", "Only the project owner can start a scan"],
  "Тек жоба иесі өзгерте алады": ["Только владелец проекта может изменять его", "Only the project owner can edit it"],
  "Тек жоба иесі өшіре алады": ["Только владелец проекта может удалить его", "Only the project owner can delete it"],
  "Жоба табылмады": ["Проект не найден", "Project not found"],
  "Скан табылмады": ["Проверка не найдена", "Scan not found"],
  "Алдыңғы скан әлі аяқталмаған": ["Предыдущая проверка ещё не завершена", "The previous scan is still running"],
  "Бұл email басқа аккаунтқа тіркелген": ["Этот email уже занят другим аккаунтом", "This email belongs to another account"],
  "Бұл email тіркелген": ["Этот email уже зарегистрирован", "This email is already registered"],
  "Скан әлі аяқталмаған": ["Проверка ещё не завершена", "The scan is not finished yet"],
  "Email дұрыс емес": ["Некорректный email", "Invalid email"],
  "Тек .zip файл қабылданады": ["Принимается только .zip файл", "Only .zip files are accepted"],
  "GitHub байланыстырылмаған": ["GitHub не подключён", "GitHub is not connected"],
  "GitHub OAuth бапталмаған (GITHUB_CLIENT_ID/SECRET)": ["GitHub OAuth не настроен (GITHUB_CLIENT_ID/SECRET)", "GitHub OAuth is not configured (GITHUB_CLIENT_ID/SECRET)"],
  "GitHub репозиторийлерін алу мүмкін болмады": ["Не удалось получить репозитории GitHub", "Could not fetch GitHub repositories"],
  "GitHub-пен байланыс орнамады": ["Не удалось связаться с GitHub", "Could not connect to GitHub"],
  "GitHub сілтемесі дұрыс емес. Мысалы: https://github.com/user/repo": ["Некорректная ссылка GitHub. Пример: https://github.com/user/repo", "Invalid GitHub link. Example: https://github.com/user/repo"],
  "ZIP ашылған күйінде тым үлкен (zip-bomb қорғанысы)": ["ZIP слишком велик после распаковки (защита от zip-бомбы)", "ZIP is too large when extracted (zip-bomb protection)"],
  "ZIP файлы бүлінген немесе дұрыс емес": ["ZIP-файл повреждён или некорректен", "The ZIP file is corrupted or invalid"],
  "ZIP ішінде файл саны тым көп": ["В ZIP слишком много файлов", "The ZIP contains too many files"],
  "Репозиторий табылмады немесе жеке (private). GitHub арқылы кіріп, рұқсат беріңіз.": ["Репозиторий не найден или приватный. Подключите GitHub и дайте доступ.", "Repository not found or private. Connect GitHub and grant access."],
  "Репозиторий тым үлкен": ["Репозиторий слишком большой", "The repository is too large"],
  "Репозиторийді клондау уақыты бітті (тым үлкен немесе қолжетімсіз)": ["Время клонирования истекло (слишком большой или недоступен)", "Cloning timed out (too large or unreachable)"],
  "Ішкі қате: талдау аяқталмады": ["Внутренняя ошибка: анализ не завершён", "Internal error: the analysis did not finish"],
  "Failed to fetch": ["Нет связи с сервером. Проверьте, что сервер запущен.", "Cannot reach the server. Check that it is running."],
  "Load failed": ["Нет связи с сервером. Проверьте, что сервер запущен.", "Cannot reach the server. Check that it is running."],
};
const PREFIX = [
  ["Клондау сәтсіз аяқталды:", ["Не удалось клонировать:", "Cloning failed:"]],
  ["GitHub токен бермеді", ["GitHub не выдал токен", "GitHub did not return a token"]],
  ["Файл тым үлкен", ["Файл слишком большой", "File is too large"]],
];
export function translateError(msg) {
  const l = getLang();
  if (l === "kk" || !msg) return msg === "Failed to fetch" || msg === "Load failed" ? "Сервермен байланыс жоқ. Сервер қосулы екенін тексеріңіз." : msg;
  const i = l === "ru" ? 0 : 1;
  if (EXACT[msg]) return EXACT[msg][i];
  for (const [p, tr] of PREFIX) if (msg.startsWith(p)) return tr[i] + msg.slice(p.length);
  return msg;
}

// Талдау барысының кезеңдері серверден қазақша келеді
const STAGES = {
  "Кезекте": ["В очереди", "Queued"], "Бастапқы код алынуда": ["Получение исходного кода", "Fetching source code"],
  "Файлдар жиналуда және тілдер анықталуда": ["Сбор файлов и определение языков", "Collecting files and detecting languages"],
  "Нәтижелер біріктірілуде": ["Объединение результатов", "Merging results"], "Нәтижелер сақталуда": ["Сохранение результатов", "Saving results"],
  "LLM түсіндірмелері дайындалуда": ["Подготовка пояснений ИИ", "Preparing AI explanations"], "Дайын": ["Готово", "Done"], "Қате": ["Ошибка", "Failed"],
};
export function translateStage(s) {
  const l = getLang();
  if (l === "kk" || !s) return s;
  const i = l === "ru" ? 0 : 1;
  if (STAGES[s]) return STAGES[s][i];
  const m = s.match(/^Талдау: (.+)$/);
  return m ? `${l === "ru" ? "Анализ" : "Analysis"}: ${m[1]}` : s;
}
