import { getLang, translateError } from "./lang";
const TOKEN_KEY = "secreview_token";

export const getToken = () => { try { return localStorage.getItem(TOKEN_KEY) || ""; } catch { return ""; } };
export const setToken = (t) => { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* жеке режим */ } };

let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

async function request(path, { method = "GET", body, form, raw } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  let res;
  try { res = await fetch(`/api${path}`, { method, headers, body: payload }); } catch (e) { throw new Error(translateError(e.message || "Failed to fetch")); }
  if (res.status === 401 && token) onUnauthorized();
  if (!res.ok) {
    let msg = { kk: `Қате ${res.status}`, ru: `Ошибка ${res.status}`, en: `Error ${res.status}` }[getLang()];
    try {
      const d = await res.json();
      msg = typeof d.detail === "string" ? d.detail : Array.isArray(d.detail) ? d.detail.map((x) => x.msg).join("; ") : msg;
    } catch { /* json емес */ }
    throw new Error(translateError(msg));
  }
  return raw ? res : res.json();
}

export const api = {
  register: (b) => request("/auth/register", { method: "POST", body: b }),
  login: (b) => request("/auth/login", { method: "POST", body: b }),
  me: () => request("/auth/me"),
  githubStatus: () => request("/auth/github/status"),
  githubRepos: () => request("/auth/github/repos"),
  githubStart: (next) => request(`/auth/github/start?next=${encodeURIComponent(next)}`, { method: "POST" }),
  githubDisconnect: () => request("/auth/github", { method: "DELETE" }),
  updateMe: (b) => request("/auth/me", { method: "PATCH", body: b }),
  changePassword: (b) => request("/auth/password", { method: "POST", body: b }),
  dashboard: () => request(`/dashboard?lang=${getLang()}`),
  recent: () => request("/scans/recent"),
  languages: () => request("/languages"),
  health: () => request("/health"),
  updateProject: (id, b) => request(`/projects/${id}`, { method: "PATCH", body: b }),
  advisors: () => request("/advisors"),
  projects: () => request("/projects"),
  project: (id) => request(`/projects/${id}`),
  createProject: (b) => request("/projects", { method: "POST", body: b }),
  uploadProject: (name, file, description = "", advisors = "") => { const f = new FormData(); f.append("name", name); f.append("description", description); f.append("advisors", advisors); f.append("file", file); return request("/projects/upload", { method: "POST", form: f }); },
  deleteProject: (id) => request(`/projects/${id}`, { method: "DELETE" }),
  startScan: (pid) => request(`/projects/${pid}/scans`, { method: "POST" }),
  projectScans: (pid) => request(`/projects/${pid}/scans`),
  scan: (id) => request(`/scans/${id}`),
  findings: (id, params) => request(`/scans/${id}/findings?${new URLSearchParams({ ...params, lang: getLang() })}`),
  downloadReport: async (id) => {
    const res = await request(`/scans/${id}/report.pdf?lang=${getLang()}`, { raw: true });
    const blob = await res.blob();
    // Серверден келген файл атын оқимыз (кириллицамен, RFC 5987)
    const cd = res.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename\*=UTF-8''([^;]+)/i) || cd.match(/filename="([^"]+)"/i);
    const filename = m ? decodeURIComponent(m[1]) : `SecReview_${id}.pdf`;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  },
};
