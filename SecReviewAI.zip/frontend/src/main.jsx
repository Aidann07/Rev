import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import "@fontsource-variable/inter";
import App from "./App";
import { AuthProvider } from "./auth";
import { I18nProvider } from "./i18n";
import { getLang, saveLang } from "./lang";
import { applyTheme, initialTheme } from "./theme";
import "./styles.css";

applyTheme(initialTheme());
saveLang(getLang());

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <I18nProvider>
        <AuthProvider>
          <App />
        </AuthProvider>
      </I18nProvider>
    </BrowserRouter>
  </React.StrictMode>
);
