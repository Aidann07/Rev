// Тақырып (жарық/қараңғы): таңдау браузерде сақталады, болмаса жүйе баптауы алынады
const KEY = "secreview_theme";
export function initialTheme() {
  try { const t = localStorage.getItem(KEY); if (t === "light" || t === "dark") return t; } catch { /* жеке режим */ }
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
export function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem(KEY, t); } catch { /* жеке режим */ }
}
