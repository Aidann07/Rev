import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../auth";
import { useI18n } from "../i18n";
import { LANGS } from "../lang";
import { applyTheme } from "../theme";
import Icon from "./Icon";

const initials = (n = "") => n.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("") || "?";

// Сыртына басқанда / Esc-те жабылатын ашылмалы мәзір
export function useDropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef();
  useEffect(() => {
    if (!open) return;
    const down = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const key = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", down); document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", down); document.removeEventListener("keydown", key); };
  }, [open]);
  return [open, setOpen, ref];
}

export default function Header({ theme, setTheme }) {
  const { user } = useAuth();
  const { t, lang, setLang } = useI18n();
  const teacher = user.role === "teacher";
  const links = teacher
    ? [["/", "nav.home"], ["/projects", "nav.allProjects"], ["/settings", "nav.settings"]]
    : [["/", "nav.home"], ["/projects", "nav.projects"], ["/check", "nav.check"], ["/settings", "nav.settings"]];
  const flip = () => { const n = theme === "dark" ? "light" : "dark"; applyTheme(n); setTheme(n); };
  return (
    <header className="top">
      <Link to="/" className="brand" aria-label={t("nav.brand")}>
        <span className="logo"><Icon name="shield" size={19} /></span>SecReview AI
      </Link>
      <nav aria-label={t("nav.main")}>
        {links.map(([to, k]) => <NavLink key={to} to={to} end={to === "/"}>{t(k)}</NavLink>)}
      </nav>
      <div className="tools">
        <select aria-label={t("hdr.lang")} value={lang} onChange={(e) => setLang(e.target.value)}>
          {LANGS.map(([k, n]) => <option key={k} value={k}>{n}</option>)}
        </select>
        <button className="iconbtn" onClick={flip} aria-label={theme === "dark" ? t("hdr.toLight") : t("hdr.toDark")}><Icon name={theme === "dark" ? "sun" : "moon"} /></button>
        <span className="avatar" title={user.name} aria-hidden="true">{initials(user.name)}</span>
      </div>
    </header>
  );
}
