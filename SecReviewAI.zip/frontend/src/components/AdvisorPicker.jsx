import { useEffect, useId, useRef, useState } from "react";
import { api } from "../api";
import { useI18n } from "../i18n";
import Icon from "./Icon";

// «Сейітқалиева Айгүл Нұрланқызы» -> «Сейітқалиева А.Н.»
export const shortName = (n = "") => { const [s, ...r] = n.split(/\s+/); return r.length ? `${s} ${r.map((x) => x[0] + ".").join("")}` : n; };

// Ғылыми жетекшілерді тізімнен іздеп таңдау (combobox): чип, пернетақта, ARIA
export default function AdvisorPicker({ value, onChange, max = 5 }) {
  const { t } = useI18n();
  const id = useId();
  const [all, setAll] = useState([]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const box = useRef();
  useEffect(() => { api.advisors().then(setAll).catch(() => {}); }, []);
  useEffect(() => {
    const down = (e) => { if (box.current && !box.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", down);
    return () => document.removeEventListener("mousedown", down);
  }, []);

  const tr = (k, v) => { const r = t(`${k}.${v}`); return r === `${k}.${v}` ? v : r; };
  const needle = q.trim().toLowerCase();
  const opts = all.filter((a) => !value.includes(a.name) && (!needle || `${a.name} ${a.position} ${a.department}`.toLowerCase().includes(needle)));
  const full = value.length >= max;
  const add = (name) => { if (!full && !value.includes(name)) onChange([...value, name]); setQ(""); setActive(0); if (value.length + 1 >= max) setOpen(false); };
  const remove = (name) => onChange(value.filter((v) => v !== name));
  const key = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, opts.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === "Enter" && open && opts[active]) { e.preventDefault(); add(opts[active].name); }
    else if (e.key === "Escape" && open) { e.preventDefault(); e.stopPropagation(); setOpen(false); }   // терезені жаппай, тек тізімді жабу
    else if (e.key === "Backspace" && !q && value.length) remove(value[value.length - 1]);
  };

  return (
    <div className="advpick" ref={box}>
      <span className="lbl" id={`${id}-l`}>{t("md.advisors")}</span>
      <div className="advwrap">
      <div className="advbox" onClick={() => !full && setOpen(true)}>
        {value.map((n) => (
          <span key={n} className="chip2 chipx">{shortName(n)}
            <button type="button" onClick={() => remove(n)} aria-label={t("md.advRemove", { name: n })}><Icon name="x" size={13} /></button>
          </span>
        ))}
        {!full && (
          <input role="combobox" aria-labelledby={`${id}-l`} aria-expanded={open} aria-controls={`${id}-lb`} aria-autocomplete="list"
            aria-activedescendant={open && opts[active] ? `${id}-o${active}` : undefined} value={q} autoComplete="off"
            placeholder={value.length ? "" : t("md.advSearch")} onFocus={() => setOpen(true)} onKeyDown={key}
            onChange={(e) => { setQ(e.target.value); setActive(0); setOpen(true); }} />
        )}
      </div>
      {open && !full && (
        <ul className="advlist" id={`${id}-lb`} role="listbox" aria-labelledby={`${id}-l`}>
          {opts.length === 0 && <li className="muted small" style={{ padding: "10px 12px" }}>{t("md.advNone")}</li>}
          {opts.map((a, i) => (
            <li key={a.id} id={`${id}-o${i}`} role="option" aria-selected={i === active} className={i === active ? "on" : ""}
              onMouseDown={(e) => e.preventDefault()} onClick={() => add(a.name)} onMouseEnter={() => setActive(i)}>
              <strong>{a.name}</strong>
              <small>{[tr("pos", a.position), tr("dep", a.department)].filter(Boolean).join(" · ")}</small>
            </li>
          ))}
        </ul>
      )}
      </div>
      <span className="hint">{t("md.advHint")}</span>
    </div>
  );
}
