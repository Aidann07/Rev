import { useEffect, useRef, useState } from "react";
import { api } from "../api";
import { useAuth } from "../auth";
import { useI18n } from "../i18n";
import AdvisorPicker from "./AdvisorPicker";
import { Alert } from "./ui";
import Icon from "./Icon";

// Жоба қосу / өңдеу терезесі. `project` берілсе — өңдеу режимі.
export default function ProjectModal({ project, onClose, onSaved }) {
  const { user, refresh } = useAuth();
  const { t } = useI18n();
  const ref = useRef();
  const edit = !!project;
  const [tab, setTab] = useState("github");
  const [name, setName] = useState(project?.name || "");
  const [desc, setDesc] = useState(project?.description || "");
  const [adv, setAdv] = useState(project?.advisors || []);
  const [url, setUrl] = useState("");
  const [file, setFile] = useState(null);
  const [repos, setRepos] = useState([]);
  const [gh, setGh] = useState({ enabled: false });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { const d = ref.current; if (d && !d.open) d.showModal(); }, []);
  useEffect(() => { if (!edit) api.githubStatus().then(setGh).catch(() => {}); }, [edit]);
  useEffect(() => { if (!edit && user.github_connected) api.githubRepos().then(setRepos).catch(() => {}); }, [edit, user.github_connected]);

  const connect = async () => { try { window.location.href = (await api.githubStart("/projects")).url; } catch (e) { setErr(e.message); } };
  const disconnect = async () => { await api.githubDisconnect(); await refresh(); setRepos([]); };

  const submit = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try {
      let p;
      if (edit) p = await api.updateProject(project.id, { name, description: desc, advisors: adv });
      else if (tab === "zip") p = await api.uploadProject(name, file, desc, adv.join(", "));
      else p = await api.createProject({ name, repo_url: url, description: desc, advisors: adv });
      onSaved(p);
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  return (
    <dialog ref={ref} onClose={onClose} onClick={(e) => { if (e.target === ref.current) ref.current.close(); }} aria-labelledby="mtitle">
      <div className="mhead">
        <h2 id="mtitle">{t(edit ? "md.edit" : "md.add")}</h2>
        <button className="iconbtn" type="button" onClick={() => ref.current.close()} aria-label={t("app.close")}><Icon name="x" size={18} /></button>
      </div>
      <form className="mbody" onSubmit={submit}>
        {!edit && (
          <div className="tabs" role="tablist" aria-label={t("md.source")}>
            <button role="tab" aria-selected={tab === "github"} className={tab === "github" ? "on" : ""} onClick={() => setTab("github")} type="button">{t("md.tabGh")}</button>
            <button role="tab" aria-selected={tab === "zip"} className={tab === "zip" ? "on" : ""} onClick={() => setTab("zip")} type="button">{t("md.tabZip")}</button>
          </div>
        )}
        <label>{t("md.name")}<input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("md.namePh")} required maxLength={200} /></label>
        <label>{t("md.desc")} <span className="hint">{t("md.optional")}</span><textarea rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={500} /></label>
        <AdvisorPicker value={adv} onChange={setAdv} />
        {!edit && (tab === "github" ? (
          <>
            <label>{t("md.repo")}
              <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://github.com/user/repo" required inputMode="url" autoComplete="off" />
            </label>
            {user.github_connected && (
              <label>{t("md.pickRepo")}
                <select value="" onChange={(e) => { const r = repos.find((x) => x.url === e.target.value); if (r) { setUrl(r.url); if (!name) setName(r.name.split("/")[1]); } }}>
                  <option value="">{repos.length ? t("md.pickPh") : t("md.pickNone")}</option>
                  {repos.map((r) => <option key={r.url} value={r.url}>{r.name}{r.private ? " " + t("md.private") : ""}</option>)}
                </select>
              </label>
            )}
            <p className="muted small">{t("md.ghNote")}<br />{t("md.ghTip")}</p>
            {gh.enabled && (user.github_connected
              ? <p className="small">{t("md.ghConnected")} <strong>{user.github_login}</strong> · <button type="button" className="link" onClick={disconnect}>{t("app.disconnect")}</button></p>
              : <button type="button" className="btn" onClick={connect}><Icon name="github" size={18} />{t("md.ghConnect")}</button>)}
          </>
        ) : (
          <label>{t("md.zip")}<input type="file" accept=".zip,application/zip" onChange={(e) => setFile(e.target.files[0])} required /></label>
        ))}
        <Alert>{err}</Alert>
        <div className="mfoot">
          <button type="button" className="btn" onClick={() => ref.current.close()}>{t("app.cancel")}</button>
          <button className="btn primary" disabled={busy}>{busy ? t("app.saving") : edit ? t("app.save") : t("app.add")}</button>
        </div>
      </form>
    </dialog>
  );
}
