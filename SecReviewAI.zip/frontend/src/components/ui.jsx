import { useI18n } from "../i18n";

export const SEV = {
  high: { icon: "▲", cls: "sev-high" },
  medium: { icon: "◆", cls: "sev-medium" },
  low: { icon: "●", cls: "sev-low" },
  info: { icon: "○", cls: "sev-info" },
};

// Қауіптілік түспен ғана емес, белгі + мәтінмен де көрсетіледі (WCAG: түс жалғыз ақпарат көзі болмауы тиіс)
export function SeverityBadge({ level }) {
  const { t } = useI18n();
  const s = SEV[level] || SEV.info;
  return <span className={`badge ${s.cls}`}><span aria-hidden="true">{s.icon}</span> {t(`sev.${SEV[level] ? level : "info"}`)}</span>;
}

export function Grade({ grade, score, compact }) {
  const { t } = useI18n();
  const cls = grade === "A" || grade === "B" ? "g-ok" : grade === "C" ? "g-mid" : "g-bad";
  return (
    <div className={`grade ${cls}${compact ? " compact" : ""}`} role="img" aria-label={t("grade.aria", { grade, score })}>
      <strong aria-hidden="true">{grade}</strong>
      <span aria-hidden="true">{score}/100</span>
    </div>
  );
}

export function Alert({ kind = "error", children }) {
  if (!children) return null;
  return <div className={`alert ${kind}`} role={kind === "error" ? "alert" : "status"}>{children}</div>;
}

const pad = (n) => String(n).padStart(2, "0");
export const fmtDate = (d) => {
  if (!d) return "";
  const x = new Date(d);
  return `${pad(x.getDate())}.${pad(x.getMonth() + 1)}.${x.getFullYear()} ${pad(x.getHours())}:${pad(x.getMinutes())}`;
};

export function StatusPill({ status }) {
  const { t } = useI18n();
  return <span className={`pill st-${status}`}>{status === "done" || status === "failed" || status === "queued" || status === "running" ? t(`st.${status}`) : status}</span>;
}
