import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api";
import Icon from "../components/Icon";
import { useI18n } from "../i18n";
import { translateError, translateStage } from "../lang";
import { Alert, Grade, SEV, SeverityBadge, StatusPill, fmtDate } from "../components/ui";

function Finding({ f }) {
  const { t } = useI18n();
  return (
    <li className="finding">
      <details>
        <summary>
          <SeverityBadge level={f.severity} />
          <span className="ftitle">{f.title}</span>
          <span className="floc">{f.file}{f.line ? `:${f.line}` : ""}</span>
        </summary>
        <div className="fbody">
          <div className="meta">
            {f.cwe && <span className="tag">{f.cwe}</span>}
            <span className="tag">{f.language}</span>
            <span className="tag">{t(`cat.${f.category}`) === `cat.${f.category}` ? f.category : t(`cat.${f.category}`)}</span>
            <span className="tag">{t("sc.tool", { v: f.tool })}</span>
            <span className="tag">{t("sc.conf", { v: ["high", "medium", "low"].includes(f.confidence) ? t(`conf.${f.confidence}`) : f.confidence })}</span>
            {f.llm_enhanced ? <span className="tag ai">{t("sc.ai")}</span> : null}
          </div>
          {f.snippet && <pre className="code" tabIndex={0}><code>{f.snippet}</code></pre>}
          <p><strong>{t("sc.why")}</strong> {f.explanation}</p>
          <p><strong>{t("sc.fix")}</strong> {f.fix}</p>
        </div>
      </details>
    </li>
  );
}

export default function Scan() {
  const { t, lang } = useI18n();
  const { id } = useParams();
  const [scan, setScan] = useState(null);
  const [findings, setFindings] = useState([]);
  const [err, setErr] = useState("");
  const [sevs, setSevs] = useState(["high", "medium", "low", "info"]);
  const [flang, setFlang] = useState("");
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");
  const [dq, setDq] = useState("");
  const [dl, setDl] = useState(false);
  const timer = useRef();

  const loadScan = useCallback(async () => {
    try {
      const s = await api.scan(id);
      setScan(s);
      if (s.status === "queued" || s.status === "running") timer.current = setTimeout(loadScan, 1200);
    } catch (e) { setErr(e.message); }
  }, [id]);
  useEffect(() => { loadScan(); return () => clearTimeout(timer.current); }, [loadScan]);
  useEffect(() => { const t = setTimeout(() => setDq(q), 300); return () => clearTimeout(t); }, [q]);

  const done = scan?.status === "done";
  useEffect(() => {
    if (!done) return;
    const params = { severity: sevs.join(","), limit: 1000 };
    if (flang) params.language = flang;
    if (cat) params.category = cat;
    if (dq) params.q = dq;
    api.findings(id, params).then(setFindings).catch((e) => setErr(e.message));
  }, [done, id, sevs, flang, cat, dq, lang]);

  const toggle = (s) => setSevs((cur) => (cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s]));
  const download = async () => { setDl(true); try { await api.downloadReport(id); } catch (e) { setErr(e.message); } finally { setDl(false); } };

  if (!scan) return <div className="page"><Alert>{err}</Alert>{!err && <p className="muted" role="status">{t("app.loading")}</p>}</div>;
  const s = scan.summary || {};
  const sev = s.severity || {};

  return (
    <div className="page">
      <p className="crumb"><Link to={`/projects/${scan.project_id}`}><Icon name="arrowLeft" size={16} />{scan.project_name}</Link></p>
      <div className="row between">
        <div><h1>{t("sc.title", { id: scan.id })}</h1><p className="muted">{fmtDate(scan.created_at)} · <StatusPill status={scan.status} /></p></div>
        {done && <button className="btn primary" onClick={download} disabled={dl}>{dl ? t("sc.pdfBusy") : t("sc.pdf")}</button>}
      </div>
      <Alert>{err}</Alert>

      {(scan.status === "queued" || scan.status === "running") && (
        <section className="card" aria-live="polite">
          <h2>{t("sc.running")}</h2>
          <div className="bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={scan.progress} aria-label={t("sc.progressAria")}><div style={{ width: `${scan.progress}%` }} /></div>
          <p className="muted">{translateStage(scan.stage) || t("sc.queued")} · {scan.progress}%</p>
        </section>
      )}
      {scan.status === "failed" && <Alert>{translateError(scan.error) || t("sc.failed")}</Alert>}

      {done && (
        <>
          <section className="card summary" aria-label={t("sc.summaryAria")}>
            <Grade grade={s.grade} score={s.score} />
            <div className="sevgrid">
              {["high", "medium", "low", "info"].map((k) => (
                <div key={k} className={`sevbox ${SEV[k].cls}`}><strong>{sev[k] || 0}</strong><span>{t(`sev.${k}`)}</span></div>
              ))}
            </div>
            <dl className="facts">
              <div><dt>{t("sc.files")}</dt><dd>{s.files_scanned}</dd></div>
              <div><dt>{t("sc.issues")}</dt><dd>{s.total}</dd></div>
              <div><dt>{t("sc.languages")}</dt><dd>{Object.keys(s.languages || {}).length}</dd></div>
            </dl>
          </section>

          <section className="card" aria-labelledby="langs">
            <h2 id="langs">{t("sc.byLang")}</h2>
            <ul className="langs">
              {Object.entries(s.languages || {}).map(([l, n]) => (
                <li key={l}><strong>{l}</strong><span>{t("sc.langRow", { f: n, n: (s.by_language || {})[l] || 0 })}</span></li>
              ))}
            </ul>
            <p className="muted small">{t("sc.tools")} {Object.entries(s.tools || {}).filter(([k]) => !k.endsWith(":error")).map(([k, v]) => `${k} (${v})`).join(", ") || "—"}{s.llm ? " · " + t("sc.llmOn") : ""}</p>
          </section>

          <section aria-labelledby="fl">
            <h2 id="fl">{t("sc.found", { n: findings.length })}</h2>
            <div className="filters" role="group" aria-label={t("sc.filters")}>
              {["high", "medium", "low", "info"].map((k) => (
                <button key={k} type="button" className={`chip ${SEV[k].cls} ${sevs.includes(k) ? "on" : ""}`} aria-pressed={sevs.includes(k)} onClick={() => toggle(k)}>
                  <span aria-hidden="true">{SEV[k].icon}</span> {t(`sev.${k}`)} · {sev[k] || 0}
                </button>
              ))}
              <select aria-label={t("sc.byLangAria")} value={flang} onChange={(e) => setFlang(e.target.value)}>
                <option value="">{t("sc.allLangs")}</option>
                {Object.keys(s.by_language || {}).map((l) => <option key={l}>{l}</option>)}
              </select>
              <select aria-label={t("sc.byCatAria")} value={cat} onChange={(e) => setCat(e.target.value)}>
                <option value="">{t("sc.allCats")}</option>
                {Object.keys(s.by_category || {}).map((c) => <option key={c} value={c}>{t(`cat.${c}`) === `cat.${c}` ? c : t(`cat.${c}`)}</option>)}
              </select>
              <input type="search" aria-label={t("sc.search")} placeholder={t("sc.searchPh")} value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            {findings.length === 0 ? <div className="card empty"><p>{t(s.total === 0 ? "sc.good" : "sc.noMatch")}</p></div> : (
              <ul className="flist">{findings.map((f) => <Finding key={f.id} f={f} />)}</ul>
            )}
            <p className="muted small">{t("sc.note")}</p>
          </section>
        </>
      )}
    </div>
  );
}
