import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import Icon from "../components/Icon";
import { Alert } from "../components/ui";
import { useI18n } from "../i18n";

function Profile() {
  const { user } = useAuth();
  const { t } = useI18n();
  return (
    <section className="card" aria-labelledby="prof">
      <h2 id="prof" className="ch">{t("set.profile")}</h2>
      <dl style={{ margin: "10px 0 0" }}>
        <div className="setrow"><dt>{t("set.name")}</dt><dd>{user.name}</dd></div>
      </dl>
    </section>
  );
}

function Github() {
  const { user, refresh } = useAuth();
  const { t } = useI18n();
  const [gh, setGh] = useState(null);
  const [sp, setSp] = useSearchParams();
  const [msg, setMsg] = useState({ k: "", t: "" });
  useEffect(() => { api.githubStatus().then(setGh).catch(() => setGh({ enabled: false })); }, []);
  useEffect(() => {  // GitHub-тан оралғаннан кейінгі нәтиже
    const r = sp.get("github");
    if (!r) return;
    setMsg(r === "connected" ? { k: "ok", t: t("set.ghOk") } : { k: "error", t: t(`set.ghErr.${sp.get("reason") || "unknown"}`) });
    setSp({}, { replace: true });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const connect = async () => {
    setMsg({ k: "", t: "" });
    try { window.location.href = (await api.githubStart("/settings")).url; } catch (e) { setMsg({ k: "error", t: e.message }); }
  };
  return (
    <section className="card" aria-labelledby="gh">
      <h2 id="gh" className="ch">{t("set.gh")}</h2>
      <div style={{ marginTop: 10 }}><Alert kind={msg.k || "error"}>{msg.t}</Alert></div>
      <div className="ghrow" style={{ marginTop: 14 }}>
        <span className="tile"><Icon name="github" size={24} /></span>
        {user.github_connected ? (
          <>
            <div style={{ flex: 1 }}><strong>@{user.github_login}</strong><br /><a href={`https://github.com/${user.github_login}`} target="_blank" rel="noopener noreferrer" className="muted small">github.com/{user.github_login}</a></div>
            <button className="btn" onClick={async () => { await api.githubDisconnect(); await refresh(); }}>{t("app.disconnect")}</button>
          </>
        ) : (
          <>
            <div style={{ flex: 1 }}><strong>{t("set.ghNo")}</strong><br /><span className="muted small">{gh && !gh.enabled ? t("set.ghNoCfg") : t("set.ghHint")}</span></div>
            {gh?.enabled && <button className="btn" onClick={connect}>{t("app.connect")}</button>}
          </>
        )}
      </div>
    </section>
  );
}

export default function Settings() {
  const { logout } = useAuth();
  const { t } = useI18n();
  return (
    <div className="page" style={{ maxWidth: 820 }}>
      <div className="pagehead"><div><h1>{t("set.title")}</h1></div></div>
      <Profile />
      <Github />
      <button className="btn" onClick={logout}><Icon name="logout" size={18} />{t("set.logout")}</button>
    </div>
  );
}
