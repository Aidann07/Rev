import { useState } from "react";
import { useAuth } from "../auth";
import { useI18n } from "../i18n";
import { LANGS } from "../lang";
import { Alert } from "../components/ui";

export default function Auth() {
  const { login, register } = useAuth();
  const { t, lang, setLang } = useI18n();
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ email: "", name: "", password: "", teacher_code: "" });
  const [teacher, setTeacher] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      if (mode === "login") await login({ email: f.email, password: f.password });
      else await register({ ...f, teacher_code: teacher ? f.teacher_code : "" });
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  return (
    <main className="auth">
      <div className="card auth-card">
        <select className="authlang" aria-label="Language" value={lang} onChange={(e) => setLang(e.target.value)}>{LANGS.map(([k, n]) => <option key={k} value={k}>{n}</option>)}</select>
        <h1 style={{ fontSize: 28 }}>SecReview AI</h1>
        <p className="muted">{t("auth.tagline")}</p>
        <div className="tabs" role="tablist" aria-label={t("auth.tabs")}>
          <button role="tab" aria-selected={mode === "login"} className={mode === "login" ? "on" : ""} onClick={() => setMode("login")} type="button">{t("auth.login")}</button>
          <button role="tab" aria-selected={mode === "register"} className={mode === "register" ? "on" : ""} onClick={() => setMode("register")} type="button">{t("auth.register")}</button>
        </div>
        <form onSubmit={submit} noValidate>
          {mode === "register" && (
            <label>{t("auth.name")}
              <input value={f.name} onChange={set("name")} autoComplete="name" required />
            </label>
          )}
          <label>{t("auth.email")}
            <input type="email" value={f.email} onChange={set("email")} autoComplete="email" required />
          </label>
          <label>{t("auth.password")} {mode === "register" && <small className="muted">{t("auth.min8")}</small>}
            <input type="password" value={f.password} onChange={set("password")} minLength={8} autoComplete={mode === "login" ? "current-password" : "new-password"} required />
          </label>
          {mode === "register" && (
            <>
              <label className="check"><input type="checkbox" checked={teacher} onChange={(e) => setTeacher(e.target.checked)} /> {t("auth.teacher")}</label>
              {teacher && <label>{t("auth.teacherCode")}<input value={f.teacher_code} onChange={set("teacher_code")} autoComplete="off" /></label>}
            </>
          )}
          <Alert>{err}</Alert>
          <button className="btn primary wide" disabled={busy}>{busy ? t("auth.wait") : mode === "login" ? t("auth.login") : t("auth.register")}</button>
        </form>
      </div>
    </main>
  );
}
