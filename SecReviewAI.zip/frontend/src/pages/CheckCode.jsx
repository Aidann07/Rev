import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import Icon from "../components/Icon";
import ProjectModal from "../components/ProjectModal";
import { useI18n } from "../i18n";
import { Alert, Grade, StatusPill, fmtDate } from "../components/ui";

export default function CheckCode() {
  const { t, lang } = useI18n();
  const nav = useNavigate();
  const [projects, setProjects] = useState(null);
  const [pid, setPid] = useState("");
  const [langs, setLangs] = useState([]);
  const [health, setHealth] = useState(null);
  const [recent, setRecent] = useState([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState(false);

  const load = () => api.projects().then((l) => { setProjects(l); setPid((cur) => cur || (l[0] ? String(l[0].id) : "")); }).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
    api.languages().then((r) => setLangs(r.supported || [])).catch(() => {});
    api.health().then(setHealth).catch(() => {});
    const poll = () => api.recent().then(setRecent).catch(() => {});
    poll(); const t = setInterval(poll, 3000); return () => clearInterval(t);
  }, []);

  const start = async (e) => {
    e.preventDefault(); setBusy(true); setErr("");
    try { const s = await api.startScan(pid); nav(`/scans/${s.id}`); } catch (ex) { setErr(ex.message); setBusy(false); }
  };
  const names = [...new Set(langs.map((l) => l.name || l))];

  return (
    <div className="page">
      <div className="pagehead">
        <div><h1>{t("ck.title")}</h1><p>{t("ck.sub")}</p></div>
      </div>
      <Alert>{err}</Alert>
      <section className="card" aria-labelledby="chk">
        <h2 id="chk" className="ch">{t("ck.new")}</h2>
        {projects && projects.length === 0 ? (
          <p className="muted">{t("ck.addFirst")} <button type="button" className="link" onClick={() => setModal(true)}>{t("pr.add")}</button></p>
        ) : (
          <form className="check-form" onSubmit={start}>
            <label>{t("ck.project")}
              <select value={pid} onChange={(e) => setPid(e.target.value)} required>
                {(projects || []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </label>
            <button className="btn primary" disabled={busy || !pid}><Icon name="shield" size={18} />{busy ? t("pj.starting") : t("pr.scan")}</button>
          </form>
        )}
        <p className="muted small" style={{ marginBottom: 0 }}>
          {t(health?.llm ? "ck.llmOn" : "ck.llmOff")} {t("ck.noExec")}
        </p>
      </section>
      <section className="card" aria-labelledby="sl">
        <h2 id="sl" className="ch">{t("ck.langs")}</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 10 }}>{names.map((n) => <span key={n} className="chip2">{n}</span>)}</div>
      </section>
      <section className="card" aria-labelledby="rc">
        <h2 id="rc" className="ch">{t("ck.recent")}</h2>
        {recent.length === 0 && <p className="muted">{t("ck.none")}</p>}
        {recent.map((s) => (
          <Link key={s.id} to={`/scans/${s.id}`} className="progress-row">
            <span style={{ flex: 1 }}><strong>{s.project_name}</strong><br /><span className="muted small">{fmtDate(s.created_at)}</span></span>
            {s.status === "done" ? <><span className="muted small">{t("dash.issuesN", { n: s.total })}</span><Grade grade={s.grade} score={s.score} compact /></>
              : s.status === "failed" ? <StatusPill status="failed" />
              : <><div className="bar" role="progressbar" aria-valuenow={s.progress} aria-valuemin={0} aria-valuemax={100} aria-label={t("ck.progress")}><div style={{ width: `${s.progress}%` }} /></div><span className="muted small">{s.progress}%</span></>}
          </Link>
        ))}
      </section>
      {modal && <ProjectModal onClose={() => setModal(false)} onSaved={() => { setModal(false); load(); }} />}
    </div>
  );
}
