import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import Icon from "../components/Icon";
import { useI18n } from "../i18n";
import { translateError } from "../lang";
import { Alert, Grade, StatusPill, fmtDate } from "../components/ui";

export default function Project() {
  const { id } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const { t } = useI18n();
  const [p, setP] = useState(null);
  const [scans, setScans] = useState([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => Promise.all([api.project(id), api.projectScans(id)]).then(([a, b]) => { setP(a); setScans(b); }).catch((e) => setErr(e.message)), [id]);
  useEffect(() => { load(); }, [load]);

  const start = async () => {
    setBusy(true); setErr("");
    try { const s = await api.startScan(id); nav(`/scans/${s.id}`); } catch (e) { setErr(e.message); setBusy(false); }
  };
  const del = async () => {
    if (!window.confirm(t("pr.confirmDel", { name: p?.name || "" }))) return;
    try { await api.deleteProject(id); nav("/projects"); } catch (e) { setErr(e.message); }
  };

  if (!p) return <div className="page"><Alert>{err}</Alert>{!err && <p className="muted" role="status">{t("app.loading")}</p>}</div>;
  return (
    <div className="page">
      <p className="crumb"><Link to="/projects"><Icon name="arrowLeft" size={16} />{t("pj.back")}</Link></p>
      <div className="row between">
        <div>
          <h1>{p.name}</h1>
          <p className="muted">{p.description ? p.description + " · " : ""}{p.source_type === "github" ? p.repo_url : t("pr.zip")}{user.role === "teacher" && <> · {p.owner_name}</>}</p>
        </div>
        {user.role !== "teacher" && (
          <div className="row gap">
            <button className="btn primary" onClick={start} disabled={busy}>{busy ? t("pj.starting") : t("pr.scan")}</button>
            <button className="btn danger" onClick={del}>{t("pr.delete")}</button>
          </div>
        )}
      </div>
      <Alert>{err}</Alert>
      <h2>{t("pj.history")}</h2>
      {scans.length === 0 ? <div className="card empty"><p>{t("pj.noScans")}</p></div> : (
        <ul className="plist">
          {scans.map((s) => (
            <li key={s.id} className="card pitem">
              <div>
                <Link to={`/scans/${s.id}`} className="ptitle">{t("pj.scanN", { id: s.id })}</Link>
                <div className="muted small">{fmtDate(s.created_at)}{s.status === "done" && <> · {t("pj.issuesFiles", { n: s.summary.total, f: s.summary.files_scanned })}</>}{s.status === "failed" && <> · {translateError(s.error)}</>}</div>
              </div>
              {s.status === "done" ? <Grade grade={s.summary.grade} score={s.summary.score} /> : <StatusPill status={s.status} />}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
