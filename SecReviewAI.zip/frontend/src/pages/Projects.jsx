import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import Icon from "../components/Icon";
import { shortName } from "../components/AdvisorPicker";
import ProjectModal from "../components/ProjectModal";
import { useDropdown } from "../components/Header";
import { useI18n } from "../i18n";
import { Alert, fmtDate } from "../components/ui";

function Card({ p, teacher, onEdit, onDelete, onScan }) {
  const { t } = useI18n();
  const [open, setOpen, ref] = useDropdown();
  const nav = useNavigate();
  const ls = p.last_scan;
  const sev = ls?.status === "done" ? ls.summary?.severity || {} : null;
  const vulns = sev ? (sev.high || 0) + (sev.medium || 0) + (sev.low || 0) : null;
  const status = ls ? ls.status : null;
  return (
    <article className="card pcard">
      <div className="phead">
        <span className="tile t-blue"><Icon name="folder" size={26} /></span>
        <div className="grow">
          <Link to={`/projects/${p.id}`} className="ptitle" style={{ textDecoration: "none" }}>{p.name}</Link>
          <p className="pdesc">{p.description || (p.source_type === "github" ? p.repo_url.replace("https://github.com/", t("pr.gh")) : t("pr.zip"))}</p>
        </div>
        <span className={`pstat s-${status || "none"}`}>{t(`st.${status || "none"}`)}</span>
      </div>
      <dl className="pbody">
        <div className="prow"><dt>{t("pr.language")}</dt><dd>{p.languages?.length ? p.languages.join(", ") : "—"}</dd></div>
        <div className="prow"><dt>{t("pr.advisors")}</dt><dd>{p.advisors?.length ? p.advisors.map((a) => <span key={a} className="chip2" title={a}>{shortName(a)}</span>) : "—"}</dd></div>
        {teacher && <div className="prow"><dt>{t("pr.student")}</dt><dd>{p.owner_name}</dd></div>}
        <div className="prow"><dt>{t("pr.lastCheck")}</dt><dd>{ls?.finished_at ? fmtDate(ls.finished_at).split(" ")[0] : "—"}</dd></div>
        <div className="prow"><dt>{t("pr.vulns")}</dt><dd>{vulns === null ? "—" : vulns}</dd></div>
      </dl>
      <div className="pfoot">
        <button className="btn" onClick={() => nav(`/projects/${p.id}`)}>{t("pr.open")}</button>
        {!teacher && (
          <div className="menuwrap" ref={ref}>
            <button className="iconbtn" onClick={() => setOpen(!open)} aria-label={t("pr.actions", { name: p.name })} aria-expanded={open}><Icon name="dots" /></button>
            {open && (
              <div className="dropdown">
                <button className="mi" onClick={() => { setOpen(false); onScan(p); }}><Icon name="play" size={17} />{t("pr.scan")}</button>
                <button className="mi" onClick={() => { setOpen(false); onEdit(p); }}><Icon name="pencil" size={17} />{t("pr.edit")}</button>
                <button className="mi red" onClick={() => { setOpen(false); onDelete(p); }}><Icon name="trash" size={17} />{t("pr.delete")}</button>
              </div>
            )}
          </div>
        )}
      </div>
    </article>
  );
}

export default function Projects() {
  const { user } = useAuth();
  const { t } = useI18n();
  const nav = useNavigate();
  const teacher = user.role === "teacher";
  const [list, setList] = useState(null);
  const [err, setErr] = useState("");
  const [modal, setModal] = useState(null); // null | "new" | project
  const [sp] = useSearchParams();
  const load = () => api.projects().then(setList).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  const scan = async (p) => { try { const s = await api.startScan(p.id); nav(`/scans/${s.id}`); } catch (e) { setErr(e.message); } };
  const del = async (p) => {
    if (!window.confirm(t("pr.confirmDel", { name: p.name }))) return;
    try { await api.deleteProject(p.id); load(); } catch (e) { setErr(e.message); }
  };

  return (
    <div className="page">
      <div className="pagehead">
        <div>
          <h1>{t(teacher ? "pr.titleTeacher" : "pr.title")}</h1>
          <p>{t("pr.sub")}</p>
        </div>
        {!teacher && <button className="btn primary" onClick={() => setModal("new")}><Icon name="plus" size={18} />{t("pr.add")}</button>}
      </div>
      {sp.get("github") === "connected" && <Alert kind="ok">{t("pr.ghOk")}</Alert>}
      {sp.get("github") === "error" && <Alert>{t(`set.ghErr.${sp.get("reason") || "unknown"}`)}</Alert>}
      <Alert>{err}</Alert>
      {list === null ? <p className="muted" role="status">{t("app.loading")}</p> : list.length === 0 ? (
        <div className="card" style={{ textAlign: "center", padding: 40 }}>
          <h2 style={{ marginTop: 0 }}>{t("pr.emptyTitle")}</h2>
          <p className="muted">{t(teacher ? "pr.emptyTeacher" : "pr.emptyStudent")}</p>
        </div>
      ) : list.map((p) => <Card key={p.id} p={p} teacher={teacher} onEdit={setModal} onDelete={del} onScan={scan} />)}
      {modal && <ProjectModal project={modal === "new" ? null : modal} onClose={() => setModal(null)} onSaved={() => { setModal(null); load(); }} />}
    </div>
  );
}
