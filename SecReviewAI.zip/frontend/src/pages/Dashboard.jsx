import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import Icon from "../components/Icon";
import { useI18n } from "../i18n";
import { Alert, Grade, SEV, SeverityBadge, StatusPill, fmtDate } from "../components/ui";

function Delta({ v, goodWhenDown }) {
  const { t } = useI18n();
  if (!v) return null;
  const up = v > 0;
  const good = goodWhenDown ? !up : up;
  return <span className={`delta ${good ? "up" : "down"}`} title={up ? t("dash.up") : t("dash.down")}>{up ? "↑" : "↓"} {Math.abs(v)}</span>;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { t, lang } = useI18n();
  const nav = useNavigate();
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api.dashboard().then(setD).catch((e) => setErr(e.message)); }, [lang]);
  const teacher = user.role === "teacher";
  const first = (user.name || "").split(/\s+/)[0];
  const h = new Date().getHours();
  const greet = t(h < 5 ? "dash.night" : h < 12 ? "dash.morning" : h < 18 ? "dash.day" : "dash.evening");
  const st = d?.stats;
  const cards = st && [
    { icon: "cap", cls: "t-blue", label: t(teacher ? "dash.statProjectsT" : "dash.statProjects"), s: st.projects },
    { icon: "clipboard", cls: "t-purple", label: t("dash.statScans"), s: st.scans },
    { icon: "alert", cls: "t-red", label: t("dash.statFound"), s: st.findings, goodWhenDown: true },
    { icon: "check", cls: "t-green", label: t("dash.statFixed"), s: st.fixed },
  ];
  const sev = d?.severity || {};
  const maxSev = Math.max(1, ...["high", "medium", "low", "info"].map((k) => sev[k] || 0));

  return (
    <div className="page">
      <div className="pagehead">
        <div>
          <h1>{greet}, {first}</h1>
          <p>{t(teacher ? "dash.subTeacher" : "dash.sub")}</p>
        </div>
        {!teacher && <button className="btn primary" onClick={() => nav("/check")}><Icon name="shield" size={18} />{t("nav.check")}</button>}
      </div>
      <Alert>{err}</Alert>
      {!d && !err && <p className="muted" role="status">{t("app.loading")}</p>}
      {d && (
        <>
          <section className="stats" aria-label={t("dash.stats")}>
            {cards.map((c) => (
              <Link key={c.label} to="/projects" className="card stat">
                <span className={`tile ${c.cls}`}><Icon name={c.icon} size={24} /></span>
                <span>
                  <span className="lbl">{c.label}</span>
                  <span className="val">{c.s.value}<Delta v={c.s.delta} goodWhenDown={c.goodWhenDown} /></span>
                </span>
                <Icon name="chevron" size={18} className="go" />
              </Link>
            ))}
          </section>
          {d.recent.length === 0 ? (
            <div className="card" style={{ textAlign: "center", padding: 40, marginTop: 16 }}>
              <h2 style={{ marginTop: 0 }}>{t("dash.emptyTitle")}</h2>
              <p className="muted">{t(teacher ? "dash.emptyTeacher" : "dash.emptyStudent")}</p>
              {!teacher && <Link to="/projects" className="btn primary" style={{ textDecoration: "none" }}><Icon name="plus" size={18} />{t("dash.addProject")}</Link>}
            </div>
          ) : (
            <div className="cols" style={{ marginTop: 16 }}>
              <section className="card" aria-labelledby="rec">
                <h2 id="rec" className="ch">{t("dash.recent")}</h2>
                {d.recent.map((s) => (
                  <Link key={s.id} to={`/scans/${s.id}`} className="srow">
                    <span className="grow"><span className="nm">{s.project_name}</span><br /><span className="muted small">{fmtDate(s.finished_at || s.created_at)}</span></span>
                    {s.status === "done" ? <><span className="muted small">{t("dash.issuesN", { n: s.total })}</span><Grade grade={s.grade} score={s.score} compact /></> : <StatusPill status={s.status} />}
                  </Link>
                ))}
              </section>
              <div>
                <section className="card" aria-labelledby="sv">
                  <h2 id="sv" className="ch">{t("dash.severity")}</h2>
                  {["high", "medium", "low", "info"].map((k) => (
                    <div key={k} className="sbar"><span>{t(`sev.${k}`)}</span><span className="track"><i className={`fill-${k}`} style={{ width: `${((sev[k] || 0) / maxSev) * 100}%` }} /></span><b>{sev[k] || 0}</b></div>
                  ))}
                  <p className="muted small" style={{ marginBottom: 0 }}>{t("dash.severityNote")}</p>
                </section>
                {d.top_issues.length > 0 && (
                  <section className="card" aria-labelledby="top">
                    <h2 id="top" className="ch">{t("dash.top")}</h2>
                    {d.top_issues.map((x) => (
                      <div key={x.rule_id} className="srow"><span className="grow">{x.title}</span><SeverityBadge level={x.severity} /><b>{x.count}</b></div>
                    ))}
                  </section>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
