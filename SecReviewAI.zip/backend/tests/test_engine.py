"""Талдау қозғалтқышының тесттері: әр тілге оң және теріс жағдай."""
from pathlib import Path

import pytest

from app.analysis.orchestrator import run_analysis


def scan(tmp_path: Path, files: dict[str, str]):
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return run_analysis(tmp_path)


def ids(findings):
    return {f.rule_id for f in findings}


def test_python_vulns(tmp_path):
    f, _ = scan(tmp_path, {"a.py": 'import os\nos.system("ls " + x)\neval(y)\ncur.execute("SELECT * FROM t WHERE id=" + i)\n'})
    assert {"PY-OSSYS", "PY-EVAL", "PY-SQLI"} <= ids(f)


def test_python_safe_code_clean(tmp_path):
    f, s = scan(tmp_path, {"a.py": 'import json\ncur.execute("SELECT * FROM t WHERE id=?", (i,))\nx = json.loads(s)\n'})
    assert not [x for x in f if x.severity in ("high", "medium")]


def test_js_html_css(tmp_path):
    f, _ = scan(tmp_path, {
        "a.js": 'el.innerHTML = location.hash;\neval(code);\n',
        "i.html": '<html><head></head><body><a href="x" target="_blank">x</a><form method="post"><input name="a"></form></body></html>',
        "s.css": '@import url("http://x.com/a.css");\n',
    })
    r = ids(f)
    assert {"JS-INNERHTML", "JS-EVAL", "HTML-BLANK", "HTML-CSRF", "CSS-IMPORT"} <= r


def test_html_csrf_not_flagged_when_token_present(tmp_path):
    f, _ = scan(tmp_path, {"i.html": '<form method="post"><input type="hidden" name="csrf_token" value="x"></form>'})
    assert "HTML-CSRF" not in ids(f)


def test_blank_with_noopener_ok(tmp_path):
    f, _ = scan(tmp_path, {"i.html": '<a href="x" target="_blank" rel="noopener noreferrer">x</a>'})
    assert "HTML-BLANK" not in ids(f)


def test_java_and_sql(tmp_path):
    f, _ = scan(tmp_path, {
        "D.java": 'class D { void f(){ st.executeQuery("SELECT * FROM t WHERE n=\'" + name + "\'"); MessageDigest.getInstance("MD5"); } }',
        "s.sql": "GRANT ALL ON *.* TO a;\nDELETE FROM users;\n",
    })
    assert {"JV-SQLI", "JV-HASH", "SQL-GRANT", "SQL-NOWHERE-DEL"} <= ids(f)


def test_sql_delete_with_where_ok(tmp_path):
    f, _ = scan(tmp_path, {"s.sql": "DELETE FROM users WHERE id = 3;\n"})
    assert "SQL-NOWHERE-DEL" not in ids(f)


def test_php_go_ruby_c(tmp_path):
    f, _ = scan(tmp_path, {
        "a.php": '<?php echo $_GET["q"]; eval($x);',
        "m.go": 'tls.Config{InsecureSkipVerify: true}',
        "a.rb": 'eval(params[:c])',
        "a.c": 'void f(){\n char b[8];\n gets(b);\n strcpy(b, s);\n}',
    })
    assert {"PHP-XSS", "PHP-EVAL", "GO-TLS", "RB-EVAL", "C-GETS", "C-STRCPY"} <= ids(f)


def test_secrets_detected_and_masked(tmp_path):
    f, _ = scan(tmp_path, {"c.py": 'KEY = "AKIAIOSFODNN7EXAMPLE"\napi_key = "abcd1234efgh5678"\n'})
    secs = [x for x in f if x.category == "secrets"]
    assert secs
    for x in secs:  # құпияның толық мәні есепке түспеуі тиіс
        assert "AKIAIOSFODNN7EXAMPLE" not in x.snippet and "abcd1234efgh5678" not in x.snippet


def test_placeholder_secret_ignored(tmp_path):
    f, _ = scan(tmp_path, {"c.py": 'password = "changeme"\napi_key = os.environ["K"]\nsecret = "${SECRET}"\n'})
    assert not [x for x in f if x.category == "secrets"]


def test_env_file_flagged(tmp_path):
    f, _ = scan(tmp_path, {".env": "DB_PASSWORD=realvalue\n", ".env.example": "DB_PASSWORD=\n"})
    assert [x.file for x in f if x.rule_id == "SEC-FILE"] == [".env"]


def test_dependencies(tmp_path):
    f, _ = scan(tmp_path, {
        "requirements.txt": "requests==2.25.0\nflask>=3.0\n",
        "package.json": '{"dependencies": {"lodash": "^4.17.15", "express": "4.19.2"}}',
        "pom.xml": "<project><dependencies><dependency><groupId>org.apache.logging.log4j</groupId><artifactId>log4j-core</artifactId><version>2.14.1</version></dependency></dependencies></project>",
    })
    r = ids(f)
    assert {"DEP-CVE-2023-32681", "DEP-CVE-2021-23337", "DEP-CVE-2021-44228"} <= r
    assert not any("express" in x.title and x.rule_id.startswith("DEP-CVE") for x in f)  # 4.19.2 — түзетілген


def test_dockerfile(tmp_path):
    f, _ = scan(tmp_path, {"Dockerfile": "FROM python:latest\nRUN curl http://x | sh\n"})
    assert {"DK-ROOT", "DK-LATEST", "SH-CURLPIPE"} <= ids(f)


def test_comment_lines_skipped_for_code_rules(tmp_path):
    f, _ = scan(tmp_path, {"a.py": "# eval(x)\n", "b.js": "// eval(x)\n"})
    assert not ids(f) & {"PY-EVAL", "JS-EVAL"}


def test_skips_node_modules_and_symlink_safe(tmp_path):
    f, s = scan(tmp_path, {"node_modules/x/a.js": "eval(1)", "ok.js": "var a = 1;"})
    assert s["files_scanned"] == 1


def test_score_and_summary(tmp_path):
    f, s = scan(tmp_path, {"ok.py": "x = 1\n"})
    assert s["score"] == 100 and s["grade"] == "A" and s["total"] == 0
    f, s = scan(tmp_path / "bad", {"a.py": "eval(x)\nos.system(y)\n"})
    assert s["score"] < 100 and s["severity"]["high"] >= 2


# ---- Нақты жобаларда өлшеуден шыққан регрессия тесттері ----
def test_no_sqli_false_positive_on_cipher_update(tmp_path):
    f, _ = scan(tmp_path, {"a.js": 'const x = `${cipher.update(t, "utf8", "hex")} ${cipher.final("hex")}`;\nrouter.get(`/${page}`, h);\n'})
    assert not ids(f) & {"JS-SQLI", "JS-SQLI2"}


def test_regex_exec_not_command_injection(tmp_path):
    f, _ = scan(tmp_path, {"a.js": "const m = re.exec(text);\nconst n = /a/.exec(s);\n"})
    assert "JS-CMD" not in ids(f)
    f, _ = scan(tmp_path / "b", {"a.js": "exec(`ls ${dir}`);\nchild_process.exec('ls ' + d);\n"})
    assert "JS-CMD" in ids(f)


def test_escaped_output_not_flagged_xss(tmp_path):
    f, _ = scan(tmp_path, {"a.js": "res.send('user ' + escapeHtml(req.params.uid));\nres.send(req.query.q);\n"})
    assert [x.line for x in f if x.rule_id == "JS-XSSREQ"] == [2]


def test_thymeleaf_form_not_flagged_csrf(tmp_path):
    f, _ = scan(tmp_path, {"a.html": '<form th:object="${o}" method="post"><input name="a"></form>'})
    assert "HTML-CSRF" not in ids(f)


def test_npmrc_without_token_not_flagged(tmp_path):
    f, _ = scan(tmp_path, {".npmrc": "package-lock=false\n"})
    assert "SEC-FILE" not in ids(f)
    f, _ = scan(tmp_path / "t", {".npmrc": "//registry.npmjs.org/:_authToken=abcd1234efgh\n"})
    assert "SEC-FILE" in ids(f)


def test_sql_password_is_masked_in_snippet(tmp_path):
    f, _ = scan(tmp_path, {"u.sql": "CREATE USER IF NOT EXISTS 'petclinic'@'%' IDENTIFIED BY 'hunter2pass';\n"})
    snips = " ".join(x.snippet for x in f)
    assert "hunter2pass" not in snips


def test_test_files_capped_and_excluded_from_score(tmp_path):
    f, s = scan(tmp_path, {"tests/test_a.py": "eval(x)\nos.system(y)\n"})
    assert f and all(x.severity in ("low", "info") for x in f)
    assert s["score"] == 100 and "тест" in f[0].title
    # нақты токен тестте де толық қауіптілікте қалады
    f, _ = scan(tmp_path / "x", {"tests/test_b.py": 'K = "AKIAIOSFODNN7EXAMPLE"\n'})
    assert any(x.severity == "high" and x.rule_id == "SEC-AWS" for x in f)


def test_helmet_is_project_level_once(tmp_path):
    files = {f"src/r{i}.js": "const express = require('express');\nconst app = express();\n" for i in range(5)}
    f, _ = scan(tmp_path, files)
    assert [x.rule_id for x in f].count("JS-HELMET") == 1
    f, _ = scan(tmp_path / "ok", {"app.js": "const express = require('express');\nconst helmet = require('helmet');\n"})
    assert "JS-HELMET" not in ids(f)


def test_bandit_assert_ignored(tmp_path):
    f, _ = scan(tmp_path, {"a.py": "assert x == 1\n"})
    assert "BANDIT-B101" not in ids(f)
