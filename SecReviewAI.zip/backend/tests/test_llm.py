"""LLM қабаты: нақты API-сыз, жалған клиентпен. Қате болса білім қоры мәтіні қалуы тиіс."""
import sys
import types
from types import SimpleNamespace as NS

from app.config import settings
from app.services import llm


def finding(**kw):
    base = dict(category="code", severity="high", language="Python", title="SQL", cwe="CWE-89", file="a.py", line=1,
                snippet="x", explanation="БАСТАПҚЫ", fix="БАСТАПҚЫ-FIX", llm_enhanced=0)
    base.update(kw)
    return NS(**base)


def fake_anthropic(reply=None, raises=False, calls=None):
    class Msgs:
        def create(self, **kw):
            if calls is not None:
                calls.append(kw)
            if raises:
                raise RuntimeError("quota")
            return NS(content=[NS(type="text", text=reply)])
    mod = types.ModuleType("anthropic")
    mod.Anthropic = lambda **kw: NS(messages=Msgs())
    return mod


def test_disabled_without_key(monkeypatch):
    monkeypatch.setattr(settings, "anthropic_api_key", "")
    f = finding()
    assert llm.enhance([f]) == 0 and f.explanation == "БАСТАПҚЫ"


def test_enhance_parses_json_and_skips_secrets(monkeypatch):
    calls = []
    monkeypatch.setattr(settings, "anthropic_api_key", "k")
    monkeypatch.setitem(sys.modules, "anthropic", fake_anthropic('мәтін {"explanation": "ЖАҢА", "fix": "ЖАҢА-FIX"} аяғы', calls=calls))
    code, secret, low = finding(), finding(category="secrets", title="Құпия"), finding(severity="low")
    n = llm.enhance([code, secret, low])
    assert n == 1 and code.explanation == "ЖАҢА" and code.fix == "ЖАҢА-FIX" and code.llm_enhanced == 1
    assert secret.explanation == "БАСТАПҚЫ"          # құпиялар LLM-ге жіберілмейді
    assert low.explanation == "БАСТАПҚЫ"             # тек жоғары/орташа
    assert len(calls) == 1


def test_enhance_falls_back_on_error_and_bad_json(monkeypatch):
    monkeypatch.setattr(settings, "anthropic_api_key", "k")
    monkeypatch.setitem(sys.modules, "anthropic", fake_anthropic(raises=True))
    f = finding()
    assert llm.enhance([f]) == 0 and f.explanation == "БАСТАПҚЫ" and f.llm_enhanced == 0
    monkeypatch.setitem(sys.modules, "anthropic", fake_anthropic("json емес жауап"))
    assert llm.enhance([f]) == 0 and f.explanation == "БАСТАПҚЫ"
