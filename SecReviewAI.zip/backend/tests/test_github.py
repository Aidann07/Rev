"""GitHub: сілтемелерді өңдеу, OAuth (GitHub жауаптары имитацияланған), репозиторийлер, токен қауіпсіздігі, .venv сүзгісі."""
import io
import time
import urllib.error
import urllib.parse
import zipfile

import pytest
from fastapi.testclient import TestClient

from app.config import settings
from app.main import app
from app.security import create_token
from app.services import repo as repomod
from app.services.repo import RepoError, normalize_github_url

c = TestClient(app)
_n = 0


def reg():
    global _n
    _n += 1
    r = c.post("/api/auth/register", json={"email": f"gh{_n}{int(time.time()*1000)}@t.kz", "name": "Тест", "password": "password123"})
    return r.json()["token"], {"Authorization": "Bearer " + r.json()["token"]}


@pytest.fixture(autouse=True)
def oauth_on(monkeypatch):
    monkeypatch.setattr(settings, "github_client_id", "cid")
    monkeypatch.setattr(settings, "github_client_secret", "csecret")


def state_from(url):
    return urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["state"][0]


@pytest.mark.parametrize("url,expected", [
    ("https://github.com/u/r", "https://github.com/u/r.git"), ("github.com/u/r/", "https://github.com/u/r.git"),
    ("www.github.com/u/r.git", "https://github.com/u/r.git"), ("git@github.com:u/r.git", "https://github.com/u/r.git"),
    ("https://github.com/u/r/tree/dev/src", "https://github.com/u/r.git#dev"), ("https://github.com/u/r?tab=x#y", "https://github.com/u/r.git"),
])
def test_url_forms(url, expected):
    assert normalize_github_url(url) == expected


@pytest.mark.parametrize("bad", ["https://evil.com/u/r", "https://github.com.evil.com/u/r", "https://github.com/u", "file:///etc/passwd",
                                 "https://github.com/u/r/tree/-x", "", "https://github.com/../r", "https://github.com/u/r/../.."])
def test_url_rejected(bad):
    with pytest.raises(RepoError):
        normalize_github_url(bad)


def test_start_requires_login_and_state_is_not_a_login_token():
    assert c.post("/api/auth/github/start").status_code == 401
    _, h = reg()
    url = c.post("/api/auth/github/start?next=/projects", headers=h).json()["url"]
    assert url.startswith("https://github.com/login/oauth/authorize?") and "client_id=cid" in url and "redirect_uri=" in url
    state = state_from(url)
    # state кіру токені ретінде жарамайды
    assert c.get("/api/auth/me", headers={"Authorization": "Bearer " + state}).status_code == 401
    # URL арқылы токен беру енді жоқ
    assert c.get("/api/auth/me?access_token=" + state).status_code == 401
    assert "github.com/login" not in c.get("/api/auth/github/login?access_token=x", follow_redirects=False).headers.get("location", "")


def test_oauth_success_and_encrypted_token(monkeypatch):
    _, h = reg()
    state = state_from(c.post("/api/auth/github/start?next=/projects", headers=h).json()["url"])
    seen = {}

    def fake(url, data=None, headers=None):
        seen[url] = (data, headers)
        return {"access_token": "gho_SECRET123"} if "access_token" in url else {"login": "aibek-n"}
    monkeypatch.setattr("app.routers.auth._http_json", fake)
    r = c.get(f"/api/auth/github/callback?code=abc&state={state}", follow_redirects=False)
    assert r.status_code in (302, 307) and r.headers["location"].endswith("/projects?github=connected")
    me = c.get("/api/auth/me", headers=h).json()
    assert me["github_connected"] and me["github_login"] == "aibek-n"
    # токен дерекқорда ашық күйде тұрмайды
    from app.database import SessionLocal
    from app.models import User
    with SessionLocal() as db:
        enc = db.get(User, me["id"]).github_token_enc
    assert enc and "gho_SECRET123" not in enc
    assert b"redirect_uri" in seen["https://github.com/login/oauth/access_token"][0]


@pytest.mark.parametrize("gh_error,reason", [("incorrect_client_credentials", "credentials"), ("bad_verification_code", "code"),
                                              ("redirect_uri_mismatch", "redirect"), ("whatever", "unknown")])
def test_oauth_errors_redirect_with_reason(monkeypatch, gh_error, reason):
    _, h = reg()
    state = state_from(c.post("/api/auth/github/start", headers=h).json()["url"])
    monkeypatch.setattr("app.routers.auth._http_json", lambda *a, **k: {"error": gh_error})
    r = c.get(f"/api/auth/github/callback?code=abc&state={state}", follow_redirects=False)
    assert f"github=error" in r.headers["location"] and f"reason={reason}" in r.headers["location"]
    assert not c.get("/api/auth/me", headers=h).json()["github_connected"]


def test_oauth_denied_bad_state_and_network(monkeypatch):
    _, h = reg()
    state = state_from(c.post("/api/auth/github/start", headers=h).json()["url"])
    r = c.get(f"/api/auth/github/callback?error=access_denied&state={state}", follow_redirects=False)
    assert "reason=denied" in r.headers["location"]
    r = c.get("/api/auth/github/callback?code=abc&state=garbage", follow_redirects=False)
    assert "reason=session" in r.headers["location"]
    expired = create_token(1, purpose="gh", minutes=-1)
    assert "reason=session" in c.get(f"/api/auth/github/callback?code=a&state={expired}", follow_redirects=False).headers["location"]
    # кіру токенін state ретінде беру — қабылданбайды
    tok, _ = reg()
    assert "reason=session" in c.get(f"/api/auth/github/callback?code=a&state={tok}", follow_redirects=False).headers["location"]

    def boom(*a, **k):
        raise OSError("no network")
    monkeypatch.setattr("app.routers.auth._http_json", boom)
    state = state_from(c.post("/api/auth/github/start", headers=h).json()["url"])
    assert "reason=network" in c.get(f"/api/auth/github/callback?code=a&state={state}", follow_redirects=False).headers["location"]


def _connect(monkeypatch, h):
    state = state_from(c.post("/api/auth/github/start", headers=h).json()["url"])
    monkeypatch.setattr("app.routers.auth._http_json", lambda url, *a, **k: {"access_token": "gho_x"} if "access_token" in url else {"login": "u"})
    c.get(f"/api/auth/github/callback?code=a&state={state}", follow_redirects=False)


def test_repos_pagination_and_revoked_token(monkeypatch):
    _, h = reg()
    _connect(monkeypatch, h)
    pages = {1: [{"full_name": f"u/r{i}", "html_url": f"https://github.com/u/r{i}", "private": i % 2 == 0, "language": "Python"} for i in range(100)],
             2: [{"full_name": "u/last", "html_url": "https://github.com/u/last", "private": False, "language": None}]}

    def fake(url, *a, **k):
        return pages[int(urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["page"][0])]
    monkeypatch.setattr("app.routers.auth._http_json", fake)
    repos = c.get("/api/auth/github/repos", headers=h).json()
    assert len(repos) == 101 and repos[-1]["name"] == "u/last"

    def revoked(*a, **k):
        raise urllib.error.HTTPError("u", 401, "Bad credentials", {}, io.BytesIO(b"{}"))
    monkeypatch.setattr("app.routers.auth._http_json", revoked)
    r = c.get("/api/auth/github/repos", headers=h)
    assert r.status_code == 409
    assert not c.get("/api/auth/me", headers=h).json()["github_connected"]  # рұқсат өшірілді, қайта қосу керек


def test_disconnect_clears_token(monkeypatch):
    _, h = reg()
    _connect(monkeypatch, h)
    assert c.get("/api/auth/me", headers=h).json()["github_connected"]
    monkeypatch.setattr("urllib.request.urlopen", lambda *a, **k: (_ for _ in ()).throw(OSError("offline")))  # GitHub қолжетімсіз болса да істейді
    assert c.delete("/api/auth/github", headers=h).status_code == 200
    assert not c.get("/api/auth/me", headers=h).json()["github_connected"]


def test_clone_token_is_scoped_to_github_and_hidden(tmp_path, monkeypatch):
    monkeypatch.setenv("GIT_CONFIG_COUNT", "1")                                # сыртқы баптау (мысалы, прокси) сақталуы керек
    monkeypatch.setenv("GIT_CONFIG_KEY_0", "http.proxy")
    monkeypatch.setenv("GIT_CONFIG_VALUE_0", "http://p:3128")
    env = repomod._git_env(tmp_path / "x", "gho_TOKEN")
    assert env["GIT_CONFIG_COUNT"] == "2" and env["GIT_CONFIG_KEY_0"] == "http.proxy"
    assert env["GIT_CONFIG_KEY_1"] == "http.https://github.com/.extraheader"   # басқа хосттарға жіберілмейді
    assert "gho_TOKEN" not in " ".join(env.values())                          # токен ашық күйде емес (base64)
    clean = repomod._git_env(tmp_path / "x", "")
    assert clean["GIT_CONFIG_COUNT"] == "1" and "extraheader" not in " ".join(v for k, v in clean.items() if k.startswith("GIT_CONFIG_KEY_0"))


def test_clone_falls_back_when_branch_or_token_is_bad(monkeypatch, tmp_path):
    calls = []

    def fake(url, branch, dest, token):
        calls.append((branch, bool(token)))
        if branch == "nope":
            return 128, "fatal: Remote branch nope not found in upstream origin"
        if token:
            return 128, "remote: Invalid username or password. fatal: Authentication failed"
        dest.mkdir(parents=True, exist_ok=True)
        (dest / "a.py").write_text("x=1")
        return 0, ""
    monkeypatch.setattr(repomod, "_git_clone", fake)
    repomod.clone_repo("https://github.com/u/r/tree/nope", tmp_path / "s", token="old")
    assert calls == [("nope", True), ("", True), ("", False)] and (tmp_path / "s" / "a.py").exists()


@pytest.mark.parametrize("stderr,expect", [
    ("fatal: unable to access: Could not resolve host: github.com", "байланыс орнамады"),
    ("remote: Repository not found.\nfatal: repository 'x' not found", "табылмады немесе жеке"),
    ("fatal: could not read Username for 'https://github.com'", "табылмады немесе жеке"),
])
def test_clone_error_messages(monkeypatch, tmp_path, stderr, expect):
    monkeypatch.setattr(repomod, "_git_clone", lambda *a: (128, stderr))
    with pytest.raises(RepoError, match=expect):
        repomod.clone_repo("https://github.com/u/r", tmp_path / "s")


def test_venv_and_vendor_dirs_are_not_scanned_and_bandit_is_localized(tmp_path):
    from app.analysis.orchestrator import run_analysis
    (tmp_path / "app.py").write_text("import requests\nr = requests.get(url)\n")   # Bandit B113 (timeout жоқ)
    for venv in (".venv", "myenv", "proj_env"):
        d = tmp_path / "backend" / venv / "Lib" / "site-packages" / "pkg"
        d.mkdir(parents=True)
        (d / "bad.py").write_text("import pickle\npickle.loads(x)\neval(y)\n")
        (tmp_path / "backend" / venv / "pyvenv.cfg").write_text("home = x")
    findings, summary = run_analysis(tmp_path, lambda p, s: None)
    assert {f.file for f in findings} == {"app.py"}
    from app.analysis import i18n
    b113 = [f for f in findings if f.rule_id == "BANDIT-B113"]
    if b113:  # Bandit орнатылған болса
        assert b113[0].title == "HTTP сұранысында timeout көрсетілмеген"
        assert i18n.title("BANDIT-B113", b113[0].title, "en") == "HTTP request without a timeout"
