import io
import time
import zipfile

import pytest
from fastapi.testclient import TestClient

from app.database import init_db
from app.main import app

init_db()
client = TestClient(app)


def make_zip(files: dict) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in files.items():
            z.writestr(k, v)
    return b.getvalue()


def register(email, role_code=""):
    r = client.post("/api/auth/register", json={"email": email, "name": "Айдана", "password": "password123", "teacher_code": role_code})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}, r.json()["user"]


def wait_scan(h, sid, timeout=60):
    for _ in range(timeout * 4):
        d = client.get(f"/api/scans/{sid}", headers=h).json()
        if d["status"] in ("done", "failed"):
            return d
        time.sleep(0.25)
    raise AssertionError("scan timeout")


def test_health():
    assert client.get("/api/health").json()["status"] == "ok"


def test_auth_flow_and_validation():
    h, u = register("a@x.kz")
    assert u["role"] == "student"
    assert client.post("/api/auth/register", json={"email": "a@x.kz", "name": "x", "password": "password123"}).status_code == 409
    assert client.post("/api/auth/login", json={"email": "a@x.kz", "password": "wrongwrong"}).status_code == 401
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/auth/me", headers=h).json()["email"] == "a@x.kz"
    assert client.post("/api/auth/register", json={"email": "t@x.kz", "name": "T", "password": "password123", "teacher_code": "bad"}).status_code == 403


def test_full_scan_flow_and_pdf():
    h, _ = register("s1@x.kz")
    z = make_zip({"proj/app.py": 'import os\nos.system("x" + a)\n', "proj/index.html": '<a target="_blank" href="x">x</a>',
                  "proj/schema.sql": "GRANT ALL ON *.* TO a;"})
    r = client.post("/api/projects/upload", headers=h, data={"name": "Диплом"}, files={"file": ("p.zip", z, "application/zip")})
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    sc = client.post(f"/api/projects/{pid}/scans", headers=h)
    assert sc.status_code == 200
    d = wait_scan(h, sc.json()["id"])
    assert d["status"] == "done", d
    assert d["summary"]["files_scanned"] == 3
    assert set(d["summary"]["languages"]) == {"Python", "HTML", "SQL"}
    fs = client.get(f"/api/scans/{d['id']}/findings", headers=h).json()
    assert {x["rule_id"] for x in fs} >= {"PY-OSSYS", "HTML-BLANK", "SQL-GRANT"}
    assert all(x["explanation"] and x["fix"] for x in fs)
    assert fs[0]["severity"] == "high"  # қауіптілік бойынша сұрыпталған
    only_py = client.get(f"/api/scans/{d['id']}/findings", headers=h, params={"language": "Python"}).json()
    assert only_py and all(x["language"] == "Python" for x in only_py)
    pdf = client.get(f"/api/scans/{d['id']}/report.pdf", headers=h)
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF" and len(pdf.content) > 3000
    # токен URL арқылы қабылданбайды (тек Authorization тақырыбы)
    tok = h["Authorization"].split()[1]
    assert client.get(f"/api/scans/{d['id']}/report.pdf", params={"access_token": tok}).status_code == 401


def test_access_control_between_students_and_teacher():
    h1, _ = register("own@x.kz")
    h2, _ = register("other@x.kz")
    ht, u = register("teach@x.kz", "teach-123")
    assert u["role"] == "teacher"
    z = make_zip({"a.py": "eval(x)"})
    pid = client.post("/api/projects/upload", headers=h1, data={"name": "P"}, files={"file": ("p.zip", z)}).json()["id"]
    assert client.get(f"/api/projects/{pid}", headers=h2).status_code == 404       # бөтен студент көре алмайды
    assert client.post(f"/api/projects/{pid}/scans", headers=h2).status_code == 404
    assert client.get(f"/api/projects/{pid}", headers=ht).status_code == 200        # оқытушы көре алады
    assert client.post(f"/api/projects/{pid}/scans", headers=ht).status_code == 403  # бірақ скан іске қоспайды
    assert client.get("/api/teacher/projects", headers=h1).status_code == 403
    assert client.get("/api/teacher/projects", headers=ht).status_code == 200


def test_bad_inputs():
    h, _ = register("bad@x.kz")
    assert client.post("/api/projects", headers=h, json={"name": "x", "repo_url": "https://evil.com/a/b"}).status_code == 422
    assert client.post("/api/projects", headers=h, json={"name": "x", "repo_url": "file:///etc/passwd"}).status_code == 422
    assert client.post("/api/projects/upload", headers=h, data={"name": "x"}, files={"file": ("a.txt", b"x")}).status_code == 422
    pid = client.post("/api/projects/upload", headers=h, data={"name": "broken"}, files={"file": ("a.zip", b"notazip")}).json()["id"]
    sid = client.post(f"/api/projects/{pid}/scans", headers=h).json()["id"]
    d = wait_scan(h, sid)
    assert d["status"] == "failed" and "ZIP" in d["error"]


def test_zip_slip_blocked(tmp_path):
    from app.services.repo import extract_zip
    zp = tmp_path / "evil.zip"
    with zipfile.ZipFile(zp, "w") as z:
        z.writestr("../../escaped.txt", "pwn")
        z.writestr("ok.py", "x=1")
    dest = tmp_path / "out" / "src"
    extract_zip(zp, dest)
    assert (dest / "ok.py").exists()
    assert not (tmp_path / "escaped.txt").exists() and not (tmp_path.parent / "escaped.txt").exists()


def test_github_token_encrypted_at_rest():
    from app.crypto import decrypt, encrypt
    c = encrypt("ghp_secret_token_value")
    assert "ghp_secret" not in c and decrypt(c) == "ghp_secret_token_value"
    assert decrypt("garbage") == ""
