import os
import tempfile

_tmp = tempfile.mkdtemp(prefix="secreview_test_")
os.environ["DATA_DIR"] = _tmp
os.environ["TEACHER_CODE"] = "teach-123"
os.environ.pop("DATABASE_URL", None)
os.environ.pop("REDIS_URL", None)
os.environ.pop("ANTHROPIC_API_KEY", None)
