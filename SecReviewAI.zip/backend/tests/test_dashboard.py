"""Басты бет, жоба метадеректері, профиль және ескі дерекқорды миграциялау."""
import io
import time
import zipfile

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, inspect, text

from app.database import SessionLocal, init_db
from app.main import app
from app.models import Finding, Project, Scan, User, now

init_db()
client = TestClient(app)


def reg(email, name="Айбек Нұрланұлы", code=""):
    r = client.post("/api/auth/register", json={"email": email, "name": name, "password": "password123", "teacher_code": code})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}, r.json()["user"]["id"]


def zipbytes(files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in files.items():
            z.writestr(k, v)
    return b.getvalue()


def test_project_metadata_roundtrip_and_patch():
    h, _ = reg("meta@x.kz")
    r = client.post("/api/projects/upload", headers=h, data={"name": "Кітапхана", "description": "Веб-жүйе", "advisors": "Дана Сәрсенова, Марат Иманов, Дана Сәрсенова"},
                    files={"file": ("p.zip", zipbytes({"a.py": "x=1", "b.html": "<p>x</p>"}))})
    p = r.json()
    assert p["description"] == "Веб-жүйе" and p["advisors"] == ["Дана Сәрсенова", "Марат Иманов"]  # қайталану жойылды
    sid = client.post(f"/api/projects/{p['id']}/scans", headers=h).json()["id"]
    for _ in range(100):
        if client.get(f"/api/scans/{sid}", headers=h).json()["status"] in ("done", "failed"):
            break
        time.sleep(0.1)
    p = client.get(f"/api/projects/{p['id']}", headers=h).json()
    assert p["languages"][:2] == ["Python", "HTML"] or set(p["languages"]) == {"Python", "HTML"}
    up = client.patch(f"/api/projects/{p['id']}", headers=h, json={"name": "Жаңа ат", "advisors": ["A", "B"]}).json()
    assert up["name"] == "Жаңа ат" and up["advisors"] == ["A", "B"] and up["description"] == "Веб-жүйе"
    other, _ = reg("meta2@x.kz")
    assert client.patch(f"/api/projects/{p['id']}", headers=other, json={"name": "x"}).status_code == 404


def test_profile_and_password():
    h, _ = reg("prof@x.kz")
    assert client.patch("/api/auth/me", headers=h, json={"name": "Жаңа Аты"}).json()["name"] == "Жаңа Аты"
    reg("taken@x.kz")
    assert client.patch("/api/auth/me", headers=h, json={"email": "taken@x.kz"}).status_code == 409
    assert client.patch("/api/auth/me", headers=h, json={"email": "bad"}).status_code == 422
    assert client.patch("/api/auth/me", headers=h, json={"email": "NEW@x.kz"}).json()["email"] == "new@x.kz"
    assert client.post("/api/auth/password", headers=h, json={"current": "wrong", "new": "newpassword1"}).status_code == 403
    assert client.post("/api/auth/password", headers=h, json={"current": "password123", "new": "newpassword1"}).status_code == 200
    assert client.post("/api/auth/login", json={"email": "new@x.kz", "password": "password123"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "new@x.kz", "password": "newpassword1"}).status_code == 200


def _seed_two_scans(uid):
    """Қолмен екі скан: екіншісінде бір осалдық түзетілген, бірі қалған, бірі жаңа."""
    db = SessionLocal()
    p = Project(owner_id=uid, name="Seed", source_type="zip", zip_path="", advisors=[])
    db.add(p); db.commit()
    def mk(sev, items):
        s = Scan(project_id=p.id, status="done", progress=100, summary={"severity": sev, "grade": "C", "score": 60}, finished_at=now())
        db.add(s); db.commit()
        for f, rid, sn in items:
            db.add(Finding(scan_id=s.id, file=f, line=1, rule_id=rid, title=rid, severity="high", snippet=sn))
        db.commit()
        return s
    mk({"high": 3, "medium": 0, "low": 0, "info": 0}, [("a.py", "R1", "eval(x)"), ("b.py", "R2", "os.system(y)"), ("c.py", "R3", "md5(z)")])
    mk({"high": 2, "medium": 0, "low": 0, "info": 0}, [("b.py", "R2", "os.system(y)"), ("d.py", "R4", "exec(q)")])
    db.close()
    return p.id


def test_dashboard_stats_are_computed_from_real_data():
    h, uid = reg("dash@x.kz")
    assert client.get("/api/dashboard", headers=h).json()["stats"]["projects"]["value"] == 0
    _seed_two_scans(uid)
    d = client.get("/api/dashboard", headers=h).json()
    st = d["stats"]
    assert st["projects"] == {"value": 1, "delta": 1}
    assert st["scans"]["value"] == 2
    assert st["findings"] == {"value": 2, "delta": -1}      # 3 -> 2
    assert st["fixed"] == {"value": 2, "delta": 2}          # R1 және R3 түзетілді (R4 жаңа, R2 қалды)
    assert d["severity"]["high"] == 2 and len(d["recent"]) == 2 and d["recent"][0]["grade"] == "C"
    assert {t["rule_id"] for t in d["top_issues"]} == {"R2", "R4"}


def test_dashboard_isolated_per_student_and_visible_to_teacher():
    h1, u1 = reg("iso1@x.kz")
    h2, _ = reg("iso2@x.kz")
    ht, _ = reg("iso_t@x.kz", code="teach-123")
    _seed_two_scans(u1)
    assert client.get("/api/dashboard", headers=h2).json()["stats"]["projects"]["value"] == 0
    assert client.get("/api/scans/recent", headers=h2).json() == []
    assert client.get("/api/dashboard", headers=ht).json()["stats"]["projects"]["value"] >= 1
    assert client.get("/api/scans/recent", headers=h1).status_code == 200  # /scans/{id}-мен шатаспайды


def test_migration_adds_columns_to_old_database(tmp_path, monkeypatch):
    import app.database as dbm
    eng = create_engine(f"sqlite:///{tmp_path/'old.db'}")
    with eng.begin() as c:
        c.execute(text("CREATE TABLE projects (id INTEGER PRIMARY KEY, owner_id INT, name VARCHAR(200), source_type VARCHAR(20), repo_url VARCHAR(500), zip_path VARCHAR(500), created_at DATETIME)"))
    monkeypatch.setattr(dbm, "engine", eng)
    dbm._migrate()
    cols = {c["name"] for c in inspect(eng).get_columns("projects")}
    assert {"description", "advisors"} <= cols
    dbm._migrate()  # қайта шақыру қауіпсіз


def test_findings_and_pdf_are_localized(tmp_path):
    from app.analysis import i18n
    assert i18n.title("PY-EVAL", "eval()/exec() қолданылған", "ru") == "Используется eval()/exec()"
    assert i18n.title("PY-EVAL", "eval()/exec() қолданылған", "en") == "eval()/exec() used"
    assert i18n.title("PY-EVAL", "eval()/exec() қолданылған", "kk") == "eval()/exec() қолданылған"
    assert i18n.title("HTML-ALT", "3 суретте alt атрибуты жоқ", "en") == "3 images have no alt attribute"
    assert i18n.title("DEP-CVE-2021-44228", "Осал кітапхана: log4j-core 2.14 — Log4Shell: қашықтан код орындау (RCE)", "ru").startswith("Уязвимая библиотека: log4j-core 2.14")
    from app.analysis.kb import KB
    why, fix = KB["sqli"]
    assert i18n.texts(why, fix, "en", False)[0].startswith("User data is placed")
    assert i18n.texts(why, fix, "en", True) == (why, fix)   # LLM мәтіні өзгермейді
    assert i18n.texts("белгісіз", "белгісіз", "ru", False) == ("белгісіз", "белгісіз")
    # барлық ереже мен білім қорының аудармасы бар
    from app.analysis import rules
    from app.analysis.i18n_kb import RU, EN
    assert set(KB) == set(RU) == set(EN)
    assert {r.id for r in rules.RULES} <= set(i18n.T_RU) & set(i18n.T_EN)


def test_advisors_seeded_searchable_and_teacher_can_add():
    h, _ = reg("adv1@x.kz")
    assert client.get("/api/advisors").status_code == 401
    allv = client.get("/api/advisors", headers=h).json()
    assert len(allv) == 50 and len({a["name"] for a in allv}) == 50
    assert all(a["position"] and a["department"] for a in allv)
    first = allv[0]["name"].split()[0]
    found = client.get("/api/advisors", params={"q": first[:5].lower()}, headers=h).json()
    assert found and all(first[:5].lower() in (a["name"] + a["department"] + a["position"]).lower() for a in found)
    assert client.get("/api/advisors", params={"q": "жоқ-жоқ-жоқ"}, headers=h).json() == []
    assert client.get("/api/advisors", params={"q": "ҚАЛИ"}, headers=h).json()                # регистр маңызды емес
    assert client.get("/api/advisors", params={"q": "%"}, headers=h).json() == []
    # студент қоса алмайды, оқытушы қосады, қайталануға болмайды
    assert client.post("/api/advisors", json={"name": "Жаңа Оқытушы Тест"}, headers=h).status_code == 403
    ht, _ = reg("adv-t@x.kz", code="teach-123")
    assert client.post("/api/advisors", json={"name": "Жаңа  Оқытушы   Тест", "position": "Доцент"}, headers=ht).status_code == 201
    assert client.post("/api/advisors", json={"name": "Жаңа Оқытушы Тест"}, headers=ht).status_code == 409
    assert len(client.get("/api/advisors", headers=h).json()) == 51


def test_advisor_seed_is_not_repeated_and_added_to_old_db(tmp_path, monkeypatch):
    from app import database
    from app.models import Advisor
    database._seed_advisors()                       # екінші рет шақырғанда қайталанбайды
    with database.SessionLocal() as db:
        n = db.query(Advisor).count()
    database._seed_advisors()
    with database.SessionLocal() as db:
        assert db.query(Advisor).count() == n


def test_project_can_store_selected_advisors():
    h, _ = reg("adv2@x.kz")
    names = [a["name"] for a in client.get("/api/advisors", headers=h).json()[:2]]
    r = client.post("/api/projects/upload", headers=h, data={"name": "P", "advisors": ", ".join(names)},
                    files={"file": ("a.zip", zipbytes({"a.py": "x=1"}), "application/zip")})
    assert r.status_code == 200 and r.json()["advisors"] == names
