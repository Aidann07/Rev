"""Жол бойынша жұмыс істейтін ережелер (регекс). Көп тілді."""
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    severity: str
    cwe: str
    kind: str            # kb.py кілті
    langs: tuple         # тілдер тізімі; ("*",) — барлығы
    pattern: re.Pattern
    confidence: str = "medium"
    category: str = "code"


def R(id, title, sev, cwe, kind, langs, pat, conf="medium", flags=0, cat="code"):
    if isinstance(langs, str):
        langs = (langs,)
    return Rule(id, title, sev, cwe, kind, tuple(langs), re.compile(pat, flags), conf, cat)


JS = ("JavaScript", "TypeScript", "HTML")
JSONLY = ("JavaScript", "TypeScript")
SQLWORDS = r"\b(SELECT\s+[\w*.,\s`\"\[\]()]{1,80}?\s+FROM|INSERT\s+INTO|UPDATE\s+[\w.`\"\[\]]+\s+SET|DELETE\s+FROM)\b"

RULES: list[Rule] = [
    # ---------------- Python ----------------
    R("PY-EVAL", "eval()/exec() қолданылған", "high", "CWE-95", "codei", "Python", r"(?<![\w.])(eval|exec)\s*\(", "medium"),
    R("PY-PICKLE", "pickle арқылы десериализация", "high", "CWE-502", "deser", "Python", r"\b(c?[Pp]ickle|dill|shelve)\.(loads?|Unpickler)\s*\("),
    R("PY-YAML", "yaml.load қауіпсіз емес жүктеушімен", "high", "CWE-502", "deser", "Python",
      r"\byaml\.load\s*\((?!.*Loader\s*=\s*(yaml\.)?(Safe|CSafe)Loader)"),
    R("PY-SHELL", "subprocess shell=True қолданылған", "high", "CWE-78", "cmdi", "Python", r"\bsubprocess\.\w+\(.*shell\s*=\s*True"),
    R("PY-OSSYS", "os.system/os.popen қолданылған", "high", "CWE-78", "cmdi", "Python", r"\bos\.(system|popen)\s*\("),
    R("PY-SQLI", "SQL сұрауы жол біріктіру/f-string арқылы құрылған", "high", "CWE-89", "sqli", "Python",
      r"\.(execute|executemany|executescript|raw)\s*\(\s*(f[\"']|[\"'][^\"']*[\"']\s*(%|\+|\.format)|[A-Za-z_]\w*\s*\+)", "medium"),
    R("PY-SQLI2", "SQL жолына айнымалы f-string арқылы қосылған", "high", "CWE-89", "sqli", "Python",
      r"\bf[\"'][^\"']*" + SQLWORDS + r"[^\"']*\{[^}]+\}", "medium", re.I),
    R("PY-DEBUG", "Debug режимі қосулы", "medium", "CWE-489", "debug", "Python", r"(\.run\(.*debug\s*=\s*True|^\s*DEBUG\s*=\s*True)"),
    R("PY-HASH", "Әлсіз хэш алгоритмі (MD5/SHA-1)", "medium", "CWE-327", "weakcrypto", "Python", r"\bhashlib\.(md5|sha1)\s*\(", "medium"),
    R("PY-NOVERIFY", "TLS сертификатын тексеру өшірілген", "medium", "CWE-295", "tls", "Python", r"\bverify\s*=\s*False"),
    R("PY-RANDOM", "Кездейсоқ сан токен/пароль үшін қолданылуы мүмкін", "low", "CWE-338", "weakrand", "Python",
      r"\b(token|secret|password|passwd|otp|session)\w*\s*=.*\brandom\.(random|randint|choice|choices|getrandbits)\(", "low", re.I),
    R("PY-JWT", "JWT қолтаңбасы тексерілмейді", "high", "CWE-347", "jwt", "Python",
      r"(verify_signature[\"']?\s*:\s*False|algorithms\s*=\s*\[\s*[\"']none[\"']|verify\s*=\s*False.*jwt|jwt\.decode\([^)]*verify\s*=\s*False)", "medium", re.I),
    R("PY-CORS", "CORS барлық домендерге ашық", "medium", "CWE-942", "cors", "Python", r"allow_origins\s*=\s*\[\s*[\"']\*[\"']\s*\]|CORS_ORIGIN_ALLOW_ALL\s*=\s*True"),
    R("PY-TMPL", "render_template_string пайдаланушы деректерімен (SSTI/XSS)", "medium", "CWE-1336", "xss", "Python", r"\brender_template_string\s*\(", "low"),
    R("PY-MARKUP", "Markup()/mark_safe экрандаусыз шығарады", "medium", "CWE-79", "xss", "Python", r"\b(Markup|mark_safe)\s*\(", "low"),
    R("PY-BIND", "Сервер барлық интерфейсте тыңдайды (0.0.0.0)", "low", "CWE-668", "misconfig", "Python", r"host\s*=\s*[\"']0\.0\.0\.0[\"']", "low"),
    R("PY-XML", "XML талдағыш XXE-ге осал болуы мүмкін", "medium", "CWE-611", "xxe", "Python", r"\bxml\.(etree\.ElementTree|dom\.minidom|sax)\b.*\b(parse|fromstring)|\blxml\.etree\.(parse|fromstring)", "low"),
    R("PY-TEMPFILE", "Қауіпсіз емес уақытша файл (mktemp)", "low", "CWE-377", "misconfig", "Python", r"\btempfile\.mktemp\s*\("),

    # ---------------- JavaScript / TypeScript / HTML ----------------
    R("JS-EVAL", "eval()/new Function қолданылған", "high", "CWE-95", "codei", JS, r"(?<![\w.])eval\s*\(|\bnew\s+Function\s*\(", "medium"),
    R("JS-INNERHTML", "innerHTML/outerHTML-ге мән меншіктелген (XSS)", "medium", "CWE-79", "xss", JS, r"\.(innerHTML|outerHTML)\s*\+?=(?!=)"),
    R("JS-INSERTHTML", "insertAdjacentHTML қолданылған (XSS)", "medium", "CWE-79", "xss", JS, r"\.insertAdjacentHTML\s*\(", "low"),
    R("JS-DOCWRITE", "document.write қолданылған (XSS)", "medium", "CWE-79", "xss", JS, r"\bdocument\.write(ln)?\s*\("),
    R("JS-REACT", "dangerouslySetInnerHTML қолданылған", "medium", "CWE-79", "xss", JS, r"dangerouslySetInnerHTML"),
    R("JS-VHTML", "v-html директивасы (XSS)", "medium", "CWE-79", "xss", ("HTML", "JavaScript", "TypeScript"), r"\bv-html\s*=|\[innerHTML\]\s*="),
    R("JS-JQHTML", "jQuery .html() пайдаланушы деректерімен", "low", "CWE-79", "xss", JS, r"\$\([^)]*\)\.(html|append|prepend|after|before)\s*\(\s*[^\"')\s][^)]*(location|input|val\(\)|params|query)", "low"),
    R("JS-TIMER", "setTimeout/setInterval жол ретінде код орындайды", "medium", "CWE-95", "codei", JS, r"\bset(Timeout|Interval)\s*\(\s*[\"'`]"),
    R("JS-CMD", "child_process.exec қолданылған", "high", "CWE-78", "cmdi", JSONLY, r"((?<![\w.])exec(Sync)?|\b(child_process|cp)\.exec(Sync)?)\s*\(\s*([`\"'].*(\$\{|\+)|[a-zA-Z_]\w*\s*[,)])", "medium"),
    R("JS-SQLI", "SQL сұрауы жол біріктіру/шаблон арқылы құрылған", "high", "CWE-89", "sqli", JSONLY,
      r"\.(query|execute|raw)\s*\(\s*(`[^`]*\$\{|[\"'][^\"']*[\"']\s*\+)", "medium"),
    R("JS-SQLI2", "SQL жолына айнымалы қосылған", "high", "CWE-89", "sqli", JSONLY, SQLWORDS + r"[^\"'`;]*[\"'`]\s*\+\s*\w+|`[^`]*" + SQLWORDS + r"[^`]*\$\{", "medium", re.I),
    R("JS-STORAGE", "Токен/пароль localStorage-та сақталады", "medium", "CWE-922", "storage", JS,
      r"(localStorage|sessionStorage)\.setItem\(\s*[\"'`][^\"'`]*(token|jwt|password|auth|secret)", "medium", re.I),
    R("JS-TLS", "TLS тексеру өшірілген", "medium", "CWE-295", "tls", JSONLY, r"rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*[\"']?0"),
    R("JS-CORS", "CORS барлық домендерге ашық", "medium", "CWE-942", "cors", JSONLY,
      r"Access-Control-Allow-Origin[\"'`]?\s*[,:]\s*[\"'`]\*|\bcors\(\s*\)|origin\s*:\s*[\"'`]\*[\"'`]"),
    R("JS-POSTMSG", "postMessage maqsat-origin '*'", "medium", "CWE-345", "xss", JS, r"postMessage\([^)]*,\s*[\"']\*[\"']\s*\)"),
    R("JS-JWT", "JWT 'none' алгоритмі немесе тексерусіз декодтау", "high", "CWE-347", "jwt", JSONLY, r"algorithms?\s*:\s*\[?\s*[\"']none[\"']|jwt\.decode\(", "low"),
    R("JS-REDIR", "Пайдаланушы деректерімен қайта бағыттау", "medium", "CWE-601", "redirect", JSONLY,
      r"(res\.redirect|window\.location(\.href)?\s*=|location\.replace)\s*\(?\s*(req\.(query|params|body)|.*location\.(search|hash))"),
    R("JS-PATH", "Файл жолы сұраныс деректерінен құрылған", "high", "CWE-22", "path", JSONLY,
      r"\bfs\.\w+\(\s*[^)]*req\.(params|query|body)|path\.(join|resolve)\([^)]*req\.(params|query|body)"),
    R("JS-LOGSENS", "Құпия мәлімет консольға/логқа жазылады", "low", "CWE-532", "infoleak", JSONLY, r"console\.(log|info|debug)\(.*(password|token|secret|apikey)", "low", re.I),
    R("JS-MATHRAND", "Math.random токен үшін қолданылуы мүмкін", "low", "CWE-338", "weakrand", JSONLY, r"\b(token|secret|password|session|id)\w*\s*[:=].*Math\.random\(", "low", re.I),
    R("JS-COOKIE", "Cookie қауіпсіздік белгілерінсіз", "low", "CWE-1004", "session", JS, r"document\.cookie\s*=\s*(?!.*(HttpOnly|Secure))", "low"),
    R("JS-XSSREQ", "Сұраныс деректері res.send арқылы экрандаусыз шығады", "high", "CWE-79", "xss", JSONLY, r"^(?!.*(escape|sanitiz|encodeURI|DOMPurify|\bxss\s*\(|\.toString\(\)|parseInt|Number\()).*res\.send\(\s*[^)]*req\.(query|params|body)", "medium"),
    R("JS-JSURL", "javascript: URL (XSS)", "medium", "CWE-79", "xss", ("HTML", "JavaScript", "TypeScript"), r"(href|src|action)\s*=\s*[\"']\s*javascript:", "medium", re.I),

    # ---------------- Java / Kotlin ----------------
    R("JV-SQLI", "SQL сұрауы жол біріктіру арқылы құрылған", "high", "CWE-89", "sqli", ("Java", "Kotlin"),
      r"\.(executeQuery|executeUpdate|execute|prepareStatement|createQuery|createNativeQuery|query|queryForObject|queryForList)\s*\(\s*(\"[^\"]*\"\s*\+|[A-Za-z_]\w*\s*\+|String\.format|\"[^\"]*\$\{|\"[^\"]*\$[A-Za-z_])", "medium"),
    R("JV-SQLI2", "SQL жолына айнымалы қосылған", "high", "CWE-89", "sqli", ("Java", "Kotlin"), r"\"\s*" + SQLWORDS + r"[^\"]*\"\s*\+\s*\w+", "medium", re.I),
    R("JV-CMD", "Runtime.exec/ProcessBuilder қолданылған", "high", "CWE-78", "cmdi", ("Java", "Kotlin"), r"Runtime\.getRuntime\(\)\.exec\s*\(|new\s+ProcessBuilder\s*\(", "medium"),
    R("JV-DESER", "ObjectInputStream десериализациясы", "high", "CWE-502", "deser", ("Java", "Kotlin"), r"new\s+ObjectInputStream\s*\(|\.readObject\s*\(\)|XMLDecoder\s*\("),
    R("JV-HASH", "Әлсіз хэш/шифр алгоритмі", "medium", "CWE-327", "weakcrypto", ("Java", "Kotlin"),
      r"MessageDigest\.getInstance\(\s*\"(MD5|MD2|SHA-?1)\"|Cipher\.getInstance\(\s*\"(DES|DESede|RC4|RC2|AES/ECB|AES\")"),
    R("JV-RANDOM", "java.util.Random қауіпсіздік үшін жарамайды", "low", "CWE-330", "weakrand", ("Java", "Kotlin"), r"new\s+(java\.util\.)?Random\s*\(", "low"),
    R("JV-XXE", "XML талдағыш XXE-ге осал болуы мүмкін", "medium", "CWE-611", "xxe", ("Java", "Kotlin"),
      r"(DocumentBuilderFactory|SAXParserFactory|XMLInputFactory|TransformerFactory|SAXBuilder)\.newInstance\(\)", "low"),
    R("JV-TLS", "TLS/hostname тексеру өшірілген", "medium", "CWE-295", "tls", ("Java", "Kotlin"),
      r"ALLOW_ALL_HOSTNAME_VERIFIER|TrustAllCerts|setHostnameVerifier\(.*(true|->\s*true)|checkServerTrusted\s*\([^)]*\)\s*\{\s*\}|NoopHostnameVerifier"),
    R("JV-CSRF", "Spring CSRF қорғанысы өшірілген", "medium", "CWE-352", "csrf", ("Java", "Kotlin"), r"csrf\(\)\s*\.\s*disable\(\)|\.csrf\s*\{?\s*it\.disable|csrf\.disable\(\)"),
    R("JV-CORS", "CORS барлық домендерге ашық", "medium", "CWE-942", "cors", ("Java", "Kotlin"), r"@CrossOrigin(\(\s*(origins\s*=\s*)?\"\*\"\s*\))?\s*$|allowedOrigins\(\s*\"\*\"|setAllowedOrigins\(.*\"\*\""),
    R("JV-STACK", "printStackTrace қателер туралы ақпаратты ашады", "low", "CWE-209", "infoleak", ("Java", "Kotlin"), r"\.printStackTrace\s*\(\s*\)"),
    R("JV-PATH", "Файл жолы сұраныс параметрінен құрылған", "high", "CWE-22", "path", ("Java", "Kotlin"), r"new\s+File\([^)]*(getParameter|request\.|@RequestParam|getHeader)", "medium"),
    R("JV-SPEL", "SpEL өрнегін талдау (код орындау қаупі)", "medium", "CWE-917", "codei", ("Java", "Kotlin"), r"SpelExpressionParser|ExpressionParser\s+\w+\s*=", "low"),
    R("JV-REDIR", "Қайта бағыттау сұраныс параметрімен", "medium", "CWE-601", "redirect", ("Java", "Kotlin"), r"sendRedirect\([^)]*(getParameter|request\.)", "medium"),
    R("JV-XSS", "Сұраныс параметрі экрандаусыз жауапқа жазылады", "high", "CWE-79", "xss", ("Java", "Kotlin"), r"(getWriter\(\)\.(print|println|write)|out\.print(ln)?)\([^)]*getParameter", "medium"),
    R("JV-COOKIE", "Cookie HttpOnly/Secure белгісіз", "low", "CWE-1004", "session", ("Java", "Kotlin"), r"new\s+Cookie\(", "low"),

    # ---------------- SQL ----------------
    R("SQL-GRANT", "GRANT ALL — артық құқық", "medium", "CWE-269", "sqlperm", "SQL", r"\bGRANT\s+ALL\b", "medium", re.I),
    R("SQL-HOST", "Пайдаланушыға кез келген хосттан кіруге рұқсат ('%')", "medium", "CWE-284", "sqlperm", "SQL", r"CREATE\s+USER\s+[^;]*@\s*['\"]%['\"]|GRANT\s+[^;]*@\s*['\"]%['\"]", "medium", re.I),
    R("SQL-PASS", "SQL файлында пароль ашық жазылған", "high", "CWE-798", "secrets", "SQL",
      r"(IDENTIFIED\s+BY|PASSWORD\s*[=(]?|WITH\s+PASSWORD)\s*['\"][^'\"]{3,}['\"]", "medium", re.I, "secrets"),
    R("SQL-DYN", "Динамикалық SQL жол біріктіру арқылы (EXEC)", "high", "CWE-89", "sqli", "SQL",
      r"\bEXEC(UTE)?\s*\(?\s*(@\w+|['\"][^'\"]*['\"]\s*\+)|sp_executesql\s+@\w+|PREPARE\s+\w+\s+FROM\s+(CONCAT|@)", "medium", re.I),
    R("SQL-NOWHERE-DEL", "WHERE жоқ DELETE (барлық жолдарды өшіреді)", "medium", "CWE-1284", "sqlwhere", "SQL",
      r"^\s*DELETE\s+FROM\s+[\w.`\"\[\]]+\s*;", "medium", re.I),
    R("SQL-NOWHERE-UPD", "WHERE жоқ UPDATE (барлық жолдарды өзгертеді)", "medium", "CWE-1284", "sqlwhere", "SQL",
      r"^\s*UPDATE\s+[\w.`\"\[\]]+\s+SET\s+[^;]*;(?<!WHERE)", "low", re.I),
    R("SQL-PWCOL", "Пароль бағаны жай мәтін болуы мүмкін", "low", "CWE-256", "weakcrypto", "SQL",
      r"\b(password|passwd|pwd)\s+(varchar|char|text)\s*(\(\s*\d{1,2}\s*\))?", "low", re.I),
    R("SQL-SUPER", "SUPERUSER/DBA құқығы беріледі", "medium", "CWE-250", "sqlperm", "SQL", r"\b(SUPERUSER|WITH\s+GRANT\s+OPTION|db_owner|sysadmin)\b", "low", re.I),

    # ---------------- PHP ----------------
    R("PHP-EVAL", "eval/assert арқылы код орындау", "high", "CWE-95", "codei", "PHP", r"\b(eval|assert|create_function)\s*\(", "medium"),
    R("PHP-CMD", "Жүйелік команда орындалады", "high", "CWE-78", "cmdi", "PHP", r"\b(system|exec|shell_exec|passthru|popen|proc_open|pcntl_exec)\s*\("),
    R("PHP-INCLUDE", "include/require пайдаланушы деректерімен (LFI/RFI)", "high", "CWE-98", "path", "PHP", r"\b(include|require)(_once)?\s*\(?\s*[^;]*\$_(GET|POST|REQUEST|COOKIE)"),
    R("PHP-XSS", "Пайдаланушы деректері экрандаусыз шығады", "high", "CWE-79", "xss", "PHP",
      r"^(?!.*(htmlspecialchars|htmlentities|intval|\(int\)|esc_html|e\()).*\b(echo|print)\b[^;]*\$_(GET|POST|REQUEST|COOKIE)"),
    R("PHP-SQLI", "SQL сұрауына пайдаланушы деректері тікелей қосылады", "high", "CWE-89", "sqli", "PHP",
      r"(mysqli?_query|->query|->exec|pg_query)\s*\([^;]*(\$_(GET|POST|REQUEST|COOKIE)|\"\s*\.\s*\$|\"[^\"]*\$\w+[^\"]*\")", "medium"),
    R("PHP-SQLI2", "SQL жолына айнымалы қосылған", "high", "CWE-89", "sqli", "PHP", SQLWORDS + r"[^\"';]*[\"']\s*\.\s*\$\w+", "medium", re.I),
    R("PHP-UNSER", "unserialize сенімсіз деректермен", "high", "CWE-502", "deser", "PHP", r"\bunserialize\s*\(\s*\$"),
    R("PHP-HASH", "md5/sha1 пароль үшін қолданылуы мүмкін", "medium", "CWE-327", "weakcrypto", "PHP", r"\b(md5|sha1)\s*\(", "low"),
    R("PHP-EXTRACT", "extract($_GET/$_POST) айнымалыларды қайта жазады", "high", "CWE-621", "misconfig", "PHP", r"\bextract\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)"),
    R("PHP-UPLOAD", "move_uploaded_file — жүктеуді тексеріңіз", "medium", "CWE-434", "upload", "PHP", r"\bmove_uploaded_file\s*\(", "low"),
    R("PHP-ERRORS", "display_errors қосулы", "low", "CWE-209", "debug", "PHP", r"display_errors[\"']?\s*[=,]\s*[\"']?(1|On|true)", "medium", re.I),
    R("PHP-REDIR", "header('Location') пайдаланушы деректерімен", "medium", "CWE-601", "redirect", "PHP", r"header\s*\(\s*[\"']Location:[^)]*\$_(GET|POST|REQUEST)", "medium", re.I),

    # ---------------- C# ----------------
    R("CS-SQLI", "SQL сұрауы жол біріктіру/интерполяция арқылы құрылған", "high", "CWE-89", "sqli", "C#",
      r"(new\s+SqlCommand|CommandText\s*=|FromSqlRaw|ExecuteSqlRaw|ExecuteReader|ExecuteNonQuery)\s*\(?[^;]*(\"\s*\+|\$\")", "medium"),
    R("CS-BINFMT", "BinaryFormatter қауіпсіз емес", "high", "CWE-502", "deser", "C#", r"\bBinaryFormatter\b|\bNetDataContractSerializer\b|TypeNameHandling\.(All|Auto|Objects)"),
    R("CS-PROC", "Process.Start қолданылған", "medium", "CWE-78", "cmdi", "C#", r"\bProcess\.Start\s*\(", "low"),
    R("CS-HASH", "Әлсіз хэш алгоритмі", "medium", "CWE-327", "weakcrypto", "C#", r"\b(MD5|SHA1)(CryptoServiceProvider)?\.Create\(\)|new\s+(MD5|SHA1)CryptoServiceProvider|\bDESCryptoServiceProvider\b"),
    R("CS-VALID", "Сұранысты тексеру өшірілген", "medium", "CWE-20", "misconfig", "C#", r"ValidateRequest\s*=\s*\"?false|\[ValidateInput\(\s*false\s*\)\]"),
    R("CS-TLS", "Сертификатты тексеру өшірілген", "medium", "CWE-295", "tls", "C#", r"ServerCertificateValidationCallback\s*[+]?=.*(true|=>\s*true)|DangerousAcceptAnyServerCertificateValidator"),
    R("CS-XSS", "Html.Raw экрандаусыз шығарады", "medium", "CWE-79", "xss", "C#", r"@?Html\.Raw\s*\(", "low"),

    # ---------------- Go ----------------
    R("GO-SQLI", "SQL сұрауы fmt.Sprintf/біріктіру арқылы құрылған", "high", "CWE-89", "sqli", "Go",
      r"\.(Query|QueryRow|Exec|QueryContext|ExecContext)\w*\(\s*(\w+,\s*)?(fmt\.Sprintf|\"[^\"]*\"\s*\+)", "medium"),
    R("GO-EXEC", "exec.Command shell немесе айнымалымен", "medium", "CWE-78", "cmdi", "Go", r"exec\.Command\(\s*(\"(sh|bash|cmd)\"|[a-z_]\w*\s*[,)])", "low"),
    R("GO-TLS", "InsecureSkipVerify: true", "medium", "CWE-295", "tls", "Go", r"InsecureSkipVerify\s*:\s*true"),
    R("GO-HASH", "Әлсіз хэш (md5/sha1)", "medium", "CWE-327", "weakcrypto", "Go", r"\b(md5|sha1)\.(New|Sum)\s*\(|\"crypto/(md5|sha1|des|rc4)\""),
    R("GO-RAND", "math/rand қауіпсіздік үшін жарамайды", "low", "CWE-338", "weakrand", "Go", r"\"math/rand\"", "low"),
    R("GO-BIND", "Барлық интерфейсте тыңдайды", "low", "CWE-668", "misconfig", "Go", r"ListenAndServe\(\s*\"0\.0\.0\.0", "low"),

    # ---------------- Ruby ----------------
    R("RB-EVAL", "eval/instance_eval/class_eval", "high", "CWE-95", "codei", "Ruby", r"\b(eval|instance_eval|class_eval|module_eval)\b\s*[\(\"'#a-z]", "medium"),
    R("RB-CMD", "Жүйелік команда интерполяциямен", "high", "CWE-78", "cmdi", "Ruby", r"\b(system|exec|spawn)\s*\(?.*#\{|`[^`]*#\{|%x[\(\{\[].*#\{"),
    R("RB-SQLI", "SQL сұрауына интерполяция", "high", "CWE-89", "sqli", "Ruby", r"\b(where|find_by_sql|execute|select|order|joins)\s*\(\s*\"[^\"]*#\{"),
    R("RB-DESER", "Marshal.load / YAML.load", "high", "CWE-502", "deser", "Ruby", r"\b(Marshal\.load|YAML\.load)\s*\("),
    R("RB-XSS", "html_safe/raw экрандауды өшіреді", "medium", "CWE-79", "xss", "Ruby", r"\.html_safe\b|\braw\s*\(?\s*@?\w+", "low"),

    # ---------------- C / C++ ----------------
    R("C-GETS", "gets() — буфер асып кетуі", "high", "CWE-120", "bufoverflow", ("C", "C++"), r"(?<![\w.])gets\s*\("),
    R("C-STRCPY", "Қауіпсіз емес функция (strcpy/strcat/sprintf)", "high", "CWE-120", "bufoverflow", ("C", "C++"), r"(?<![\w.])(strcpy|strcat|sprintf|vsprintf|stpcpy)\s*\("),
    R("C-SYSTEM", "system() қолданылған", "high", "CWE-78", "cmdi", ("C", "C++"), r"(?<![\w.])(system|popen)\s*\("),
    R("C-SCANF", "scanf(\"%s\") өлшемсіз", "medium", "CWE-120", "bufoverflow", ("C", "C++"), r"\bscanf\s*\(\s*\"[^\"]*%s"),
    R("C-FMT", "printf пішім жолы литерал емес", "medium", "CWE-134", "format", ("C", "C++"), r"\b(printf|fprintf|syslog)\s*\(\s*([a-z_]+,\s*)?[a-z_]\w*\s*\)", "low"),
    R("C-RAND", "rand() қауіпсіздік үшін жарамайды", "low", "CWE-338", "weakrand", ("C", "C++"), r"(?<![\w.])rand\s*\(\s*\)", "low"),

    # ---------------- Rust ----------------
    R("RS-UNSAFE", "unsafe блогы", "low", "CWE-119", "unsafe", "Rust", r"\bunsafe\s*\{|\bunsafe\s+fn\b", "low"),

    # ---------------- Shell / Dockerfile ----------------
    R("SH-CURLPIPE", "Желіден жүктелген скрипт бірден орындалады (curl | sh)", "medium", "CWE-494", "supply", ("Shell", "Dockerfile"), r"\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?(ba|z)?sh\b"),
    R("SH-EVAL", "eval қолданылған", "medium", "CWE-78", "cmdi", "Shell", r"^\s*eval\s+", "low"),
    R("SH-CHMOD", "chmod 777 — барлығына толық рұқсат", "medium", "CWE-732", "privilege", ("Shell", "Dockerfile"), r"\bchmod\s+(-R\s+)?0?777\b"),
    R("SH-INSECURE", "curl/wget TLS тексеруінсіз", "medium", "CWE-295", "tls", ("Shell", "Dockerfile"), r"\bcurl\b[^|;]*\s(-k|--insecure)\b|\bwget\b[^|;]*--no-check-certificate"),
    R("DK-LATEST", "Базалық образ нұсқасы көрсетілмеген (latest)", "low", "CWE-1104", "dockertag", "Dockerfile", r"^\s*FROM\s+(--platform=\S+\s+)?[^\s:@]+(:latest)?(\s+AS\s+\w+)?\s*$", "medium", re.I),
    R("DK-ADDURL", "ADD арқылы URL-дан жүктеу", "medium", "CWE-494", "supply", "Dockerfile", r"^\s*ADD\s+https?://", "medium", re.I),
    R("DK-SECRET", "ENV/ARG ішінде құпия мәлімет", "high", "CWE-798", "secrets", "Dockerfile",
      r"^\s*(ENV|ARG)\s+\w*(PASSWORD|SECRET|TOKEN|API_?KEY|PRIVATE)\w*\s*[= ]\s*[^\s$][^\s]*", "medium", re.I, "secrets"),
    R("DK-SSH", "SSH порты (22) ашылған", "low", "CWE-284", "misconfig", "Dockerfile", r"^\s*EXPOSE\s+.*\b22\b", "medium", re.I),
    R("DK-SUDO", "sudo контейнерде", "low", "CWE-250", "privilege", "Dockerfile", r"\bapt(-get)?\s+install[^\n]*\bsudo\b", "low"),

    # ---------------- YAML / Config ----------------
    R("YML-PRIV", "privileged: true — контейнерге толық хост құқығы", "high", "CWE-250", "privilege", "YAML", r"\bprivileged\s*:\s*true\b"),
    R("YML-HOSTNET", "Хост желісі қолданылады", "medium", "CWE-668", "privilege", "YAML", r"\bhostNetwork\s*:\s*true|network_mode\s*:\s*[\"']?host|hostPID\s*:\s*true"),
    R("YML-ROOT", "Контейнер root немесе артық құқықпен", "medium", "CWE-250", "privilege", "YAML", r"\brunAsUser\s*:\s*0\b|allowPrivilegeEscalation\s*:\s*true|runAsNonRoot\s*:\s*false"),
    R("YML-PORTS", "Дерекқор/сервис порты барлық интерфейске ашық", "low", "CWE-668", "misconfig", "YAML", r"[\"']?0\.0\.0\.0:\d+:\d+[\"']?", "low"),
    R("CFG-DEBUG", "Debug режимі конфигурацияда қосулы", "medium", "CWE-489", "debug", ("Config", "YAML", "JSON", "TOML"), r"^\s*[\"']?(DEBUG|APP_DEBUG|debug|FLASK_DEBUG)[\"']?\s*[=:]\s*[\"']?(true|True|1|on)[\"']?\s*,?\s*$", "medium"),
    R("CFG-ACTUATOR", "Spring Actuator барлық endpoint-тері ашық", "medium", "CWE-200", "infoleak", "Config", r"management\.endpoints\.web\.exposure\.include\s*=\s*\*"),
    R("CFG-SSLOFF", "SSL/TLS өшірілген", "medium", "CWE-319", "tls", ("Config", "YAML", "TOML"), r"^\s*(ssl|tls|verify_ssl|useSSL)\s*[=:]\s*(false|0|no)\s*$", "medium", re.I),

    # ---------------- CSS ----------------
    R("CSS-EXPR", "CSS expression() (ескі IE, XSS)", "medium", "CWE-79", "xss", "CSS", r"\bexpression\s*\(", "medium", re.I),
    R("CSS-JSURL", "CSS ішінде javascript: URL", "medium", "CWE-79", "xss", "CSS", r"url\(\s*[\"']?\s*javascript:", "medium", re.I),
    R("CSS-IMPORT", "Сыртқы CSS @import (тексерусіз сыртқы ресурс)", "low", "CWE-829", "supply", "CSS", r"@import\s+(url\()?\s*[\"']?https?://", "medium", re.I),
    R("CSS-HTTP", "CSS ресурсы HTTP арқылы (mixed content)", "low", "CWE-319", "tls", "CSS", r"url\(\s*[\"']?http://", "medium", re.I),
    R("CSS-EXFIL", "Атрибут селекторы + url() — деректі сыртқа ағызу тәсілі", "medium", "CWE-200", "infoleak", "CSS",
      r"\[\s*(value|name|href|data-\w+)\s*[\^\$\*]=[^\]]*\]\s*\{[^}]*url\(", "low", re.I),
    R("CSS-OUTLINE", "Фокус көрсеткіші өшірілген (outline: none)", "info", "", "a11y", "CSS", r"outline\s*:\s*(none|0)\b(?![^;}]*(box-shadow|border))", "low", re.I, "accessibility"),
    R("CSS-TINY", "Өте кіші мәтін өлшемі (<12px)", "info", "", "a11y", "CSS", r"font-size\s*:\s*([0-9]|1[01])(\.\d+)?px", "medium", re.I, "accessibility"),
]


def rules_for(language: str) -> list[Rule]:
    return [r for r in RULES if "*" in r.langs or language in r.langs]
