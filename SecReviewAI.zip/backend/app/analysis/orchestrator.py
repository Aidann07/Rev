"""Талдау оркестраторы: файлдарды жинайды, тілді анықтайды, талдаушыларды іске қосады, нәтижені біріктіреді."""
import os
from collections import Counter
from pathlib import Path
from typing import Callable

from .analyzers import ANALYZERS, ScanContext
from .finding import SEVERITY_ORDER, SEVERITY_WEIGHT, RawFinding
from .languages import SKIP_DIRS, detect_language
from ..config import settings

import re

TEST_PATH = re.compile(r"(^|/)(tests?|__tests__|specs?|testing|e2e|fixtures|mocks?|examples?|samples?|demo)(/|$)|(^|/)test_[^/]+\.py$|"
                       r"[._-](test|spec)\.(js|jsx|ts|tsx|py|java|go|rb|php)$|(Test|Tests|IT)\.(java|kt|cs)$", re.I)
# Бұл ережелер тест папкасында да толық қауіптілікпен қалады (нақты токен пішімдері)
KEEP_IN_TESTS = {"SEC-AWS", "SEC-GITHUB", "SEC-PRIVKEY", "SEC-SLACK", "SEC-GOOGLE", "SEC-STRIPE", "SEC-LLMKEY"}
CONF_FACTOR = {"high": 1.0, "medium": 0.8, "low": 0.5}


def collect_files(root: Path):
    files, all_rel = [], []
    for dirpath, dirnames, filenames in os.walk(root):
        # виртуал орта (кез келген атпен) — pyvenv.cfg бар папка; тәуелділіктер студенттің коды емес
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not (Path(dirpath) / d / "pyvenv.cfg").exists()]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.is_symlink():
                continue
            rel = p.relative_to(root).as_posix()
            all_rel.append(rel)
            lang = detect_language(rel)
            if lang:
                files.append((rel, lang))
            if len(files) >= settings.max_files:
                return files, all_rel
    return files, all_rel


def _key(f: RawFinding) -> tuple:
    kind = f.extra.get("kind", "")
    if f.category == "secrets":
        return (f.file, f.line, "secrets")
    if f.line and kind and kind not in ("misconfig", "deps"):
        return (f.file, f.line, kind)
    return (f.file, f.line, f.rule_id)


def dedupe(findings: list[RawFinding]) -> list[RawFinding]:
    """Бір жолдағы бір түрлі осалдықты әртүрлі құралдар тапса, бір жазбаға біріктіреді
    (мәтіні — ертерек жұмыс істеген құралдан, қауіптілігі — ең жоғарысы)."""
    best: dict[tuple, RawFinding] = {}
    for f in findings:
        cur = best.get(_key(f))
        if cur is None:
            best[_key(f)] = f
            continue
        if SEVERITY_ORDER[f.severity] < SEVERITY_ORDER[cur.severity]:
            cur.severity = f.severity
        cur.extra.setdefault("also", []).append(f.tool)
    return list(best.values())


def apply_test_policy(findings: list[RawFinding]) -> None:
    """Тест/мысал файлдарындағы табылымдар нақты өнімге әсер етпейді: «төмен» деңгейден жоғары болмайды және баллға әсер етпейді."""
    for f in findings:
        if TEST_PATH.search(f.file) and f.rule_id not in KEEP_IN_TESTS:
            f.extra["test"] = True
            if SEVERITY_ORDER[f.severity] < SEVERITY_ORDER["low"]:
                f.severity = "low"
            if "(тест" not in f.title:
                f.title += " (тест/мысал файлы)"


def risk_score(findings: list[RawFinding]) -> tuple[int, str]:
    penalty = sum(SEVERITY_WEIGHT[f.severity] * CONF_FACTOR.get(f.confidence, 0.8) for f in findings
                  if f.category not in ("accessibility", "quality") and not f.extra.get("test"))
    score = max(0, int(round(100 - min(100, penalty))))
    grade = "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 55 else "D" if score >= 35 else "F"
    return score, grade


def run_analysis(root: Path, progress: Callable[[int, str], None] | None = None):
    progress = progress or (lambda p, s: None)
    progress(10, "Файлдар жиналуда және тілдер анықталуда")
    files, all_rel = collect_files(root)
    ctx = ScanContext(root=root, files=files, all_rel_paths=all_rel)

    lang_files = Counter(l for _, l in files)
    raw: list[RawFinding] = []
    tool_counts: Counter = Counter()
    n = len(ANALYZERS)
    for i, an in enumerate(ANALYZERS):
        progress(15 + int(55 * i / n), f"Талдау: {an.name}")
        try:
            res = an.run(ctx)
        except Exception as e:  # бір талдаушының қатесі бүкіл сканды тоқтатпауы тиіс
            res = []
            tool_counts[f"{an.name}:error"] += 1
            print(f"[analyzer {an.name}] error: {e!r}")
        raw.extend(res)
        if res:
            tool_counts[an.name] += len(res)

    progress(75, "Нәтижелер біріктірілуде")
    findings = dedupe(raw)
    apply_test_policy(findings)
    findings.sort(key=lambda f: (SEVERITY_ORDER[f.severity], f.file, f.line))

    sev = Counter(f.severity for f in findings)
    by_lang = Counter(f.language for f in findings)
    by_cat = Counter(f.category for f in findings)
    score, grade = risk_score(findings)
    summary = {
        "files_scanned": len(files),
        "files_total": len(all_rel),
        "languages": dict(lang_files.most_common()),
        "severity": {k: sev.get(k, 0) for k in ("high", "medium", "low", "info")},
        "by_language": dict(by_lang.most_common()),
        "by_category": dict(by_cat.most_common()),
        "tools": dict(tool_counts),
        "total": len(findings),
        "score": score,
        "grade": grade,
    }
    return findings, summary
