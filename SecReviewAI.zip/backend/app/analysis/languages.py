"""Тілді анықтау: кеңейтілім және файл атауы бойынша."""
from pathlib import PurePosixPath

EXT_LANG = {
    ".py": "Python", ".pyw": "Python",
    ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript", ".jsx": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript",
    ".html": "HTML", ".htm": "HTML", ".xhtml": "HTML", ".vue": "HTML", ".svelte": "HTML",
    ".css": "CSS", ".scss": "CSS", ".sass": "CSS", ".less": "CSS",
    ".java": "Java", ".kt": "Kotlin", ".kts": "Kotlin",
    ".sql": "SQL",
    ".php": "PHP", ".phtml": "PHP",
    ".cs": "C#", ".go": "Go", ".rb": "Ruby", ".rs": "Rust",
    ".c": "C", ".h": "C", ".cpp": "C++", ".cc": "C++", ".hpp": "C++",
    ".sh": "Shell", ".bash": "Shell",
    ".yml": "YAML", ".yaml": "YAML", ".json": "JSON", ".xml": "XML", ".toml": "TOML",
    ".ini": "Config", ".cfg": "Config", ".conf": "Config", ".properties": "Config", ".env": "Config",
    ".tf": "Terraform", ".gradle": "Gradle",
}
NAME_LANG = {
    "dockerfile": "Dockerfile", "docker-compose.yml": "YAML", "docker-compose.yaml": "YAML",
    "requirements.txt": "Dependencies", "package.json": "Dependencies", "pom.xml": "Dependencies",
    "build.gradle": "Dependencies", "composer.json": "Dependencies", "go.mod": "Dependencies",
    "gemfile": "Dependencies", ".env": "Config",
}
SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "env", "__pycache__", "dist", "build", "target",
             ".idea", ".vscode", "vendor", "bower_components", ".next", ".mypy_cache", ".pytest_cache",
             "site-packages", ".gradle", "coverage", "obj", "Pods", ".dart_tool", ".terraform", "__MACOSX", ".nuxt",
             ".tox", ".eggs", ".cache", ".svn", ".hg"}
BINARY_EXT = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp", ".pdf", ".zip", ".tar", ".gz", ".jar",
              ".class", ".exe", ".dll", ".so", ".woff", ".woff2", ".ttf", ".eot", ".mp3", ".mp4", ".pyc",
              ".lock", ".min.js", ".map", ".docx", ".xlsx", ".pptx"}


def detect_language(rel_path: str) -> str | None:
    p = PurePosixPath(rel_path)
    name = p.name.lower()
    if name.endswith(".min.js") or name.endswith(".min.css"):
        return None
    if name in NAME_LANG:
        return NAME_LANG[name]
    if name.startswith("dockerfile"):
        return "Dockerfile"
    if name.startswith(".env"):
        return "Config"
    if p.suffix.lower() in BINARY_EXT:
        return None
    return EXT_LANG.get(p.suffix.lower())


SUPPORTED = sorted({v for v in EXT_LANG.values()} | {"Dockerfile", "Dependencies"})
