"""Табылымдарды сұралған тілге (kk/ru/en) аудару. Қазақша мәтін дерекқорда түпнұсқа күйінде қалады;
аударма оқу кезінде жасалады. ЖИ (LLM) жақсартқан түсіндірме өзгертілмейді."""
import re

from . import i18n_kb as KB
from .i18n_titles import EN as T_EN, RU as T_RU

LANGS = ("kk", "ru", "en")
_T = {"ru": T_RU, "en": T_EN}
_KB = {"ru": KB.RU, "en": KB.EN}
_SENS = {"ru": KB.SENS_RU, "en": KB.SENS_EN}
_DEP = {"ru": KB.DEP_RU, "en": KB.DEP_EN}

# Сандары/атаулары бар динамикалық атаулар: (регекс, {тіл: үлгі})
_DYN = [
    (re.compile(r"^Inline оқиға өңдеушілері \((\d+) жерде\)"), {"ru": "Inline-обработчики событий ({0} мест): несовместимы с CSP", "en": "Inline event handlers ({0} places): incompatible with CSP"}),
    (re.compile(r"^(\d+) суретте alt атрибуты жоқ"), {"ru": "У {0} изображений нет атрибута alt", "en": "{0} images have no alt attribute"}),
    (re.compile(r"^Қатты жазылған құпия мән \((.*)\)$"), {"ru": "Секрет, записанный в коде ({0})", "en": "Hard-coded secret ({0})"}),
    (re.compile(r"^(\d+) кітапхананың нұсқасы бекітілмеген"), {"ru": "Версии {0} библиотек не зафиксированы (==)", "en": "{0} library versions are not pinned (==)"}),
    (re.compile(r"^npm '(.*)' скрипті желіден код жүктейді"), {"ru": "npm-скрипт '{0}' загружает код из сети", "en": "npm script '{0}' downloads code from the network"}),
]
_DEPT = re.compile(r"^Осал кітапхана: (.+?) — (.*)$")
_DEPP = {"ru": "Уязвимая библиотека: {0} — {1}", "en": "Vulnerable library: {0} — {1}"}


def title(rule_id: str, kk_title: str, lang: str) -> str:
    if lang not in _T:
        return kk_title
    if rule_id in _T[lang]:
        return _T[lang][rule_id]
    if kk_title in _SENS[lang]:
        return _SENS[lang][kk_title]
    for rx, tpl in _DYN:
        m = rx.match(kk_title)
        if m:
            return tpl[lang].format(*m.groups())
    m = _DEPT.match(kk_title)
    if m:
        cve = rule_id[4:] if rule_id.startswith("DEP-") else ""
        return _DEPP[lang].format(m.group(1), _DEP[lang].get(cve, m.group(2)))
    return kk_title


from .kb import KB as _KK
_BY_TEXT = {v[0]: k for k, v in _KK.items()}   # қазақша түсіндірме -> kind


def texts(kk_expl: str, kk_fix: str, lang: str, llm_enhanced: bool) -> tuple[str, str]:
    """LLM жақсартқан мәтін тұрған күйінде қалады, әйтпесе білім қорынан аударылады (kind түсіндірмеден табылады)."""
    if lang not in _KB or llm_enhanced:
        return kk_expl, kk_fix
    kind = _BY_TEXT.get(kk_expl)
    return _KB[lang].get(kind, (kk_expl, kk_fix)) if kind else (kk_expl, kk_fix)
