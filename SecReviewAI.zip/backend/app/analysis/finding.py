from dataclasses import dataclass, field

SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}
SEVERITY_KK = {"high": "Жоғары", "medium": "Орташа", "low": "Төмен", "info": "Ақпарат"}
SEVERITY_WEIGHT = {"high": 10, "medium": 4, "low": 1, "info": 0}


@dataclass
class RawFinding:
    file: str
    line: int
    rule_id: str
    title: str
    severity: str
    cwe: str = ""
    category: str = ""
    language: str = ""
    tool: str = "builtin"
    confidence: str = "medium"
    snippet: str = ""
    explanation: str = ""
    fix: str = ""
    extra: dict = field(default_factory=dict)
