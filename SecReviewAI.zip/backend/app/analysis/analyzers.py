"""Талдаушылар (плагиндер). Әрқайсысы run(ctx) -> list[RawFinding] қайтарады."""
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from ..config import settings
from .finding import RawFinding
from .kb import lookup
from .languages import SKIP_DIRS
from .rules import rules_for

COMMENT_PREFIX = {
    "Python": ("#",), "Shell": ("#",), "Ruby": ("#",), "YAML": ("#",), "Config": ("#", ";"), "TOML": ("#",),
    "Dockerfile": ("#",), "SQL": ("--", "#"), "PHP": ("//", "#", "*", "/*"),
    "JavaScript": ("//", "*", "/*"), "TypeScript": ("//", "*", "/*"), "Java": ("//", "*", "/*"),
    "Kotlin": ("//", "*", "/*"), "C#": ("//", "*", "/*"), "Go": ("//", "*", "/*"), "C": ("//", "*", "/*"),
    "C++": ("//", "*", "/*"), "Rust": ("//", "*", "/*"), "CSS": ("/*", "*", "//"),
}


@dataclass
class ScanContext:
    root: Path
    files: list  # [(rel_path, language)]
    all_rel_paths: list

    def read(self, rel: str) -> str | None:
        p = self.root / rel
        try:
            if p.stat().st_size > settings.max_file_bytes:
                return None
            return p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None


def _make(rule_id, title, sev, cwe, kind, file, line, lang, tool="builtin", conf="medium", snippet="", cat="code") -> RawFinding:
    why, fix = lookup(kind)
    return RawFinding(file=file, line=line, rule_id=rule_id, title=title, severity=sev, cwe=cwe, category=cat,
                      language=lang, tool=tool, confidence=conf, snippet=_safe_snippet(snippet)[:240], explanation=why, fix=fix,
                      extra={"kind": kind})


def _line_of(text: str, idx: int) -> int:
    return text.count("\n", 0, idx) + 1


_SQLSECRET = re.compile(r"(IDENTIFIED\s+BY|PASSWORD\s*[=(]?|WITH\s+PASSWORD)\s*['\"]", re.I)


def _safe_snippet(line: str) -> str:
    """Кез келген ереженің snippet-інде құпия мән ашық қалмауы үшін: жолда құпия белгісі болса, жасырамыз."""
    if not line:
        return line
    if (_SQLSECRET.search(line) or GENERIC_SECRET.search(line) or re.search(r"://[^:/@\s\"']+:[^@\s\"']+@", line)
            or any(pat.search(line) for _r, _t, _s, _c, pat in SECRET_PATTERNS)):
        return _mask(line)
    return line


_QUOTED = re.compile(r"'[^'\n]*'|\"[^\"\n]*\"")


def _mask(s: str) -> str:
    """Құпия МӘНДІ жасыру (айнымалы аты көрініп тұрады): бірінші 3 таңба + ***."""
    # белгілі токен пішімдері (айнымалы атынсыз тұрса да)
    known = s
    for rid, _t, _s, _c, pat in SECRET_PATTERNS:
        if rid not in ("SEC-URLCRED", "SEC-PRIVKEY"):
            known = pat.sub(lambda m: m.group(0)[:4] + "***", known)
    if known != s:
        return known
    # URL ішіндегі пароль: scheme://user:pass@host
    url = re.sub(r"(://[^:/@\s\"']+:)[^@\s\"']+(@)", r"\1***\2", s)
    if url != s:
        return url
    # тырнақшалы жолдар: ретімен жұптап, 4+ таңбалыларды жасырамыз ('petclinic' -> 'pet***')
    def q(m):
        body = m.group(0)[1:-1]
        return m.group(0) if len(body) < 4 else f"{m.group(0)[0]}{body[:3]}***{m.group(0)[0]}"
    quoted = _QUOTED.sub(q, s)
    if quoted != s:
        return quoted
    # тырнақсыз мән: KEY=value, KEY: value, ENV KEY value
    return re.sub(r"((?:\b(?:ENV|ARG)\s+\w+\s*[=\s]\s*)|(?:[=:]\s*))([^\s\"']{4,})",
                  lambda m: f"{m.group(1)}{m.group(2)[:3]}***", s, count=1)


# =====================================================================
class RuleAnalyzer:
    """Тіл бойынша жол ережелері."""
    name = "builtin-rules"

    def run(self, ctx: ScanContext):
        out = []
        for rel, lang in ctx.files:
            rules = rules_for(lang)
            if not rules:
                continue
            text = ctx.read(rel)
            if text is None:
                continue
            prefixes = COMMENT_PREFIX.get(lang, ())
            for no, line in enumerate(text.splitlines(), 1):
                if len(line) > 600:
                    continue
                stripped = line.strip()
                if not stripped:
                    continue
                is_comment = bool(prefixes) and stripped.startswith(prefixes)
                for r in rules:
                    if is_comment and r.category != "secrets":
                        continue
                    if r.pattern.search(line):
                        snip = _mask(stripped) if r.category == "secrets" else stripped
                        out.append(_make(r.id, r.title, r.severity, r.cwe, r.kind, rel, no, lang,
                                         conf=r.confidence, snippet=snip, cat=r.category))
        return out


# =====================================================================
FORM_RE = re.compile(r"<form\b([^>]*)>(.*?)</form>", re.I | re.S)
TAG_A_RE = re.compile(r"<a\b[^>]*>", re.I | re.S)
SCRIPT_SRC_RE = re.compile(r"<script\b[^>]*\bsrc\s*=\s*[\"']([^\"']+)[\"'][^>]*>", re.I | re.S)
LINK_RE = re.compile(r"<link\b[^>]*\bhref\s*=\s*[\"']([^\"']+)[\"'][^>]*>", re.I | re.S)
IFRAME_RE = re.compile(r"<iframe\b[^>]*>", re.I | re.S)
IMG_RE = re.compile(r"<img\b[^>]*>", re.I | re.S)
ONEVENT_RE = re.compile(r"<[a-z][^>]*\son(click|load|error|mouseover|submit|change|focus|blur)\s*=", re.I)
CSRF_HINT = re.compile(r"csrf|_token|xsrf|authenticity_token|__RequestVerificationToken|csrfmiddlewaretoken", re.I)


class HtmlAnalyzer:
    """HTML құрылымдық тексерулері (көп жолды тегтер)."""
    name = "html-checks"

    def run(self, ctx: ScanContext):
        out = []
        for rel, lang in ctx.files:
            if lang != "HTML":
                continue
            text = ctx.read(rel)
            if not text:
                continue
            ln = lambda i: _line_of(text, i)

            for m in TAG_A_RE.finditer(text):
                tag = m.group(0)
                if re.search(r"target\s*=\s*[\"']?_blank", tag, re.I) and not re.search(r"rel\s*=\s*[\"'][^\"']*(noopener|noreferrer)", tag, re.I):
                    out.append(_make("HTML-BLANK", "target=\"_blank\" сілтемесі rel=\"noopener\" жоқ", "low", "CWE-1022",
                                     "tabnabbing", rel, ln(m.start()), lang, conf="high", snippet=tag.strip()))

            for m in FORM_RE.finditer(text):
                attrs, body = m.group(1), m.group(2)
                method = re.search(r"method\s*=\s*[\"']?(\w+)", attrs, re.I)
                method = method.group(1).lower() if method else "get"
                has_pw = re.search(r"type\s*=\s*[\"']?password", body, re.I)
                if method == "post" and not CSRF_HINT.search(body) and not CSRF_HINT.search(attrs) and not re.search(r"\bth:(action|object|field)\b", attrs + body):  # Thymeleaf+Spring Security CSRF-ті өзі қосады
                    out.append(_make("HTML-CSRF", "POST формасында CSRF токені табылмады", "medium", "CWE-352", "csrf",
                                     rel, ln(m.start()), lang, conf="low", snippet=f"<form {attrs.strip()[:120]}>"))
                if has_pw and method == "get":
                    out.append(_make("HTML-PWGET", "Пароль өрісі бар форма GET әдісімен жіберіледі", "high", "CWE-598", "infoleak",
                                     rel, ln(m.start()), lang, conf="high", snippet=f"<form {attrs.strip()[:120]}>"))
                if re.search(r"action\s*=\s*[\"']http://", attrs, re.I):
                    out.append(_make("HTML-FORMHTTP", "Форма HTTP (шифрсыз) мекенжайға жіберіледі", "medium", "CWE-319", "tls",
                                     rel, ln(m.start()), lang, conf="high", snippet=f"<form {attrs.strip()[:120]}>"))

            for m in SCRIPT_SRC_RE.finditer(text):
                src, tag = m.group(1), m.group(0)
                if src.lower().startswith("http://"):
                    out.append(_make("HTML-SCRIPTHTTP", "Скрипт HTTP арқылы жүктеледі", "medium", "CWE-319", "tls",
                                     rel, ln(m.start()), lang, conf="high", snippet=tag.strip()))
                elif re.match(r"(https:)?//", src, re.I) and "integrity" not in tag.lower():
                    out.append(_make("HTML-SRI", "Сыртқы скриптте integrity (SRI) жоқ", "low", "CWE-353", "supply",
                                     rel, ln(m.start()), lang, conf="medium", snippet=tag.strip()))
            for m in LINK_RE.finditer(text):
                href, tag = m.group(1), m.group(0)
                if "stylesheet" in tag.lower():
                    if href.lower().startswith("http://"):
                        out.append(_make("HTML-CSSHTTP", "Стиль HTTP арқылы жүктеледі", "low", "CWE-319", "tls",
                                         rel, ln(m.start()), lang, conf="high", snippet=tag.strip()))
            for m in IFRAME_RE.finditer(text):
                if "sandbox" not in m.group(0).lower():
                    out.append(_make("HTML-IFRAME", "iframe sandbox атрибутынсыз", "low", "CWE-1021", "clickjack",
                                     rel, ln(m.start()), lang, conf="medium", snippet=m.group(0).strip()))

            ev = list(ONEVENT_RE.finditer(text))
            if ev:
                out.append(_make("HTML-INLINE-EVENT", f"Inline оқиға өңдеушілері ({len(ev)} жерде): CSP-мен үйлеспейді", "low",
                                 "CWE-79", "csp", rel, ln(ev[0].start()), lang, conf="low", snippet=ev[0].group(0)[:160]))

            if re.search(r"<html\b", text, re.I) and re.search(r"<head\b", text, re.I) and not re.search(r"Content-Security-Policy", text, re.I):
                out.append(_make("HTML-NOCSP", "Content-Security-Policy орнатылмаған", "low", "CWE-693", "csp",
                                 rel, 1, lang, conf="low", snippet="<head> ішінде CSP meta жоқ"))

            for m in re.finditer(r"<!--(.*?)-->", text, re.S):
                if re.search(r"(password|passwd|secret|api[_-]?key|token)\s*[:=]", m.group(1), re.I):
                    out.append(_make("HTML-COMMENT", "HTML түсініктемесінде құпия мәлімет болуы мүмкін", "medium", "CWE-615", "secrets",
                                     rel, ln(m.start()), lang, conf="low", snippet=_mask(m.group(0)[:160]), cat="secrets"))

            # --- Қолжетімділік (accessibility) ---
            imgs = [m for m in IMG_RE.finditer(text) if not re.search(r"\balt\s*=", m.group(0), re.I)]
            if imgs:
                out.append(_make("HTML-ALT", f"{len(imgs)} суретте alt атрибуты жоқ", "info", "", "a11y", rel, ln(imgs[0].start()),
                                 lang, conf="high", snippet=imgs[0].group(0)[:160], cat="accessibility"))
            if re.search(r"<html\b", text, re.I) and not re.search(r"<html\b[^>]*\blang\s*=", text, re.I):
                out.append(_make("HTML-LANG", "<html> тегінде lang атрибуты жоқ", "info", "", "a11y", rel, 1, lang,
                                 conf="high", snippet="<html>", cat="accessibility"))
            if re.search(r"<html\b", text, re.I) and not re.search(r"name\s*=\s*[\"']viewport", text, re.I):
                out.append(_make("HTML-VIEWPORT", "viewport meta жоқ (мобильді құрылғыда дұрыс көрінбейді)", "info", "", "a11y",
                                 rel, 1, lang, conf="medium", snippet="<meta name=\"viewport\"> табылмады", cat="accessibility"))
        return out


# =====================================================================
SECRET_PATTERNS = [
    ("SEC-AWS", "AWS қолжетімділік кілті", "high", "CWE-798", re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("SEC-GITHUB", "GitHub токені", "high", "CWE-798", re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{50,})\b")),
    ("SEC-PRIVKEY", "Жеке (private) кілт файлда", "high", "CWE-321", re.compile(r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY( BLOCK)?-----")),
    ("SEC-SLACK", "Slack токені", "high", "CWE-798", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")),
    ("SEC-GOOGLE", "Google API кілті", "high", "CWE-798", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("SEC-STRIPE", "Stripe құпия кілті", "high", "CWE-798", re.compile(r"\b(sk|rk)_live_[0-9a-zA-Z]{20,}\b")),
    ("SEC-LLMKEY", "LLM API кілті (OpenAI/Anthropic)", "high", "CWE-798", re.compile(r"\bsk-(ant-|proj-)?[A-Za-z0-9_\-]{32,}\b")),
    ("SEC-JWT", "JWT токені кодта", "medium", "CWE-798", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
    ("SEC-URLCRED", "URL ішінде логин:пароль", "high", "CWE-798",
     re.compile(r"\b[a-z][a-z0-9+.\-]*://[^\s:/@\"'<>]{2,}:[^\s@\"'<>/]{3,}@[^\s/\"'<>]+")),
]
GENERIC_SECRET = re.compile(
    r"(?i)[\"']?\b([A-Za-z0-9_.\-]*(password|passwd|pwd|secret|api[_-]?key|apikey|access[_-]?token|auth[_-]?token|client[_-]?secret|private[_-]?key)[A-Za-z0-9_.\-]*)[\"']?\s*[:=]\s*[\"']([^\"'\s]{6,})[\"']")
PLACEHOLDER = re.compile(
    r"(?i)^(\$|\{\{|<|%|\*{3,}|x{4,}|\.{3}|your[_-]|my[_-]|changeme|change_me|example|sample|dummy|test|placeholder|none|null|todo|password|secret|"
    r"env\.|process\.env|os\.environ|getenv|config\.)|\$\{|\{\{|<.+>|^[\*•]+$")
TEXTY = {"Python", "JavaScript", "TypeScript", "HTML", "Java", "Kotlin", "PHP", "C#", "Go", "Ruby", "Rust", "C", "C++", "Shell",
         "YAML", "JSON", "XML", "TOML", "Config", "Terraform", "Gradle", "Dockerfile", "SQL", "CSS"}
SKIP_SECRET_FILES = re.compile(r"(\.example|\.sample|\.template|\.dist)$|(^|/)(package-lock\.json|yarn\.lock|poetry\.lock)$", re.I)


class SecretAnalyzer:
    """Қатты жазылған құпиялар (барлық тілдер)."""
    name = "secret-scan"

    def run(self, ctx: ScanContext):
        out = []
        for rel, lang in ctx.files:
            if lang not in TEXTY or SKIP_SECRET_FILES.search(rel):
                continue
            text = ctx.read(rel)
            if not text:
                continue
            seen_lines = set()
            for no, line in enumerate(text.splitlines(), 1):
                if len(line) > 800:
                    continue
                for rid, title, sev, cwe, pat in SECRET_PATTERNS:
                    m = pat.search(line)
                    if m:
                        if rid == "SEC-URLCRED" and re.search(r"(?i)(localhost|127\.0\.0\.1|example\.|user:pass|username:password|<|\$\{|\{)", m.group(0)):
                            continue
                        out.append(_make(rid, title, sev, cwe, "secrets", rel, no, lang, conf="high", snippet=_mask(line.strip()), cat="secrets"))
                        seen_lines.add(no)
                        break
                else:
                    m = GENERIC_SECRET.search(line)
                    if m and no not in seen_lines:
                        value = m.group(3)
                        if PLACEHOLDER.search(value):
                            continue
                        out.append(_make("SEC-HARDCODED", f"Қатты жазылған құпия мән ({m.group(1)})", "high", "CWE-798", "secrets",
                                         rel, no, lang, conf="medium", snippet=_mask(line.strip()), cat="secrets"))
        return out


SENSITIVE_FILES = [
    (re.compile(r"(^|/)\.env(\.(local|prod|production|dev|development|staging))?$", re.I), ".env файлы репозиторийде"),
    (re.compile(r"(^|/)id_(rsa|dsa|ecdsa|ed25519)$"), "SSH жеке кілті репозиторийде"),
    (re.compile(r"\.(pem|key|p12|pfx|jks|keystore)$", re.I), "Кілт/сертификат файлы репозиторийде"),
    (re.compile(r"\.(sqlite3?|db|kdbx)$", re.I), "Дерекқор файлы репозиторийде"),
    (re.compile(r"(^|/)(\.htpasswd|credentials\.json|secrets?\.(ya?ml|json)|service[-_]account.*\.json|\.npmrc|\.pypirc|\.netrc)$", re.I), "Құпия деректер файлы репозиторийде"),
]


class SensitiveFileAnalyzer:
    name = "sensitive-files"

    def run(self, ctx: ScanContext):
        out = []
        for rel in ctx.all_rel_paths:
            for pat, title in SENSITIVE_FILES:
                if pat.search(rel):
                    if re.search(r"\.(example|sample|template|dist)$", rel, re.I):
                        continue
                    if rel.lower().endswith((".pem", ".key")) or "pub" in rel.lower():
                        txt = ctx.read(rel) or ""
                        if "PRIVATE KEY" not in txt and rel.lower().endswith((".pem", ".key")):
                            continue  # ашық кілт/сертификат — қауіпсіз
                    if Path(rel).name.lower() in (".npmrc", ".pypirc", ".netrc"):
                        txt = ctx.read(rel) or ""
                        if not re.search(r"_authToken|_auth\b|password|passwd|token|api[_-]?key", txt, re.I):
                            continue  # құпиясыз конфигурация
                    if rel.lower().endswith(".env") or ".env." in rel.lower():
                        txt = ctx.read(rel) or ""
                        if not re.search(r"^\s*\w+\s*=\s*\S+", txt, re.M):
                            continue
                    out.append(_make("SEC-FILE", title, "high", "CWE-538", "secretfile", rel, 0, "Config", conf="high",
                                     snippet=rel, cat="secrets"))
                    break
        return out


# =====================================================================
class DockerAnalyzer:
    """Dockerfile файл деңгейіндегі тексеру: USER жоқ."""
    name = "docker-checks"

    def run(self, ctx: ScanContext):
        out = []
        for rel, lang in ctx.files:
            if lang != "Dockerfile":
                continue
            text = ctx.read(rel) or ""
            froms = [m for m in re.finditer(r"^\s*FROM\b", text, re.I | re.M)]
            if not froms:
                continue
            last_stage = text[froms[-1].start():]
            users = re.findall(r"^\s*USER\s+(\S+)", last_stage, re.I | re.M)
            if not users or users[-1].lower() in ("root", "0"):
                out.append(_make("DK-ROOT", "Dockerfile: контейнер root-пен жұмыс істейді (USER жоқ)", "medium", "CWE-250", "dockerroot",
                                 rel, _line_of(text, froms[-1].start()), lang, conf="high", snippet="USER нұсқауы жоқ"))
            if not re.search(r"^\s*HEALTHCHECK\b", text, re.I | re.M):
                out.append(_make("DK-HEALTH", "Dockerfile: HEALTHCHECK жоқ", "info", "", "misconfig", rel, 1, lang, conf="low",
                                 snippet="HEALTHCHECK нұсқауы жоқ", cat="quality"))
        return out


# =====================================================================
# Оффлайн осалдық базасы (толық емес; ONLINE_DEP_AUDIT=1 болса pip-audit-пен толықтырылады)
ADVISORIES = {
    "pypi": {
        "requests": [("2.31.0", "CVE-2023-32681", "Proxy-Authorization тақырыбы бағыттау кезінде ағып кетеді")],
        "pyyaml": [("5.4", "CVE-2020-14343", "full_load арқылы ерікті код орындау")],
        "jinja2": [("3.1.3", "CVE-2024-22195", "xmlattr сүзгісі арқылы XSS")],
        "urllib3": [("1.26.5", "CVE-2021-33503", "URL талдауда ReDoS")],
        "pillow": [("10.0.1", "CVE-2023-4863", "libwebp буфер асып кетуі")],
        "flask": [("2.2.5", "CVE-2023-30861", "Кэш арқылы сессия куки ағуы")],
        "werkzeug": [("3.0.3", "CVE-2024-34069", "Debugger арқылы код орындау")],
        "cryptography": [("41.0.2", "CVE-2023-38325", "SSH сертификат тексеру қателігі")],
        "django": [("3.2.13", "CVE-2022-28346", "QuerySet.annotate/aggregate арқылы SQL injection")],
    },
    "npm": {
        "lodash": [("4.17.21", "CVE-2021-23337", "template арқылы команда енгізу")],
        "minimist": [("1.2.6", "CVE-2021-44906", "Prototype pollution")],
        "express": [("4.19.2", "CVE-2024-29041", "Open redirect")],
        "axios": [("1.6.0", "CVE-2023-45857", "XSRF-TOKEN ағуы")],
        "jsonwebtoken": [("9.0.0", "CVE-2022-23529", "Қолтаңба тексеруді айналып өту")],
        "node-fetch": [("2.6.7", "CVE-2022-0235", "Құпия тақырыптардың ағуы")],
        "moment": [("2.29.4", "CVE-2022-31129", "ReDoS")],
        "ejs": [("3.1.7", "CVE-2022-29078", "Шаблон арқылы код орындау (RCE)")],
        "jquery": [("3.5.0", "CVE-2020-11022", "htmlPrefilter арқылы XSS")],
        "handlebars": [("4.7.7", "CVE-2021-23369", "Шаблон арқылы код орындау")],
        "serialize-javascript": [("3.1.0", "CVE-2020-7660", "Код енгізу")],
    },
    "maven": {
        "log4j-core": [("2.17.1", "CVE-2021-44228", "Log4Shell: қашықтан код орындау (RCE)")],
        "spring-beans": [("5.3.18", "CVE-2022-22965", "Spring4Shell: қашықтан код орындау")],
        "jackson-databind": [("2.13.4.1", "CVE-2022-42003", "Десериализация арқылы DoS")],
        "struts2-core": [("2.5.33", "CVE-2023-50164", "Файл жүктеу арқылы RCE")],
        "commons-text": [("1.10.0", "CVE-2022-42889", "Text4Shell: код орындау")],
        "snakeyaml": [("1.31", "CVE-2022-25857", "Стек толып кетуі арқылы DoS")],
        "h2": [("2.1.210", "CVE-2021-42392", "JNDI арқылы RCE")],
    },
}


def _vtuple(v: str):
    nums = re.findall(r"\d+", v.split("+")[0].split("-")[0])
    return tuple(int(n) for n in nums[:4]) or (0,)


def _lt(a: str, b: str) -> bool:
    ta, tb = _vtuple(a), _vtuple(b)
    n = max(len(ta), len(tb))
    return ta + (0,) * (n - len(ta)) < tb + (0,) * (n - len(tb))


class DependencyAnalyzer:
    name = "dependency-audit"

    def _check(self, eco, name, ver, rel, line, out, lang="Dependencies"):
        for fixed, cve, desc in ADVISORIES.get(eco, {}).get(name.lower(), []):
            if _lt(ver, fixed):
                f = _make(f"DEP-{cve}", f"Осал кітапхана: {name} {ver} — {desc}", "high", cve, "deps", rel, line, lang,
                          tool="dependency-audit", conf="high", snippet=f"{name} {ver}  →  түзетілген нұсқа: {fixed}+", cat="dependencies")
                f.fix = f"`{name}` кітапханасын {fixed} немесе одан жоғары нұсқаға жаңартыңыз. " + f.fix
                out.append(f)

    def run(self, ctx: ScanContext):
        out = []
        for rel, lang in ctx.files:
            base = Path(rel).name.lower()
            if base not in ("requirements.txt", "package.json", "pom.xml"):
                continue
            text = ctx.read(rel)
            if not text:
                continue
            if base == "requirements.txt":
                unpinned = 0
                for no, line in enumerate(text.splitlines(), 1):
                    line = line.split("#")[0].strip()
                    if not line or line.startswith(("-", "git+", "http")):
                        continue
                    m = re.match(r"([A-Za-z0-9_.\-]+)(\[.*\])?\s*(==|>=|~=|<=|>|<)?\s*([\w.\-]+)?", line)
                    if not m:
                        continue
                    name, op, ver = m.group(1), m.group(3), m.group(4)
                    if ver and op in ("==", "~=", "<="):
                        self._check("pypi", name.lower().replace("_", "-"), ver, rel, no, out)
                    if op != "==":
                        unpinned += 1
                if unpinned:
                    out.append(_make("DEP-UNPINNED", f"{unpinned} кітапхананың нұсқасы бекітілмеген (==)", "low", "CWE-1104", "supply", rel, 1,
                                     lang, tool="dependency-audit", conf="medium", snippet="нұсқаны == арқылы бекітіңіз", cat="dependencies"))
            elif base == "package.json":
                try:
                    data = json.loads(text)
                except ValueError:
                    continue
                for sec in ("dependencies", "devDependencies"):
                    for name, spec in (data.get(sec) or {}).items():
                        ver = re.sub(r"^[\^~>=<\s]+", "", str(spec))
                        if re.match(r"\d", ver):
                            self._check("npm", name, ver, rel, 1, out)
                for hook in ("preinstall", "postinstall", "install"):
                    cmd = (data.get("scripts") or {}).get(hook, "")
                    if re.search(r"curl|wget|\|\s*(ba)?sh", cmd):
                        out.append(_make("DEP-NPMHOOK", f"npm '{hook}' скрипті желіден код жүктейді", "high", "CWE-494", "supply", rel, 1, lang,
                                         tool="dependency-audit", conf="medium", snippet=cmd[:160], cat="dependencies"))
            elif base == "pom.xml":
                for m in re.finditer(r"<dependency>(.*?)</dependency>", text, re.S):
                    a = re.search(r"<artifactId>\s*([^<\s]+)", m.group(1))
                    v = re.search(r"<version>\s*([\d][^<\s]*)", m.group(1))
                    if a and v:
                        self._check("maven", a.group(1), v.group(1), rel, _line_of(text, m.start()), out)
        return out


# =====================================================================
def _run(cmd, cwd=None, timeout=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout or settings.tool_timeout)


from .bandit_map import BANDIT as BANDIT_MAP, SKIP as BANDIT_SKIP


class BanditAnalyzer:
    """Python үшін Bandit (бар болса)."""
    name = "bandit"

    def available(self):
        return shutil.which("bandit") is not None

    def run(self, ctx: ScanContext):
        if not any(l == "Python" for _, l in ctx.files) or not self.available():
            return []
        # Папканы Bandit өзі аралаудың орнына, сүзгіден өткен Python файлдарының тізімін береміз:
        # осылайша .venv/site-packages/node_modules (кез келген атпен) тексерілмейді.
        pyfiles = [str(ctx.root / rel) for rel, lang in ctx.files if lang == "Python"]
        results = []
        try:
            for i in range(0, len(pyfiles), 200):
                p = _run(["bandit", "-f", "json", "-q", *pyfiles[i:i + 200]])
                results += json.loads(p.stdout or "{}").get("results", [])
        except (subprocess.SubprocessError, ValueError, OSError):
            return []
        data = {"results": results}
        out = []
        for r in data.get("results", []):
            if r.get("test_id") in BANDIT_SKIP:  # assert_used, import-тексерулер т.б. — шу, қауіпсіздік емес
                continue
            rel = os.path.relpath(r["filename"], ctx.root).replace("\\", "/")
            if any(part in SKIP_DIRS for part in rel.split("/")[:-1]):  # қосымша қорғаныс: тәуелділік папкалары
                continue
            sev = {"HIGH": "high", "MEDIUM": "medium", "LOW": "low"}.get(r.get("issue_severity", "LOW"), "low")
            cwe = r.get("issue_cwe", {}).get("id")
            tid = r.get("test_id")
            kind, kk_title = BANDIT_MAP[tid][:2] if tid in BANDIT_MAP else ("misconfig", r.get("issue_text", "Bandit"))
            f = _make(f"BANDIT-{tid}", kk_title, sev, f"CWE-{cwe}" if cwe else "", kind, rel,
                      r.get("line_number", 0), "Python", tool="bandit",
                      conf={"HIGH": "high", "MEDIUM": "medium", "LOW": "low"}.get(r.get("issue_confidence", "MEDIUM"), "medium"),
                      snippet=(r.get("code", "") or "").strip().splitlines()[-1] if r.get("code") else "")
            if kind == "secrets":
                quoted = re.findall(r"[\"']([^\"']+)[\"']", r.get("code", "") or "")
                if quoted and all(PLACEHOLDER.search(q) for q in quoted[-1:]):
                    continue  # changeme / ${VAR} сияқты орынбасарлар
                f.snippet = _mask(f.snippet)
                f.category = "secrets"
            out.append(f)
        return out


class SemgrepAnalyzer:
    """Semgrep — әмбебап қозғалтқыш (орнатылған және SEMGREP_CONFIG берілген болса)."""
    name = "semgrep"

    def available(self):
        return bool(settings.semgrep_config) and shutil.which("semgrep") is not None

    def run(self, ctx: ScanContext):
        if not self.available():
            return []
        try:
            p = _run(["semgrep", "scan", "--config", settings.semgrep_config, "--json", "--quiet", "--metrics=off",
                      "--timeout", "30", *[a for d in sorted(SKIP_DIRS) for a in ("--exclude", d)], str(ctx.root)], timeout=settings.tool_timeout * 2)
            data = json.loads(p.stdout or "{}")
        except (subprocess.SubprocessError, ValueError, OSError):
            return []
        from .languages import detect_language
        out = []
        for r in data.get("results", []):
            rel = os.path.relpath(r["path"], ctx.root).replace("\\", "/")
            meta = r.get("extra", {}).get("metadata", {})
            cwe = meta.get("cwe", "")
            cwe = (cwe[0] if isinstance(cwe, list) and cwe else cwe) or ""
            cwe = str(cwe).split(":")[0]
            sev = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}.get(r.get("extra", {}).get("severity", "WARNING"), "medium")
            msg = r.get("extra", {}).get("message", r.get("check_id", "Semgrep"))
            kind = "sqli" if "sql" in r.get("check_id", "").lower() else "xss" if "xss" in r.get("check_id", "").lower() else "misconfig"
            f = _make("SEMGREP-" + r.get("check_id", "").split(".")[-1][:60], msg[:200], sev, cwe, kind, rel, r.get("start", {}).get("line", 0),
                      detect_language(rel) or "", tool="semgrep", conf="medium", snippet=(r.get("extra", {}).get("lines", "") or "").strip()[:240])
            out.append(f)
        return out


class PipAuditAnalyzer:
    """pip-audit (PyPI-ге желі қажет): тек ONLINE_DEP_AUDIT=1 болғанда."""
    name = "pip-audit"

    def run(self, ctx: ScanContext):
        if not settings.online_dep_audit or not shutil.which("pip-audit"):
            return []
        out = []
        for rel, _ in ctx.files:
            if Path(rel).name.lower() != "requirements.txt":
                continue
            try:
                p = _run(["pip-audit", "-r", str(ctx.root / rel), "-f", "json", "--no-deps", "--progress-spinner", "off"])
                data = json.loads(p.stdout or "{}")
            except (subprocess.SubprocessError, ValueError, OSError):
                continue
            for dep in data.get("dependencies", []):
                for v in dep.get("vulns", []):
                    f = _make(f"DEP-{v['id']}", f"Осал кітапхана: {dep['name']} {dep.get('version', '')} — {v['id']}", "high",
                              v["id"], "deps", rel, 1, "Dependencies", tool="pip-audit", conf="high",
                              snippet=f"түзету: {', '.join(v.get('fix_versions', [])) or 'жоқ'}", cat="dependencies")
                    out.append(f)
        return out


class ProjectChecks:
    """Жоба деңгейіндегі тексерулер (бір рет қана хабарланады)."""
    name = "project-checks"

    def run(self, ctx: ScanContext):
        out = []
        js = [(r, l) for r, l in ctx.files if l in ("JavaScript", "TypeScript")]
        express_file, has_helmet = None, False
        for rel, lang in js:
            if "/test" in "/" + rel or rel.startswith("test"):
                continue
            t = ctx.read(rel) or ""
            if re.search(r"require\(\s*['\"]express['\"]\s*\)|from\s+['\"]express['\"]", t):
                express_file = express_file or rel
            if "helmet" in t:
                has_helmet = True
        pkg = ctx.read("package.json") if "package.json" in ctx.all_rel_paths else ""
        if pkg and "helmet" in pkg:
            has_helmet = True
        if express_file and not has_helmet:
            out.append(_make("JS-HELMET", "Express қолданбасында helmet жоқ (қауіпсіздік HTTP тақырыптары орнатылмаған)", "low", "CWE-693", "csp",
                             express_file, 1, "JavaScript", conf="low", snippet="npm i helmet  →  app.use(helmet())"))
        return out


ANALYZERS = [RuleAnalyzer(), HtmlAnalyzer(), SecretAnalyzer(), SensitiveFileAnalyzer(), DockerAnalyzer(),
             DependencyAnalyzer(), ProjectChecks(), BanditAnalyzer(), SemgrepAnalyzer(), PipAuditAnalyzer()]
