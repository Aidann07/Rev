"""Шифрлау модулі: GitHub токені және басқа құпиялар Fernet (AES-128-CBC + HMAC-SHA256) арқылы сақталады."""
from cryptography.fernet import Fernet, InvalidToken

from .config import settings

_f = Fernet(settings.encryption_key.encode())


def encrypt(plain: str) -> str:
    return _f.encrypt(plain.encode()).decode() if plain else ""


def decrypt(token: str) -> str:
    if not token:
        return ""
    try:
        return _f.decrypt(token.encode()).decode()
    except InvalidToken:
        return ""
