"""Баптаулар — барлығы орта айнымалылары (ENV) арқылы."""
import base64
import hashlib
import os
from pathlib import Path


class Settings:
    def __init__(self) -> None:
        self.base_dir = Path(__file__).resolve().parent.parent
        self.data_dir = Path(os.getenv("DATA_DIR", self.base_dir / "data")).resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        (self.data_dir / "workspaces").mkdir(exist_ok=True)

        self.database_url = os.getenv("DATABASE_URL", f"sqlite:///{self.data_dir / 'secreview.db'}")
        self.secret_key = os.getenv("SECRET_KEY", "dev-only-change-me-please-32-bytes-min!!")
        self.teacher_code = os.getenv("TEACHER_CODE", "")  # бос болса — оқытушы ретінде тіркелу өшірулі
        self.token_ttl_minutes = int(os.getenv("TOKEN_TTL_MINUTES", "720"))

        # Шифрлау кілті: Fernet кілті берілмесе SECRET_KEY-ден алынады
        key = os.getenv("ENCRYPTION_KEY")
        if not key:
            key = base64.urlsafe_b64encode(hashlib.sha256(self.secret_key.encode()).digest()).decode()
        self.encryption_key = key

        self.redis_url = os.getenv("REDIS_URL", "")  # бос болса — celery қолданылмайды, ішкі ағын
        self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        self.llm_model = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
        self.llm_max_findings = int(os.getenv("LLM_MAX_FINDINGS", "15"))

        self.github_client_id = os.getenv("GITHUB_CLIENT_ID", "").strip().strip("\"'")
        self.github_client_secret = os.getenv("GITHUB_CLIENT_SECRET", "").strip().strip("\"'")
        self.frontend_url = os.getenv("FRONTEND_URL", "http://localhost:5173")
        self.public_url = os.getenv("PUBLIC_URL", "http://localhost:8000")
        self.cors_origins = [o for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o]

        # Талдау шектеулері
        self.max_file_bytes = int(os.getenv("MAX_FILE_BYTES", str(1_000_000)))
        self.max_files = int(os.getenv("MAX_FILES", "5000"))
        self.max_zip_bytes = int(os.getenv("MAX_ZIP_BYTES", str(100 * 1024 * 1024)))
        self.clone_timeout = int(os.getenv("CLONE_TIMEOUT", "120"))
        self.tool_timeout = int(os.getenv("TOOL_TIMEOUT", "180"))
        self.online_dep_audit = os.getenv("ONLINE_DEP_AUDIT", "0") == "1"
        self.semgrep_config = os.getenv("SEMGREP_CONFIG", "")  # мыс: p/default немесе жергілікті папка


settings = Settings()
