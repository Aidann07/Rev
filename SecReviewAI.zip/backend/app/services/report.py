"""PDF есеп: оқытушыға арналған қорытынды (reportlab, қазақ әріптерін қолдайтын DejaVu қарпі)."""
import io
from datetime import timezone
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

from ..analysis.finding import SEVERITY_KK, SEVERITY_ORDER

FONT_DIRS = [Path("/usr/share/fonts/truetype/dejavu"), Path("/usr/share/fonts/dejavu"), Path("/Library/Fonts"),
             Path("C:/Windows/Fonts"), Path(__file__).resolve().parent.parent / "assets"]


def _register_fonts():
    for d in FONT_DIRS:
        reg, bold, mono = d / "DejaVuSans.ttf", d / "DejaVuSans-Bold.ttf", d / "DejaVuSansMono.ttf"
        if reg.exists() and bold.exists():
            pdfmetrics.registerFont(TTFont("DV", str(reg)))
            pdfmetrics.registerFont(TTFont("DV-B", str(bold)))
            pdfmetrics.registerFont(TTFont("DV-M", str(mono if mono.exists() else reg)))
            return "DV", "DV-B", "DV-M"
    return "Helvetica", "Helvetica-Bold", "Courier"  # қазақ әріптері көрінбеуі мүмкін


F, FB, FM = _register_fonts()
INK, SUB, LINE = colors.HexColor("#1F1F1E"), colors.HexColor("#6B6B66"), colors.HexColor("#E5E5E0")
ACCENT = colors.HexColor("#185FA5")
SEV_COLOR = {"high": colors.HexColor("#A32D2D"), "medium": colors.HexColor("#854F0B"),
             "low": colors.HexColor("#185FA5"), "info": colors.HexColor("#6B6B66")}
SEV_TINT = {"high": colors.HexColor("#FCEBEB"), "medium": colors.HexColor("#FAEEDA"),
            "low": colors.HexColor("#E6F1FB"), "info": colors.HexColor("#F1F1EE")}
GRADE_COLOR = {"A": "#3B6D11", "B": "#3B6D11", "C": "#854F0B", "D": "#A32D2D", "F": "#A32D2D"}


def _styles():
    return {
        "h1": ParagraphStyle("h1", fontName=FB, fontSize=20, leading=25, textColor=INK, spaceAfter=4),
        "h2": ParagraphStyle("h2", fontName=FB, fontSize=13, leading=17, textColor=ACCENT, spaceBefore=12, spaceAfter=6),
        "body": ParagraphStyle("body", fontName=F, fontSize=9.5, leading=14, textColor=INK),
        "sub": ParagraphStyle("sub", fontName=F, fontSize=8.5, leading=12, textColor=SUB),
        "code": ParagraphStyle("code", fontName=FM, fontSize=8, leading=10.5, textColor=INK, backColor=colors.HexColor("#F6F6F3"),
                               borderPadding=(4, 4, 4, 4), spaceBefore=3, spaceAfter=3),
        "ftitle": ParagraphStyle("ftitle", fontName=FB, fontSize=10, leading=13, textColor=INK),
        "label": ParagraphStyle("label", fontName=FB, fontSize=8.5, leading=12, textColor=SUB),
    }


def _p(text, style):
    return Paragraph(escape(str(text)).replace("\n", "<br/>"), style)



LBL = {
 "kk": dict(title="Код қауіпсіздігін тексеру есебі", project="Жоба", author="Автор", source="Дереккөз", zip="ZIP-архив", date="Күні",
            score="Қауіпсіздік көрсеткіші", files="Тексерілген файл", total="табылған мәселе", summary="Қорытынды",
            ok="Жоғары қауіптілігі бар мәселелер жоқ. Жоба негізгі қауіпсіздік тексерулерінен өтті.",
            bad="Жобада {n} жоғары қауіптілікті мәселе табылды (мысалы, инъекциялар, ашық құпиялар немесе осал кітапханалар). Қорғауға дейін оларды түзету ұсынылады.",
            note="Назар аударыңыз: есеп статикалық талдауға негізделген. «Сенімділігі: төмен» мәселелер қосымша қолмен тексеруді қажет етеді; бизнес-логика қателері автоматты түрде табылмайды.",
            langs="Тілдер және файл саны", lang="Тіл", file="Файл", found="Табылған мәселе", tools="Қолданылған талдау құралдары",
            findings="Табылған мәселелер", none="Мәселе табылмады.", tool="құрал", conf="сенімділігі", why="Неге қауіпті", fix="Қалай түзетеміз",
            more="… және тағы {n} мәселе (толық тізім веб-интерфейсте).", footer="SecReview AI — автоматты код қауіпсіздігі есебі", page="{n}-бет",
            sev=dict(high="Жоғары", medium="Орташа", low="Төмен", info="Ақпарат"), cf=dict(high="жоғары", medium="орташа", low="төмен")),
 "ru": dict(title="Отчёт о проверке безопасности кода", project="Проект", author="Автор", source="Источник", zip="ZIP-архив", date="Дата",
            score="Показатель безопасности", files="Проверено файлов", total="найдено проблем", summary="Заключение",
            ok="Проблем высокой опасности нет. Проект прошёл основные проверки безопасности.",
            bad="В проекте найдено проблем высокой опасности: {n} (например, инъекции, открытые секреты или уязвимые библиотеки). Рекомендуется исправить их до публикации.",
            note="Обратите внимание: отчёт основан на статическом анализе. Проблемы с «низкой уверенностью» требуют дополнительной ручной проверки; ошибки бизнес-логики автоматически не обнаруживаются.",
            langs="Языки и количество файлов", lang="Язык", file="Файлы", found="Найдено проблем", tools="Использованные средства анализа",
            findings="Найденные проблемы", none="Проблем не найдено.", tool="средство", conf="уверенность", why="Чем опасно", fix="Как исправить",
            more="… и ещё {n} проблем (полный список в веб-интерфейсе).", footer="SecReview AI — автоматический отчёт о безопасности кода", page="Стр. {n}",
            sev=dict(high="Высокая", medium="Средняя", low="Низкая", info="Инфо"), cf=dict(high="высокая", medium="средняя", low="низкая")),
 "en": dict(title="Code Security Review Report", project="Project", author="Author", source="Source", zip="ZIP archive", date="Date",
            score="Security score", files="Files scanned", total="issues found", summary="Summary",
            ok="No high-severity issues found. The project passed the main security checks.",
            bad="{n} high-severity issues were found in the project (for example, injections, exposed secrets or vulnerable libraries). It is recommended to fix them before release.",
            note="Note: the report is based on static analysis. Issues with low confidence need additional manual review; business-logic errors are not detected automatically.",
            langs="Languages and file counts", lang="Language", file="Files", found="Issues found", tools="Analysis tools used",
            findings="Findings", none="No issues found.", tool="tool", conf="confidence", why="Why it is dangerous", fix="How to fix",
            more="… and {n} more issues (full list in the web interface).", footer="SecReview AI — automated code security report", page="Page {n}",
            sev=dict(high="High", medium="Medium", low="Low", info="Info"), cf=dict(high="high", medium="medium", low="low")),
}


def _footer_for(lang):
    def _footer(canvas, doc):
        t = LBL[lang]
        canvas.saveState()
        canvas.setFont(F, 8)
        canvas.setFillColor(SUB)
        canvas.drawString(18 * mm, 10 * mm, t['footer'])
        canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, t['page'].format(n=doc.page))
        canvas.restoreState()
    return _footer


def _old_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont(F, 8)
    canvas.setFillColor(SUB)
    canvas.drawString(18 * mm, 10 * mm, "SecReview AI — автоматты код қауіпсіздігі есебі")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"{doc.page}-бет")
    canvas.restoreState()


def build_pdf(project, scan, findings, owner_name: str, lang: str = "kk") -> bytes:
    from ..analysis import i18n
    lang = lang if lang in LBL else "kk"
    T = LBL[lang]
    st = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                            title=f"SecReview AI — {project.name}", author="SecReview AI")
    W = A4[0] - 36 * mm
    s = scan.summary or {}
    sev = s.get("severity", {})
    story = []

    story += [_p(T["title"], st["h1"]),
              _p(f"{T['project']}: {project.name}", st["body"]),
              _p(f"{T['author']}: {owner_name}  ·  {T['source']}: {project.repo_url or T['zip']}", st["sub"]),
              _p(T["date"] + ": " + (scan.finished_at or scan.created_at).astimezone(timezone.utc).strftime("%d.%m.%Y %H:%M UTC"), st["sub"]),
              Spacer(1, 8)]

    grade = s.get("grade", "-")
    big = ParagraphStyle("big", fontName=FB, fontSize=34, leading=38, textColor=colors.HexColor(GRADE_COLOR.get(grade, "#1F1F1E")), alignment=1)
    score_tbl = Table([[Paragraph(grade, big), _p(f"{T['score']}: {s.get('score', 0)}/100", st["ftitle"])],
                       ["", _p(f"{T['files']}: {s.get('files_scanned', 0)} · {T['total']}: {s.get('total', 0)}", st["sub"])]],
                      colWidths=[28 * mm, W - 28 * mm])
    score_tbl.setStyle(TableStyle([("SPAN", (0, 0), (0, 1)), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                   ("BOX", (0, 0), (-1, -1), 0.8, LINE), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FAFAF9")),
                                   ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    story += [score_tbl, Spacer(1, 8)]

    cells = []
    for k in ("high", "medium", "low", "info"):
        c = ParagraphStyle("c", fontName=FB, fontSize=18, leading=22, alignment=1, textColor=SEV_COLOR[k])
        l = ParagraphStyle("l", fontName=F, fontSize=8, leading=10, alignment=1, textColor=SUB)
        cells.append([Paragraph(str(sev.get(k, 0)), c), Paragraph(T["sev"][k], l)])
    t = Table([[x[0] for x in cells], [x[1] for x in cells]], colWidths=[W / 4] * 4)
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, LINE), ("INNERGRID", (0, 0), (-1, -1), 0.5, LINE),
                           ("BACKGROUND", (0, 0), (0, -1), SEV_TINT["high"]), ("BACKGROUND", (1, 0), (1, -1), SEV_TINT["medium"]),
                           ("BACKGROUND", (2, 0), (2, -1), SEV_TINT["low"]), ("BACKGROUND", (3, 0), (3, -1), SEV_TINT["info"]),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story += [t, _p(T["summary"], st["h2"])]

    high = sev.get("high", 0)
    verdict = T["ok"] if high == 0 else T["bad"].format(n=high)
    story += [_p(verdict, st["body"]),
              _p(T["note"], st["sub"])]

    langs = s.get("languages", {})
    if langs:
        story += [_p(T["langs"], st["h2"])]
        rows = [[_p(T["lang"], st["label"]), _p(T["file"], st["label"]), _p(T["found"], st["label"])]]
        by = s.get("by_language", {})
        for lname, n in langs.items():
            rows.append([_p(lname, st["body"]), _p(n, st["body"]), _p(by.get(lname, 0), st["body"])])
        lt = Table(rows, colWidths=[W * 0.5, W * 0.2, W * 0.3], repeatRows=1)
        lt.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        story.append(lt)

    tools = {k: v for k, v in (s.get("tools") or {}).items() if not k.endswith(":error")}
    if tools:
        story += [_p(T["tools"] + ": " + ", ".join(f"{k} ({v})" for k, v in tools.items()), st["sub"])]

    story.append(PageBreak())
    story.append(_p(T["findings"], st["h2"]))
    if not findings:
        story.append(_p(T["none"], st["body"]))
    ordered = sorted(findings, key=lambda f: (SEVERITY_ORDER[f.severity], f.file, f.line))
    MAX = 400
    for f in ordered[:MAX]:
        ftitle = i18n.title(f.rule_id, f.title, lang)
        fexpl, ffix = i18n.texts(f.explanation, f.fix, lang, bool(f.llm_enhanced))
        head = Table([[_p(T["sev"][f.severity], ParagraphStyle("sv", fontName=FB, fontSize=8, textColor=SEV_COLOR[f.severity], alignment=1)),
                       _p(ftitle, st["ftitle"])]], colWidths=[20 * mm, W - 20 * mm])
        head.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), SEV_TINT[f.severity]), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                  ("LINEBELOW", (0, 0), (-1, 0), 0.5, LINE), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        loc = f"{f.file}" + (f":{f.line}" if f.line else "")
        meta = f"{loc}   ·   {f.cwe or '—'}   ·   {f.language}   ·   {T['tool']}: {f.tool}   ·   {T['conf']}: {T['cf'].get(f.confidence, f.confidence)}"
        block = [head, _p(meta, st["sub"])]
        if f.snippet:
            block.append(_p(f.snippet[:240], st["code"]))
        block += [_p(T["why"] + ": " + fexpl, st["body"]), Spacer(1, 2), _p(T["fix"] + ": " + ffix, st["body"]), Spacer(1, 9)]
        story.append(KeepTogether(block))
    if len(ordered) > MAX:
        story.append(_p(T["more"].format(n=len(ordered) - MAX), st["sub"]))

    doc.build(story, onFirstPage=_footer_for(lang), onLaterPages=_footer_for(lang))
    return buf.getvalue()
