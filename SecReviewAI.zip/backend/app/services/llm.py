"""LLM түсіндіру: табылған осалдықты қарапайым қазақ тілінде түсіндіреді.
Осалдықты ТАБУ — детерминделген құралдарда; LLM тек түсіндіреді. Кілт жоқ болса, білім қоры (kb.py) қолданылады.
Құпия мәндер LLM-ге жіберілмейді (snippet бұрыннан жасырылған, secrets категориясы мүлде жіберілмейді)."""
import json
import re

from ..config import settings

SYSTEM = ("Сен код қауіпсіздігі бойынша оқытушысың. Студентке табылған осалдықты қысқа және түсінікті қазақ тілінде түсіндір. "
          "Тек JSON қайтар: {\"explanation\": \"2-3 сөйлем: бұл не және неге қауіпті\", \"fix\": \"1-3 сөйлем: нақты қалай түзетеді + қысқа код мысалы бар болса\"}. "
          "Берілген деректерден тыс осалдық ойлап таппа.")


def enabled() -> bool:
    return bool(settings.anthropic_api_key)


def enhance(findings) -> int:
    """findings — DB Finding нысандары (жоғары қауіптілерден бастап). Қайтарады: жақсартылған саны."""
    if not enabled():
        return 0
    try:
        import anthropic
    except ImportError:
        return 0
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key, timeout=30.0)
    done = 0
    candidates = [f for f in findings if f.category != "secrets" and f.severity in ("high", "medium")]
    for f in candidates[: settings.llm_max_findings]:
        prompt = (f"Тіл: {f.language}\nОсалдық: {f.title}\nCWE: {f.cwe}\nФайл: {f.file}:{f.line}\n"
                  f"Код жолы: {f.snippet}\nНегізгі түсініктеме: {f.explanation}")
        try:
            msg = client.messages.create(model=settings.llm_model, max_tokens=500, system=SYSTEM,
                                         messages=[{"role": "user", "content": prompt}])
            text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
            m = re.search(r"\{.*\}", text, re.S)
            data = json.loads(m.group(0)) if m else {}
            if data.get("explanation"):
                f.explanation = str(data["explanation"])[:1200]
                if data.get("fix"):
                    f.fix = str(data["fix"])[:1200]
                f.llm_enhanced = 1
                done += 1
        except Exception as e:  # желі/квота қатесі — білім қоры мәтіні қалады
            print(f"[llm] skipped: {e!r}")
            break
    return done
