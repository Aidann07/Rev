"""Скан орындаушысы: көзді дайындау -> талдау -> DB-ға жазу -> LLM -> тазалау."""
import shutil
import threading
import traceback

from ..config import settings
from ..crypto import decrypt
from ..database import SessionLocal
from ..models import Finding, Scan, now
from . import llm
from .repo import RepoError, clone_repo, extract_zip, workspace
from ..analysis.orchestrator import run_analysis


def _progress(db, scan, pct, stage):
    scan.progress, scan.stage = pct, stage
    db.commit()


def execute_scan(scan_id: int) -> None:
    db = SessionLocal()
    scan = db.get(Scan, scan_id)
    if not scan:
        db.close()
        return
    ws = workspace(scan_id)
    try:
        project = scan.project
        scan.status = "running"
        _progress(db, scan, 3, "Бастапқы код алынуда")
        shutil.rmtree(ws, ignore_errors=True)
        ws.mkdir(parents=True, exist_ok=True)
        if project.source_type == "github":
            token = decrypt(project.owner.github_token_enc)
            clone_repo(project.repo_url, ws / "src", token)
        else:
            extract_zip(__import__("pathlib").Path(project.zip_path), ws / "src")
        root = ws / "src"

        findings, summary = run_analysis(root, lambda p, s: _progress(db, scan, p, s))

        _progress(db, scan, 80, "Нәтижелер сақталуда")
        rows = [Finding(scan_id=scan.id, file=f.file, line=f.line, rule_id=f.rule_id, title=f.title[:300], severity=f.severity,
                        cwe=f.cwe, category=f.category, language=f.language, tool=f.tool, confidence=f.confidence,
                        snippet=f.snippet, explanation=f.explanation, fix=f.fix) for f in findings]
        db.add_all(rows)
        db.commit()

        if llm.enabled():
            _progress(db, scan, 88, "LLM түсіндірмелері дайындалуда")
            n = llm.enhance(rows)
            summary["llm_enhanced"] = n
            db.commit()
        summary["llm"] = llm.enabled()
        scan.summary = summary
        scan.status, scan.progress, scan.stage, scan.finished_at = "done", 100, "Дайын", now()
        db.commit()
    except RepoError as e:
        scan.status, scan.error, scan.stage, scan.finished_at = "failed", str(e), "Қате", now()
        db.commit()
    except Exception:
        traceback.print_exc()
        scan.status, scan.error, scan.stage, scan.finished_at = "failed", "Ішкі қате: талдау аяқталмады", "Қате", now()
        db.commit()
    finally:
        shutil.rmtree(ws, ignore_errors=True)  # студенттің коды сақталмайды
        db.close()


def dispatch(scan_id: int) -> None:
    """Redis бар болса — Celery кезегі, әйтпесе — фондық ағын."""
    if settings.redis_url:
        from ..worker import run_scan_task
        run_scan_task.delay(scan_id)
    else:
        threading.Thread(target=execute_scan, args=(scan_id,), daemon=True).start()
