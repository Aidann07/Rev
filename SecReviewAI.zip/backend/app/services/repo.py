"""Репозиторийді алу: GitHub клондау (қауіпсіз) немесе ZIP ашу. Студенттің коды ешқашан орындалмайды."""
import base64
import os
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

from ..config import settings

# Қабылданатын түрлер: https://github.com/u/r, .git-пен/онсыз, www., схемасыз, git@github.com:u/r.git,
# ssh://git@github.com/u/r, /tree/<тармақ>, /blob/..., ?query, #fragment
GITHUB_URL = re.compile(
    r"^(?:(?:https?|git|ssh)://)?(?:[\w.\-]+@)?(?:www\.)?github\.com[/:]"
    r"(?P<owner>[A-Za-z0-9_.\-]+)/(?P<repo>[A-Za-z0-9_.\-]+?)(?:\.git)?"
    r"(?:/(?:tree|blob|commits)/(?P<branch>[A-Za-z0-9_][A-Za-z0-9_.\-]*)(?:/[^?#]*)?)?"
    r"/?(?:[?#].*)?$", re.I)
BRANCH_OK = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.\-]*$")


class RepoError(Exception):
    pass


def normalize_github_url(url: str) -> str:
    """Кез келген GitHub сілтемесін https://github.com/u/r.git (немесе ...git#тармақ) түріне келтіреді."""
    m = GITHUB_URL.match((url or "").strip())
    if not m or m["owner"] in (".", "..") or m["repo"] in (".", ".."):
        raise RepoError("GitHub сілтемесі дұрыс емес. Мысалы: https://github.com/user/repo")
    out = f"https://github.com/{m['owner']}/{m['repo']}.git"
    return out + (f"#{m['branch']}" if m["branch"] else "")


def _dir_size(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file() and not f.is_symlink())


def _git_env(dest: Path, token: str) -> dict:
    # Ортаны тазартпай, тек құпия айнымалыларды алып тастаймыз: Windows-та желі SystemRoot, прокси,
    # сертификат бапталымдарына тәуелді, тазартылған орта getaddrinfo қатесін береді.
    SECRET_ENV = {"SECRET_KEY", "ENCRYPTION_KEY", "GITHUB_CLIENT_SECRET", "ANTHROPIC_API_KEY", "TEACHER_CODE",
                  "DATABASE_URL", "REDIS_URL", "GITHUB_CLIENT_ID"}
    env = {k: v for k, v in os.environ.items() if k.upper() not in SECRET_ENV}
    env.update({"GIT_TERMINAL_PROMPT": "0", "GIT_ASKPASS": "echo", "GIT_LFS_SKIP_SMUDGE": "1"})
    if os.name != "nt":  # Windows-та жүйелік git config (schannel, сертификаттар) керек
        env["GIT_CONFIG_NOSYSTEM"] = "1"
        env["HOME"] = str(dest.parent)
    if token:  # токен командалық жолда көрінбеуі үшін ENV арқылы, тек github.com үшін беріледі
        basic = base64.b64encode(f"x-access-token:{token}".encode()).decode()
        n = int(env.get("GIT_CONFIG_COUNT", "0") or 0)  # бұрыннан бар GIT_CONFIG_* (прокси т.б.) үстінен жазбаймыз
        env.update({"GIT_CONFIG_COUNT": str(n + 1), f"GIT_CONFIG_KEY_{n}": "http.https://github.com/.extraheader",
                    f"GIT_CONFIG_VALUE_{n}": f"Authorization: Basic {basic}"})
    return env


def _git_clone(url: str, branch: str, dest: Path, token: str) -> tuple[int, str]:
    cmd = ["git", "-c", f"core.hooksPath={os.devnull}", "-c", "protocol.file.allow=never", "-c", "core.symlinks=false",
           "clone", "--depth", "1", "--no-tags", "--single-branch"]
    if branch:
        cmd += ["--branch", branch]
    cmd += [url, str(dest)]
    try:
        p = subprocess.run(cmd, env=_git_env(dest, token), capture_output=True, text=True, timeout=settings.clone_timeout)
    except subprocess.TimeoutExpired:
        raise RepoError("Репозиторийді клондау уақыты бітті (тым үлкен немесе қолжетімсіз)")
    except FileNotFoundError:
        raise RepoError("Серверде git орнатылмаған")
    err = p.stderr or ""
    return p.returncode, err.replace(token, "***") if token else err


def clone_repo(url: str, dest: Path, token: str = "") -> None:
    url, _, branch = normalize_github_url(url).partition("#")
    if branch and not BRANCH_OK.match(branch):
        branch = ""
    code, err = _git_clone(url, branch, dest, token)
    low = err.lower()
    # Сілтемедегі тармақ жоқ болса — әдепкі тармақпен қайталаймыз
    if code != 0 and branch and ("remote branch" in low and "not found" in low):
        shutil.rmtree(dest, ignore_errors=True)
        branch = ""
        code, err = _git_clone(url, branch, dest, token)
        low = err.lower()
    # Токен ескірген/қайтарылған болса, ашық репозиторий үшін токенсіз қайталаймыз
    if code != 0 and token and ("authentication failed" in low or "invalid username or password" in low or "bad credentials" in low or "403" in low):
        shutil.rmtree(dest, ignore_errors=True)
        code, err = _git_clone(url, branch, dest, "")
        low = err.lower()
    if code != 0:
        shutil.rmtree(dest, ignore_errors=True)
        if "could not resolve host" in low or "failed to connect" in low or "network is unreachable" in low or "getaddrinfo" in low:
            raise RepoError("GitHub-пен байланыс орнамады: интернет қосылымын тексеріңіз")
        if "not found" in low or "could not read username" in low or "authentication" in low or "invalid username" in low:
            raise RepoError("Репозиторий табылмады немесе жеке (private). GitHub арқылы кіріп, рұқсат беріңіз.")
        raise RepoError("Клондау сәтсіз аяқталды: " + err[-200:])
    shutil.rmtree(dest / ".git", ignore_errors=True)
    if _dir_size(dest) > settings.max_zip_bytes * 2:
        shutil.rmtree(dest, ignore_errors=True)
        raise RepoError("Репозиторий тым үлкен")


def extract_zip(zip_path: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    total = 0
    root = dest.resolve()
    try:
        with zipfile.ZipFile(zip_path) as z:
            infos = z.infolist()
            if len(infos) > settings.max_files * 4:
                raise RepoError("ZIP ішінде файл саны тым көп")
            for info in infos:
                total += info.file_size
                if total > settings.max_zip_bytes * 3:
                    raise RepoError("ZIP ашылған күйінде тым үлкен (zip-bomb қорғанысы)")
                target = (dest / info.filename).resolve()
                if root != target and root not in target.parents:
                    continue  # zip-slip: сыртқа шығатын жолдарды елемейміз
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    continue  # симлинктерді елемейміз
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(info) as src, open(target, "wb") as out:
                        shutil.copyfileobj(src, out)
    except zipfile.BadZipFile:
        raise RepoError("ZIP файлы бүлінген немесе дұрыс емес")
    # Егер бәрі бір папка ішінде болса — сол папканы түбір етеміз
    entries = [p for p in dest.iterdir()]
    if len(entries) == 1 and entries[0].is_dir():
        inner = entries[0]
        for child in list(inner.iterdir()):
            shutil.move(str(child), str(dest / child.name))
        inner.rmdir()


def workspace(scan_id: int) -> Path:
    return settings.data_dir / "workspaces" / f"scan_{scan_id}"
