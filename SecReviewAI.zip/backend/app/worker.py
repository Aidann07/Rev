"""Celery worker: celery -A app.worker.celery_app worker -l info"""
from celery import Celery

from .config import settings
from .database import init_db

celery_app = Celery("secreview", broker=settings.redis_url or "memory://", backend=None)
celery_app.conf.task_acks_late = True
init_db()


@celery_app.task(name="secreview.run_scan", bind=True, max_retries=0, soft_time_limit=1800)
def run_scan_task(self, scan_id: int):
    from .services.runner import execute_scan
    execute_scan(scan_id)
