import base64
import json
import secrets
import urllib.error
import urllib.parse
import urllib.request

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from ..config import settings
from ..crypto import decrypt, encrypt
from ..deps import current_user, get_db
from ..models import User
from ..schemas import AuthOut, LoginIn, PasswordIn, ProfilePatch, RegisterIn, UserOut
from ..security import create_token, decode_claims, decode_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


def user_out(u: User) -> UserOut:
    return UserOut(id=u.id, email=u.email, name=u.name, role=u.role, github_login=u.github_login,
                   github_connected=bool(u.github_token_enc))


@router.post("/register", response_model=AuthOut)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == body.email).first():
        raise HTTPException(409, "Бұл email тіркелген")
    role = "student"
    if body.teacher_code:
        if settings.teacher_code and secrets.compare_digest(body.teacher_code, settings.teacher_code):
            role = "teacher"
        else:
            raise HTTPException(403, "Оқытушы коды дұрыс емес")
    u = User(email=body.email, name=body.name.strip(), role=role, password_hash=hash_password(body.password))
    db.add(u)
    db.commit()
    return AuthOut(token=create_token(u.id), user=user_out(u))


@router.post("/login", response_model=AuthOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email == body.email.strip().lower()).first()
    if not u or not verify_password(body.password, u.password_hash):
        raise HTTPException(401, "Email немесе пароль қате")
    return AuthOut(token=create_token(u.id), user=user_out(u))


@router.get("/me", response_model=UserOut)
def me(u: User = Depends(current_user)):
    return user_out(u)


@router.patch("/me", response_model=UserOut)
def update_me(body: ProfilePatch, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if body.name is not None:
        u.name = body.name.strip()
    if body.email is not None:
        email = body.email.strip().lower()
        if "@" not in email or "." not in email.split("@")[-1]:
            raise HTTPException(422, "Email дұрыс емес")
        if email != u.email and db.query(User).filter(User.email == email).first():
            raise HTTPException(409, "Бұл email басқа аккаунтқа тіркелген")
        u.email = email
    db.commit()
    return user_out(u)


@router.post("/password")
def change_password(body: PasswordIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if not verify_password(body.current, u.password_hash):
        raise HTTPException(403, "Ағымдағы құпиясөз қате")
    u.password_hash = hash_password(body.new)
    db.commit()
    return {"ok": True}


# ---------------- GitHub OAuth (тек CLIENT_ID/SECRET берілсе) ----------------
def _http_json(url, data=None, headers=None):
    req = urllib.request.Request(url, data=data, headers={"Accept": "application/json", "User-Agent": "SecReviewAI", **(headers or {})})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


@router.get("/github/status")
def github_status():
    return {"enabled": bool(settings.github_client_id and settings.github_client_secret)}


NEXT_OK = {"/settings", "/projects"}


@router.post("/github/start")
def github_start(next: str = "/settings", u: User = Depends(current_user)):
    """GitHub авторизация бетінің мекенжайын қайтарады. state — 10 минуттық, тек осы мақсатқа арналған токен."""
    if not (settings.github_client_id and settings.github_client_secret):
        raise HTTPException(501, "GitHub OAuth бапталмаған (GITHUB_CLIENT_ID/SECRET)")
    state = create_token(u.id, purpose="gh", minutes=10, next=next if next in NEXT_OK else "/settings")
    params = {"client_id": settings.github_client_id, "scope": "repo read:user", "state": state,
              "redirect_uri": f"{settings.public_url}/api/auth/github/callback"}
    return {"url": "https://github.com/login/oauth/authorize?" + urllib.parse.urlencode(params)}


def _back(next_path: str, **q) -> RedirectResponse:
    return RedirectResponse(f"{settings.frontend_url}{next_path}?" + urllib.parse.urlencode(q))


@router.get("/github/callback")
def github_callback(code: str = "", state: str = "", error: str = "", db: Session = Depends(get_db)):
    claims = decode_claims(state, "gh") if state else None
    user = db.get(User, int(claims["sub"])) if claims else None
    nxt = claims.get("next", "/settings") if claims else "/settings"
    if not user:
        return _back("/settings", github="error", reason="session")
    if error or not code:  # пайдаланушы GitHub бетінде «Cancel» басты
        return _back(nxt, github="error", reason="denied")
    try:
        tok = _http_json("https://github.com/login/oauth/access_token",
                         urllib.parse.urlencode({"client_id": settings.github_client_id, "client_secret": settings.github_client_secret,
                                                 "code": code, "redirect_uri": f"{settings.public_url}/api/auth/github/callback"}).encode())
        access = tok.get("access_token")
        if not access:
            reason = {"incorrect_client_credentials": "credentials", "bad_verification_code": "code",
                      "redirect_uri_mismatch": "redirect"}.get(tok.get("error", ""), "unknown")
            return _back(nxt, github="error", reason=reason)
        gh = _http_json("https://api.github.com/user", headers={"Authorization": f"Bearer {access}"})
    except Exception:
        return _back(nxt, github="error", reason="network")
    user.github_token_enc = encrypt(access)  # Fernet-мен шифрланып сақталады
    user.github_login = gh.get("login", "")
    db.commit()
    return _back(nxt, github="connected")


@router.get("/github/repos")
def github_repos(u: User = Depends(current_user), db: Session = Depends(get_db)):
    token = decrypt(u.github_token_enc)
    if not token:
        raise HTTPException(400, "GitHub байланыстырылмаған")
    repos = []
    try:
        for page in (1, 2, 3):  # 300-ге дейін
            data = _http_json(f"https://api.github.com/user/repos?per_page=100&page={page}&sort=updated"
                              "&affiliation=owner,collaborator,organization_member", headers={"Authorization": f"Bearer {token}"})
            repos += data
            if len(data) < 100:
                break
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):  # токен қайтарылған немесе мерзімі өткен
            u.github_token_enc, u.github_login = "", ""
            db.commit()
            raise HTTPException(409, "GitHub рұқсаты жарамсыз. Баптаулар бетінде GitHub-ты қайта қосыңыз")
        raise HTTPException(502, "GitHub репозиторийлерін алу мүмкін болмады")
    except Exception:
        raise HTTPException(502, "GitHub репозиторийлерін алу мүмкін болмады")
    return [{"name": r["full_name"], "url": r["html_url"], "private": r["private"], "language": r.get("language")} for r in repos]


@router.delete("/github")
def github_disconnect(u: User = Depends(current_user), db: Session = Depends(get_db)):
    token = decrypt(u.github_token_enc)
    if token and settings.github_client_id and settings.github_client_secret:  # GitHub жағында да рұқсатты қайтарамыз (мүмкін болса)
        try:
            basic = base64.b64encode(f"{settings.github_client_id}:{settings.github_client_secret}".encode()).decode()
            req = urllib.request.Request(f"https://api.github.com/applications/{settings.github_client_id}/grant", method="DELETE",
                                         data=json.dumps({"access_token": token}).encode(),
                                         headers={"Authorization": f"Basic {basic}", "Accept": "application/vnd.github+json", "User-Agent": "SecReviewAI"})
            urllib.request.urlopen(req, timeout=10).close()
        except Exception:
            pass
    u.github_token_enc, u.github_login = "", ""
    db.commit()
    return {"ok": True}
