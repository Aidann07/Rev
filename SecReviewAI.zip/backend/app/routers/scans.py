import urllib.parse

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy import case
from sqlalchemy.orm import Session

from ..deps import current_user, get_db, teacher_only
from ..models import Finding, Project, Scan, User
from ..schemas import FindingOut, ProjectOut, ScanDetail
from ..analysis import i18n
from ..services.report import build_pdf
from .projects import project_out

router = APIRouter(prefix="/api", tags=["scans"])

SEV_RANK = case({"high": 0, "medium": 1, "low": 2, "info": 3}, value=Finding.severity, else_=4)


def get_scan(sid: int, u: User, db: Session) -> Scan:
    s = db.get(Scan, sid)
    if not s or (s.project.owner_id != u.id and u.role != "teacher"):
        raise HTTPException(404, "Скан табылмады")
    return s


@router.get("/scans/{sid}", response_model=ScanDetail)
def scan_detail(sid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    s = get_scan(sid, u, db)
    d = ScanDetail.model_validate(s)
    d.project_id, d.project_name = s.project_id, s.project.name
    return d


@router.get("/scans/{sid}/findings", response_model=list[FindingOut])
def scan_findings(sid: int, severity: str | None = None, language: str | None = None, category: str | None = None,
                  q: str | None = Query(default=None, max_length=100), lang: str = "kk", limit: int = Query(500, le=2000), offset: int = 0,
                  u: User = Depends(current_user), db: Session = Depends(get_db)):
    get_scan(sid, u, db)
    qs = db.query(Finding).filter(Finding.scan_id == sid)
    if severity:
        qs = qs.filter(Finding.severity.in_(severity.split(",")))
    if language:
        qs = qs.filter(Finding.language == language)
    if category:
        qs = qs.filter(Finding.category == category)
    if q:
        like = f"%{q}%"
        qs = qs.filter(Finding.title.ilike(like) | Finding.file.ilike(like) | Finding.cwe.ilike(like))
    out = []
    for f in qs.order_by(SEV_RANK, Finding.file, Finding.line).offset(offset).limit(limit).all():
        o = FindingOut.model_validate(f)
        o.title = i18n.title(f.rule_id, f.title, lang)
        o.explanation, o.fix = i18n.texts(f.explanation, f.fix, lang, bool(f.llm_enhanced))
        out.append(o)
    return out


@router.get("/scans/{sid}/report.pdf")
def scan_report(sid: int, lang: str = "kk", u: User = Depends(current_user), db: Session = Depends(get_db)):
    s = get_scan(sid, u, db)
    if s.status != "done":
        raise HTTPException(409, "Скан әлі аяқталмаған")
    findings = db.query(Finding).filter(Finding.scan_id == sid).all()
    pdf = build_pdf(s.project, s, findings, s.project.owner.name, lang)
    pretty = "".join(c if c.isalnum() or c in "-_" else "_" for c in s.project.name)[:40] or "report"
    ascii_name = "".join(c if c.isascii() and (c.isalnum() or c in "-_") else "_" for c in pretty)
    cd = f"attachment; filename=\"SecReview_{ascii_name}_{sid}.pdf\"; filename*=UTF-8''{urllib.parse.quote(f'SecReview_{pretty}_{sid}.pdf')}"
    return Response(pdf, media_type="application/pdf", headers={"Content-Disposition": cd})


@router.get("/teacher/projects", response_model=list[ProjectOut])
def teacher_overview(_: User = Depends(teacher_only), db: Session = Depends(get_db)):
    return [project_out(p) for p in db.query(Project).order_by(Project.id.desc()).all()]
