from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from ..deps import current_user, get_db, teacher_only
from ..models import Advisor, User

router = APIRouter(prefix="/api/advisors", tags=["advisors"])


class AdvisorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    position: str = ""
    department: str = ""


class AdvisorIn(BaseModel):
    name: str = Field(min_length=3, max_length=120)
    position: str = Field(default="", max_length=80)
    department: str = Field(default="", max_length=160)


@router.get("", response_model=list[AdvisorOut])
def list_advisors(q: str = Query(default="", max_length=80), u: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Advisor).order_by(Advisor.name).all()
    q = q.strip().casefold()   # кириллицада регистрді SQL LIKE емес, Python дұрыс ескереді (SQLite — тек ASCII)
    if q:
        rows = [a for a in rows if q in f"{a.name} {a.position} {a.department}".casefold()]
    return rows[:200]


@router.post("", response_model=AdvisorOut, status_code=201)
def add_advisor(body: AdvisorIn, u: User = Depends(teacher_only), db: Session = Depends(get_db)):
    name = " ".join(body.name.split())
    if db.query(Advisor).filter(Advisor.name == name).first():
        raise HTTPException(409, "Бұл жетекші тізімде бар")
    a = Advisor(name=name, position=body.position.strip(), department=body.department.strip())
    db.add(a)
    db.commit()
    db.refresh(a)
    return a
