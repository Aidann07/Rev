import shutil
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..deps import current_user, get_db
from ..models import Project, Scan, User
from ..schemas import ProjectIn, ProjectOut, ProjectPatch, ScanBrief, clean_advisors
from ..services.repo import RepoError, normalize_github_url
from ..services.runner import dispatch

router = APIRouter(prefix="/api/projects", tags=["projects"])


NON_PROGRAMMING = {"Dependencies", "Config", "JSON", "YAML", "XML", "TOML", "Gradle", "Dockerfile", "Terraform"}


def project_out(p: Project) -> ProjectOut:
    last = p.scans[0] if p.scans else None
    done = next((s for s in p.scans if s.status == "done"), None)
    langs = [l for l in ((done.summary or {}).get("languages", {}) if done else {}) if l not in NON_PROGRAMMING][:4]
    return ProjectOut(id=p.id, name=p.name, source_type=p.source_type, repo_url=p.repo_url, description=p.description or "",
                      advisors=p.advisors or [], languages=langs, created_at=p.created_at,
                      owner_name=p.owner.name if p.owner else "", last_scan=ScanBrief.model_validate(last) if last else None)


def get_own_project(pid: int, user: User, db: Session) -> Project:
    p = db.get(Project, pid)
    if not p or (p.owner_id != user.id and user.role != "teacher"):
        raise HTTPException(404, "Жоба табылмады")
    return p


@router.get("", response_model=list[ProjectOut])
def list_projects(u: User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(Project)
    if u.role != "teacher":
        q = q.filter(Project.owner_id == u.id)
    return [project_out(p) for p in q.order_by(Project.id.desc()).all()]


@router.post("", response_model=ProjectOut)
def create_from_github(body: ProjectIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        url = normalize_github_url(body.repo_url)
    except RepoError as e:
        raise HTTPException(422, str(e))
    p = Project(owner_id=u.id, name=body.name.strip(), source_type="github", repo_url=url.removesuffix(".git"),
                description=body.description.strip(), advisors=body.advisors)
    db.add(p)
    db.commit()
    return project_out(p)


@router.post("/upload", response_model=ProjectOut)
async def create_from_zip(name: str = Form(...), description: str = Form(""), advisors: str = Form(""),
                          file: UploadFile = File(...), u: User = Depends(current_user), db: Session = Depends(get_db)):
    if not (file.filename or "").lower().endswith(".zip"):
        raise HTTPException(422, "Тек .zip файл қабылданады")
    up_dir = settings.data_dir / "uploads"
    up_dir.mkdir(exist_ok=True)
    dest = up_dir / f"{uuid.uuid4().hex}.zip"
    size = 0
    with open(dest, "wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > settings.max_zip_bytes:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(413, f"Файл тым үлкен (максимум {settings.max_zip_bytes // 1024 // 1024} МБ)")
            out.write(chunk)
    p = Project(owner_id=u.id, name=name.strip()[:200] or "ZIP жоба", source_type="zip", zip_path=str(dest),
                description=description.strip()[:1000], advisors=clean_advisors(advisors))
    db.add(p)
    db.commit()
    return project_out(p)


@router.get("/{pid}", response_model=ProjectOut)
def get_project(pid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    return project_out(get_own_project(pid, u, db))


@router.patch("/{pid}", response_model=ProjectOut)
def update_project(pid: int, body: ProjectPatch, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_own_project(pid, u, db)
    if p.owner_id != u.id:
        raise HTTPException(403, "Тек жоба иесі өзгерте алады")
    if body.name is not None:
        p.name = body.name.strip()
    if body.description is not None:
        p.description = body.description.strip()
    if body.advisors is not None:
        p.advisors = body.advisors
    db.commit()
    return project_out(p)


@router.delete("/{pid}")
def delete_project(pid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_own_project(pid, u, db)
    if p.owner_id != u.id:
        raise HTTPException(403, "Тек жоба иесі өшіре алады")
    if p.zip_path:
        Path(p.zip_path).unlink(missing_ok=True)
    db.delete(p)
    db.commit()
    return {"ok": True}


@router.post("/{pid}/scans", response_model=ScanBrief)
def start_scan(pid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_own_project(pid, u, db)
    if p.owner_id != u.id:
        raise HTTPException(403, "Тек жоба иесі скан іске қоса алады")
    if p.scans and p.scans[0].status in ("queued", "running"):
        raise HTTPException(409, "Алдыңғы скан әлі аяқталмаған")
    scan = Scan(project_id=p.id, status="queued", stage="Кезекте")
    db.add(scan)
    db.commit()
    dispatch(scan.id)
    return ScanBrief.model_validate(scan)


@router.get("/{pid}/scans", response_model=list[ScanBrief])
def project_scans(pid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_own_project(pid, u, db)
    return [ScanBrief.model_validate(s) for s in p.scans]
