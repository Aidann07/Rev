"""Басты бет статистикасы: барлығы нақты деректен есептеледі."""
from collections import Counter
from datetime import timedelta

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..analysis import i18n
from ..deps import current_user, get_db
from ..models import Finding, Project, Scan, User, now

router = APIRouter(prefix="/api", tags=["dashboard"])
ACTIONABLE = ("high", "medium", "low")


def scan_item(s: Scan) -> dict:
    sm = s.summary or {}
    return {"id": s.id, "project_id": s.project_id, "project_name": s.project.name, "status": s.status, "stage": s.stage,
            "progress": s.progress, "created_at": s.created_at, "finished_at": s.finished_at,
            "total": sum((sm.get("severity") or {}).get(k, 0) for k in ACTIONABLE) if sm else 0,
            "grade": sm.get("grade"), "score": sm.get("score")}


def visible_projects(u: User, db: Session) -> list[Project]:
    q = db.query(Project)
    if u.role != "teacher":
        q = q.filter(Project.owner_id == u.id)
    return q.all()


def actionable(scan: Scan) -> int:
    sev = (scan.summary or {}).get("severity") or {}
    return sum(sev.get(k, 0) for k in ACTIONABLE)


def fixed_between(db: Session, prev: Scan, cur: Scan) -> int:
    """Алдыңғы скандағы, бірақ соңғыда жоқ табылымдар = түзетілгендер (файл + ереже + код жолы бойынша)."""
    def keys(sid):
        rows = db.query(Finding.file, Finding.rule_id, Finding.snippet).filter(
            Finding.scan_id == sid, Finding.severity.in_(ACTIONABLE)).all()
        return Counter((f, r, (sn or "").strip()) for f, r, sn in rows)
    return sum((keys(prev.id) - keys(cur.id)).values())


@router.get("/scans/recent")
def recent_scans(limit: int = 8, u: User = Depends(current_user), db: Session = Depends(get_db)):
    ids = [p.id for p in visible_projects(u, db)]
    if not ids:
        return []
    rows = db.query(Scan).filter(Scan.project_id.in_(ids)).order_by(Scan.id.desc()).limit(min(limit, 30)).all()
    return [scan_item(s) for s in rows]


@router.get("/dashboard")
def dashboard(lang: str = "kk", u: User = Depends(current_user), db: Session = Depends(get_db)):
    projects = visible_projects(u, db)
    week_ago = now() - timedelta(days=7)

    def aware(dt):
        return dt if dt.tzinfo else dt.replace(tzinfo=week_ago.tzinfo)

    all_scans, latest_ids = [], []
    findings_now = findings_delta = fixed_total = fixed_last = 0
    severity = Counter()
    for p in projects:
        scans = sorted(p.scans, key=lambda s: s.id)  # өсу ретімен
        all_scans += scans
        done = [s for s in scans if s.status == "done"][-10:]
        if done:
            latest_ids.append(done[-1].id)
            findings_now += actionable(done[-1])
            severity.update({k: v for k, v in ((done[-1].summary or {}).get("severity") or {}).items()})
        if len(done) >= 2:
            findings_delta += actionable(done[-1]) - actionable(done[-2])
            for a, b in zip(done, done[1:]):
                fixed_total += fixed_between(db, a, b)
            fixed_last += fixed_between(db, done[-2], done[-1])

    top = []
    if latest_ids:
        rows = db.query(Finding.rule_id, Finding.title, Finding.severity).filter(
            Finding.scan_id.in_(latest_ids), Finding.severity.in_(ACTIONABLE)).all()
        cnt = Counter(r[0] for r in rows)
        sample = {r[0]: (r[1], r[2]) for r in rows}
        top = [{"rule_id": rid, "title": i18n.title(rid, sample[rid][0], lang), "severity": sample[rid][1], "count": n} for rid, n in cnt.most_common(5)]

    recent = sorted(all_scans, key=lambda s: s.id, reverse=True)[:6]
    return {
        "stats": {
            "projects": {"value": len(projects), "delta": sum(1 for p in projects if aware(p.created_at) >= week_ago)},
            "scans": {"value": len(all_scans), "delta": sum(1 for s in all_scans if aware(s.created_at) >= week_ago)},
            "findings": {"value": findings_now, "delta": findings_delta},
            "fixed": {"value": fixed_total, "delta": fixed_last},
        },
        "severity": {k: severity.get(k, 0) for k in ("high", "medium", "low", "info")},
        "top_issues": top,
        "recent": [scan_item(s) for s in recent],
    }
