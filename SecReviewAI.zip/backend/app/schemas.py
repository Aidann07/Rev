from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class RegisterIn(BaseModel):
    email: str = Field(min_length=5, max_length=255)
    name: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=8, max_length=128)
    teacher_code: str = ""

    @field_validator("email")
    @classmethod
    def _email(cls, v: str) -> str:
        v = v.strip().lower()
        if "@" not in v or "." not in v.split("@")[-1]:
            raise ValueError("Email дұрыс емес")
        return v


class LoginIn(BaseModel):
    email: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    name: str
    role: str
    github_login: str = ""
    github_connected: bool = False


class AuthOut(BaseModel):
    token: str
    user: UserOut


def clean_advisors(v) -> list[str]:
    if isinstance(v, str):
        v = [x for x in v.replace("\n", ",").split(",")]
    out = []
    for x in v or []:
        x = str(x).strip()[:80]
        if x and x not in out:
            out.append(x)
    return out[:10]


class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    repo_url: str
    description: str = Field(default="", max_length=1000)
    advisors: list[str] = []

    @field_validator("advisors", mode="before")
    @classmethod
    def _adv(cls, v):
        return clean_advisors(v)


class ProjectPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=1000)
    advisors: list[str] | None = None

    @field_validator("advisors", mode="before")
    @classmethod
    def _adv(cls, v):
        return None if v is None else clean_advisors(v)


class ProfilePatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    email: str | None = Field(default=None, max_length=255)


class PasswordIn(BaseModel):
    current: str
    new: str = Field(min_length=8, max_length=128)


class ScanBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str
    stage: str = ""
    progress: int = 0
    error: str = ""
    summary: dict = {}
    created_at: datetime
    finished_at: datetime | None = None


class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    source_type: str
    repo_url: str = ""
    description: str = ""
    advisors: list[str] = []
    languages: list[str] = []
    created_at: datetime
    owner_name: str = ""
    last_scan: ScanBrief | None = None


class FindingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    file: str
    line: int
    rule_id: str
    title: str
    severity: str
    cwe: str
    category: str
    language: str
    tool: str
    confidence: str
    snippet: str
    explanation: str
    fix: str
    llm_enhanced: int = 0


class ScanDetail(ScanBrief):
    project_id: int
    project_name: str = ""
