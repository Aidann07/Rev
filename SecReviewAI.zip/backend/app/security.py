from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .config import settings

ALGO = "HS256"


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode()[:72], bcrypt.gensalt()).decode()


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bool(hashed) and bcrypt.checkpw(pw.encode()[:72], hashed.encode())
    except ValueError:
        return False


def create_token(user_id: int, purpose: str = "", minutes: int | None = None, **claims) -> str:
    """purpose берілсе — тек сол мақсатқа жарайтын қысқа мерзімді токен (мысалы, GitHub OAuth state)."""
    exp = datetime.now(timezone.utc) + timedelta(minutes=minutes or settings.token_ttl_minutes)
    payload = {"sub": str(user_id), "exp": exp, **claims}
    if purpose:
        payload["pur"] = purpose
    return jwt.encode(payload, settings.secret_key, algorithm=ALGO)


def decode_claims(token: str, purpose: str = "") -> dict | None:
    """Токен мақсаты сәйкес келмесе (мысалы, state-ті кіру токені ретінде қолдану) — None."""
    try:
        c = jwt.decode(token, settings.secret_key, algorithms=[ALGO])
        int(c["sub"])
    except (jwt.PyJWTError, KeyError, ValueError, TypeError):
        return None
    return c if c.get("pur", "") == purpose else None


def decode_token(token: str, purpose: str = "") -> int | None:
    c = decode_claims(token, purpose)
    return int(c["sub"]) if c else None
