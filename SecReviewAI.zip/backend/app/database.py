from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import settings

_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def init_db() -> None:
    from . import models  # noqa: F401
    Base.metadata.create_all(engine)
    _migrate()
    _seed_advisors()


def _migrate() -> None:
    """Ескі дерекқорға жаңа бағандарды қосады (create_all бар кестені өзгертпейді)."""
    from sqlalchemy import inspect, text
    cols = {c["name"] for c in inspect(engine).get_columns("projects")}
    with engine.begin() as conn:
        if "description" not in cols:
            conn.execute(text("ALTER TABLE projects ADD COLUMN description TEXT DEFAULT ''"))
        if "advisors" not in cols:
            conn.execute(text("ALTER TABLE projects ADD COLUMN advisors JSON"))


def _seed_advisors() -> None:
    """Кесте бос болса ғана бастапқы 50 жетекшіні салады (бар деректер ешқашан қайта жазылмайды)."""
    from .models import Advisor
    from .seed_advisors import advisors
    with SessionLocal() as db:
        if db.query(Advisor).count() == 0:
            db.add_all(Advisor(**a) for a in advisors())
            db.commit()
