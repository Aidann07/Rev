from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .analysis.languages import SUPPORTED
from .config import settings
from .database import init_db
from .routers import advisors, auth, dashboard, projects, scans
from .services import llm


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(title="SecReview AI", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router)
app.include_router(projects.router)
app.include_router(advisors.router)
app.include_router(dashboard.router)  # /scans/recent — /scans/{id}-ден бұрын тіркелуі тиіс
app.include_router(scans.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "llm": llm.enabled(), "queue": "celery" if settings.redis_url else "thread"}


@app.get("/api/languages")
def languages():
    return {"supported": SUPPORTED}


# Frontend build бар болса, сол өзінен беріледі (бір контейнер)
DIST = Path(__file__).resolve().parent.parent / "static"
if DIST.exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        f = (DIST / full_path).resolve()
        if full_path and DIST in f.parents and f.is_file():
            return FileResponse(f)
        return FileResponse(DIST / "index.html")
